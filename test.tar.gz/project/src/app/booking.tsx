/* eslint-disable react-hooks/set-state-in-effect */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { View, Text, SafeAreaView, TouchableOpacity, ScrollView, TextInput, Alert, Image, Animated, Modal, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useBookingStore } from '../store/bookingStore';
import { useMembershipStore } from '../store/membershipStore';
import { calculateDistanceKm, geocodeAddressSync, fetchGooglePlacesAutocomplete, fetchGooglePlaceDetails, reverseGeocodeCoords, AutocompleteSuggestion, getCurrentLocationCoords, searchNearbyPlaces } from '../utils/distance';
import { normalizeDate, canonicalizeTimeRange, formatToDDMMYYYY } from '../utils/date';
import * as Location from 'expo-location';
import { useAddressStore } from '../store/addressStore';
import { useCoachStore, generateMonthlySlots } from '../store/coachStore';
import { useNotificationStore } from '../store/notificationStore';
import { useUserStore } from '../store/userStore';
import { EmptyState, ApplePayConfirmation, BookingSuccessAnimation } from '../components';
import { Ionicons, Feather } from '@expo/vector-icons';
import MapView, { Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import Svg, { Circle, Line } from 'react-native-svg';
import { AssignmentEngine } from '../services/AssignmentEngine';
import { Database, getCurrentServerTime, getISTDateInfo } from '../database/Database';
import { WORKOUT_CATEGORY_MAPPING, getCategoryFromTitle } from '../config/WorkoutMapping';

// 5 Premium experiences specified
interface Experience {
  id: string;
  title: string;
  description: string;
  icon: string;
  gradientColors: string[];
  emoji: string;
  duration: number;
}

const EXPERIENCES: Experience[] = [
  {
    id: 'exp-strength',
    title: 'Forge Strength',
    description: 'Resistance training structured to build lean muscle and agility',
    icon: 'dumbbell',
    gradientColors: ['#FF5A5F', '#FF385C'],
    emoji: '🏋️‍♂️',
    duration: 60,
  },
  {
    id: 'exp-flow',
    title: 'Flow Motion',
    description: 'Yoga & mobility to restore balance and posture',
    icon: 'compass',
    gradientColors: ['#10B981', '#047857'],
    emoji: '🧘‍♀️',
    duration: 60,
  },
  {
    id: 'exp-rhythm',
    title: 'Rhythm Dance',
    description: 'High-intensity dance cardio to burn maximum calories',
    icon: 'music',
    gradientColors: ['#EC4899', '#BE185D'],
    emoji: '💃',
    duration: 60,
  },
  {
    id: 'exp-reset',
    title: 'Reset Studio',
    description: 'Deep stretch, myofascial release, and guided breathwork recovery',
    icon: 'coffee',
    gradientColors: ['#64748B', '#475569'],
    emoji: '🧘‍♂️',
    duration: 60,
  },
  {
    id: 'exp-combat',
    title: 'Combat Core',
    description: 'Shadow boxing, kick drills, and core conditioning',
    icon: 'activity',
    gradientColors: ['#F59E0B', '#D97706'],
    emoji: '🥊',
    duration: 60,
  },
  {
    id: 'exp-aerial',
    title: 'Aerial Yoga',
    description: 'Decompress and stretch using specialized aerial hammocks',
    icon: 'wind',
    gradientColors: ['#8B5CF6', '#6D28D9'],
    emoji: '🧘‍♀️',
    duration: 60,
  },
];

function getCustomerDisplayTime(timeRangeStr: string): string {
  const normalized = timeRangeStr.replace(/–/g, '-').replace(/\s+/g, ' ').trim();
  const parts = normalized.split('-');
  if (parts.length === 2) {
    return `${parts[0].trim()} — ${parts[1].trim()}`;
  }
  return normalized;
}

function splitAddress(fullAddress: string) {
  if (!fullAddress) return { main: 'Selected Location', secondary: '' };
  const commaIndex = fullAddress.indexOf(',');
  if (commaIndex === -1) return { main: fullAddress, secondary: '' };
  const main = fullAddress.substring(0, commaIndex).trim();
  const secondary = fullAddress.substring(commaIndex + 1).trim();
  return { main, secondary };
}

function resolveBuildingName(
  results: any[] | undefined,
  defaultAddress: string
): { buildingName: string; formattedAddress: string } {
  if (!results || results.length === 0) {
    const parts = splitAddress(defaultAddress);
    return { buildingName: parts.main || 'Selected Location', formattedAddress: defaultAddress };
  }

  // Priority building/premise types we want to match
  const buildingTypes = [
    'premise',
    'subpremise',
    'shopping_mall',
    'residential_complex',
    'apartment',
    'society',
    'condominium',
    'establishment',
    'point_of_interest'
  ];

  // Excluded business types we want to avoid choosing as building names
  const excludedBusinessTypes = [
    'restaurant', 'food', 'cafe', 'bar', 'clothing_store', 'store', 'beauty_salon',
    'hair_care', 'spa', 'gym', 'health', 'atm', 'bank', 'liquor_store', 'car_repair',
    'gas_station', 'doctor', 'pharmacy'
  ];

  for (const res of results) {
    // Check if the overall result has any of our priority building/premise types
    const hasBuildingType = res.types && res.types.some((t: string) => buildingTypes.includes(t));
    if (hasBuildingType) {
      if (res.address_components && res.address_components.length > 0) {
        // The first component is usually the building/establishment name
        const firstComp = res.address_components[0];
        
        // Ensure the component is not a street number or just digits
        const isDigits = /^\d+$/.test(firstComp.long_name || '');
        const isStreetNumber = firstComp.types && firstComp.types.includes('street_number');

        if (!isDigits && !isStreetNumber) {
          // Verify it's not an excluded business type
          const isExcludedBusiness = res.types && res.types.some((t: string) => excludedBusinessTypes.includes(t));
          
          if (!isExcludedBusiness) {
            return {
              buildingName: firstComp.long_name,
              formattedAddress: res.formatted_address || defaultAddress
            };
          }
        }
      }
    }
  }

  // 2. Priority 3: route + street number
  for (const res of results) {
    if (res.types && (res.types.includes('street_address') || res.types.includes('route'))) {
      const streetNumber = res.address_components?.find((c: any) => c.types && c.types.includes('street_number'))?.long_name;
      const route = res.address_components?.find((c: any) => c.types && c.types.includes('route'))?.long_name;
      if (streetNumber && route) {
        return {
          buildingName: `${streetNumber} ${route}`,
          formattedAddress: res.formatted_address || defaultAddress
        };
      } else if (route) {
        return {
          buildingName: route,
          formattedAddress: res.formatted_address || defaultAddress
        };
      }
    }
  }

  // 3. Priority 4: neighbourhood / sublocality
  for (const type of ['neighborhood', 'sublocality_level_1', 'sublocality_level_2', 'sublocality']) {
    for (const res of results) {
      if (res.types && res.types.includes(type)) {
        const comp = res.address_components?.find((c: any) => c.types && c.types.includes(type));
        if (comp && comp.long_name) {
          return {
            buildingName: comp.long_name,
            formattedAddress: res.formatted_address || defaultAddress
          };
        }
      }
    }
  }

  // 4. Default fallback
  const firstRes = results[0];
  const mainPart = splitAddress(firstRes.formatted_address || defaultAddress).main;
  return {
    buildingName: mainPart || 'Selected Location',
    formattedAddress: firstRes.formatted_address || defaultAddress
  };
}

function rankNearbyCandidates(
  places: any[],
  centerLat: number,
  centerLng: number
): any | null {
  if (!places || places.length === 0) return null;

  const excludedTypes = [
    'restaurant', 'food', 'cafe', 'bar', 'clothing_store', 'store', 
    'beauty_salon', 'hair_care', 'spa', 'gym', 'health', 'atm', 'bank', 
    'liquor_store', 'car_repair', 'gas_station', 'doctor', 'pharmacy'
  ];

  const candidates = places.map(place => {
    const lat1 = centerLat;
    const lon1 = centerLng;
    const lat2 = place.location?.latitude || 0;
    const lon2 = place.location?.longitude || 0;
    
    // Haversine formula
    const R = 6371e3; // meters
    const phi1 = lat1 * Math.PI/180;
    const phi2 = lat2 * Math.PI/180;
    const deltaPhi = (lat2-lat1) * Math.PI/180;
    const deltaLambda = (lon2-lon1) * Math.PI/180;
    const a = Math.sin(deltaPhi/2) * Math.sin(deltaPhi/2) +
              Math.cos(phi1) * Math.cos(phi2) *
              Math.sin(deltaLambda/2) * Math.sin(deltaLambda/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c; // in meters

    let weight = 0;
    const types = place.types || [];
    
    const name = (place.displayName?.text || '').toLowerCase();
    const isNamedBuilding = name.includes('society') || 
                            name.includes('building') || 
                            name.includes('apartment') || 
                            name.includes('residences') ||
                            name.includes('chambers') || 
                            name.includes('complex') || 
                            name.includes('park') || 
                            name.includes('tower') || 
                            name.includes('heights') || 
                            name.includes('villa') || 
                            name.includes('residency') || 
                            name.includes('manor') || 
                            name.includes('estate') ||
                            name.includes('mall') ||
                            name.includes('plaza') ||
                            name.includes('court') ||
                            name.includes('house') ||
                            name.includes('gardens') ||
                            name.includes('arcade') ||
                            name.includes('square') ||
                            name.includes('center') ||
                            name.includes('centre');

    if (types.includes('premise') || types.includes('subpremise')) {
      weight += 100;
    } else if (types.includes('residential') || types.includes('housing')) {
      weight += 80;
    } else if (isNamedBuilding) {
      weight += 60;
    } else if (types.includes('establishment') || types.includes('point_of_interest')) {
      weight += 30;
    }

    const hasExcludedType = types.some((t: string) => excludedTypes.includes(t));
    if (hasExcludedType) {
      weight -= 80;
    }

    const finalScore = weight - distance;

    return {
      place,
      distance,
      isNamedBuilding,
      finalScore
    };
  });

  candidates.sort((a, b) => b.finalScore - a.finalScore);

  const best = candidates[0];
  if (best && best.finalScore > 10) {
    return best.place;
  }
  return null;
}

async function resolveExactLocation(
  latitude: number,
  longitude: number,
  geocodedAddress: string,
  geocodedResults: any[] | undefined
): Promise<{ buildingName: string; formattedAddress: string }> {
  const geoResolved = resolveBuildingName(geocodedResults, geocodedAddress);
  
  const isGeneric = geoResolved.buildingName === 'Selected Location' ||
                    /^\d/.test(geoResolved.buildingName) ||
                    geoResolved.buildingName.includes('°') ||
                    geoResolved.buildingName.toLowerCase() === 'andheri west' ||
                    geoResolved.buildingName.toLowerCase() === 'mumbai suburban' ||
                    geoResolved.buildingName.toLowerCase() === 'mumbai' ||
                    geoResolved.buildingName.toLowerCase() === 'maharashtra' ||
                    geoResolved.buildingName.toLowerCase() === 'juhu' ||
                    geoResolved.buildingName.toLowerCase() === 'bandra west' ||
                    geoResolved.buildingName.toLowerCase() === 'bandra' ||
                    geoResolved.buildingName.toLowerCase() === 'colaba' ||
                    geoResolved.buildingName.toLowerCase() === 'powai' ||
                    /\b(road|rd|lane|nagar|gali|marg|street|st)\b/i.test(geoResolved.buildingName);

  if (isGeneric) {
    try {
      const nearbyPlaces = await searchNearbyPlaces(latitude, longitude);
      const bestCandidate = rankNearbyCandidates(nearbyPlaces, latitude, longitude);
      if (bestCandidate) {
        return {
          buildingName: bestCandidate.displayName?.text || geoResolved.buildingName,
          formattedAddress: bestCandidate.formattedAddress || geoResolved.formattedAddress
        };
      }
    } catch (e) {
      console.warn('Failed resolving nearby places for center pin:', e);
    }
  }

  return geoResolved;
}

export default function BookingScreen() {
  const router = useRouter();
  const noteInputRef = React.useRef<TextInput>(null);
  const params = useLocalSearchParams();
  const initialWorkoutId = params.workoutId as string;
  const initialWorkoutType = params.workoutType as string;
  const initialWorkoutName = params.workoutName as string;

  const { addBooking, bookings } = useBookingStore();
  const { consumeCredit } = useMembershipStore();
  const { addresses, addAddress, selectedAddressId, setSelectedAddressId } = useAddressStore();
  const { coaches } = useCoachStore();
  const { addNotification } = useNotificationStore();
  const { user } = useUserStore();

  // Booking Wizard Steps (1 to 6)
  const [step, setStep] = useState(1);

  const getInitialExperience = () => {
    const searchString = [initialWorkoutId, initialWorkoutType, initialWorkoutName]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    if (searchString) {
      if (
        searchString.includes('aerial') ||
        searchString.includes('hammock') ||
        searchString.includes('exp-aerial')
      ) {
        return EXPERIENCES[5];
      } else if (
        searchString.includes('yoga') || 
        searchString.includes('flow') || 
        searchString.includes('pilates') || 
        searchString.includes('mind & body') || 
        searchString.includes('w-2') || 
        searchString.includes('w-3')
      ) {
        return EXPERIENCES[1];
      } else if (
        searchString.includes('dance') || 
        searchString.includes('rhythm') || 
        searchString.includes('cardio') || 
        searchString.includes('w-4')
      ) {
        return EXPERIENCES[2];
      } else if (
        searchString.includes('stretch') || 
        searchString.includes('recovery') || 
        searchString.includes('reset') || 
        searchString.includes('mobility') || 
        searchString.includes('w-5')
      ) {
        return EXPERIENCES[3];
      } else if (
        searchString.includes('boxing') || 
        searchString.includes('combat') || 
        searchString.includes('kickboxing') || 
        searchString.includes('w-8')
      ) {
        return EXPERIENCES[4];
      }
    }
    return EXPERIENCES[0];
  };

  const [selectedExperience, setSelectedExperience] = useState<Experience>(() => getInitialExperience());
  const [trainerPref, setTrainerPref] = useState<'any' | 'female' | 'male' | 'favourite'>(() => {
    const profile = Database.getProfile(useUserStore.getState().user?.id || '');
    const pref = (profile?.trainerPreference || 'no_preference').toLowerCase();
    if (pref === 'male') return 'male';
    if (pref === 'female') return 'female';
    return 'any';
  });
  const [selectedTrainerId, setSelectedTrainerId] = useState<string>('');
  
  // Location selection (legacy tabs unused state cleaned)
  const [addrDefault, setAddrDefault] = useState(false);

  // Location SPRINT 4 states
  const [gpsPermission, setGpsPermission] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [gpsSignalFailure, setGpsSignalFailure] = useState(false);
  const [networkFailure, setNetworkFailure] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [activeCoords, setActiveCoords] = useState({ lat: 19.0176, lng: 72.8164 });
  const [googleSuggestions, setGoogleSuggestions] = useState<Array<AutocompleteSuggestion>>([]);
  const [isSearchingLocation, setIsSearchingLocation] = useState(false);
  const [sessionToken, setSessionToken] = useState(() => Math.random().toString(36).substring(2, 15) + Date.now().toString());
  const [hasConfirmedSearchSelection, setHasConfirmedSearchSelection] = useState(false);
  const [isPinSelectionAuthoritative, setIsPinSelectionAuthoritative] = useState(true);

  // Debounced search query autocomplete for workout location selector
  useEffect(() => {
    if (searchQuery.trim().length < 3 || hasConfirmedSearchSelection) {
      setGoogleSuggestions([]);
      return;
    }
    let active = true;
    const delay = setTimeout(async () => {
      setIsSearchingLocation(true);
      try {
        const res = await fetchGooglePlacesAutocomplete(searchQuery, sessionToken);
        if (active) {
          setGoogleSuggestions(res);
          setShowSearchDropdown(true);
        }
      } catch (err) {
        console.warn('Google autocomplete failed:', err);
      } finally {
        if (active) {
          setIsSearchingLocation(false);
        }
      }
    }, 450);

    return () => {
      active = false;
      clearTimeout(delay);
    };
  }, [searchQuery, sessionToken, hasConfirmedSearchSelection]);
  const [etaText, setEtaText] = useState('~12 mins travel');
  const [distanceText, setDistanceText] = useState('3.2 km');
  const [isLocationOutsideCoverage, setIsLocationOutsideCoverage] = useState(false);
  const [successBookingId, setSuccessBookingId] = useState('');

  // Redesigned Step 3 location modal/flow states
  const [isAddAddressModalVisible, setIsAddAddressModalVisible] = useState(false);
  const [addAddressStep, setAddAddressStep] = useState<1 | 2>(1); // Stage 1 (Map/Search), Stage 2 (Details)
  const [placeId, setPlaceId] = useState('');
  const [resolvedPlaceName, setResolvedPlaceName] = useState('Selected Location');
  const [isReverseGeocoding, setIsReverseGeocoding] = useState(false);
  const [isMapConfirmed, setIsMapConfirmed] = useState(false);
  const [gpsAccuracy, setGpsAccuracy] = useState<number | null>(null);
  const mapRef = useRef<MapView>(null);
  const reverseGeocodeTimerRef = useRef<any>(null);
  const geocodeRequestCounterRef = useRef(0);

  // New address form fields
  const [newHouseNo, setNewHouseNo] = useState('');
  const [newBuildingName, setNewBuildingName] = useState('');
  const [newFloor, setNewFloor] = useState('');
  const [newTower, setNewTower] = useState('');
  const [newLandmark, setNewLandmark] = useState('');
  const [newArrivalInstructions, setNewArrivalInstructions] = useState('');
  const [newAddressLabelType, setNewAddressLabelType] = useState<'Home' | 'Office' | 'Gym' | 'Custom'>('Home');
  const [newCustomLabel, setNewCustomLabel] = useState('');

  const openAddressModal = () => {
    geocodeRequestCounterRef.current++;
    if (reverseGeocodeTimerRef.current) {
      clearTimeout(reverseGeocodeTimerRef.current);
    }
    setIsReverseGeocoding(false);

    setNewHouseNo('');
    setNewBuildingName('');
    setNewFloor('');
    setNewLandmark('');
    setNewTower('');
    setNewAddressLabelType('Home');
    setNewCustomLabel('');
    setSearchQuery('');
    setPlaceId('');
    setResolvedPlaceName('Selected Location');
    setHasConfirmedSearchSelection(false);
    setIsPinSelectionAuthoritative(true);
    
    const lat = activeCoords.lat !== 0 ? activeCoords.lat : 19.0176;
    const lng = activeCoords.lng !== 0 ? activeCoords.lng : 72.8164;
    setActiveCoords({ lat, lng });

    setTimeout(() => {
      mapRef.current?.animateToRegion({
        latitude: lat,
        longitude: lng,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005,
      }, 300);
    }, 300);

    setAddAddressStep(1);
    setIsAddAddressModalVisible(true);
  };

  const handleSearchTextChange = (text: string) => {
    setSearchQuery(text);
    setHasConfirmedSearchSelection(false);
    setIsPinSelectionAuthoritative(false);
    setPlaceId('');
    if (text.trim().length < 3) {
      setGoogleSuggestions([]);
      setShowSearchDropdown(false);
    } else {
      setShowSearchDropdown(true);
    }
  };

  const formatISTDate = (date: Date): string => {
    const info = getISTDateInfo(date);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[info.month - 1]} ${info.day}, ${info.year}`;
  };

  // Date selection
  const [dateSelectionType, setDateSelectionType] = useState<'today' | 'tomorrow' | 'dayafter' | 'calendar'>('today');
  const [selectedDate, setSelectedDate] = useState(() => {
    const istNow = getCurrentServerTime();
    const info = getISTDateInfo(istNow);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[info.month - 1]} ${info.day}, ${info.year}`;
  });
  const [showCalendarPicker, setShowCalendarPicker] = useState(false);

  const getDefaultTimePeriod = () => {
    const hour = new Date().getHours();
    if (hour >= 6 && hour < 12) return 'morning';
    if (hour >= 12 && hour < 17) return 'afternoon';
    if (hour >= 17 && hour < 21) return 'evening';
    return 'night';
  };
  const [timePeriod, setTimePeriod] = useState<'morning' | 'afternoon' | 'evening' | 'night'>(() => getDefaultTimePeriod());
  const [selectedTime, setSelectedTime] = useState('');

  // Matchmaker and reveal state
  const [matchStage, setMatchStage] = useState(0);
  const [matchDone, setMatchDone] = useState(false);
  const [matchedCoach, setMatchedCoach] = useState<any>(null);
  const [trainerNote, setTrainerNote] = useState('');
  const [isConfirming, setIsConfirming] = useState(false);
  // Reservation states (Phase 3.1)
  const [reservationId, setReservationId] = useState<string>('');
  const [reservationTimeLeft, setReservationTimeLeft] = useState<number>(0);

  // Layout Animation
  const [slideAnim] = useState(() => new Animated.Value(0));
  const [radarAnim] = useState(() => new Animated.Value(0));

  // Synchronize database content on mount in case of direct deep link / refresh
  useEffect(() => {
    const initData = async () => {
      try {
        console.log('[BOOKING] Waiting for userStore hydration on mount...');
        // Wait for Zustand store to rehydrate from persistent storage
        while (!useUserStore.persist.hasHydrated()) {
          await new Promise((resolve) => setTimeout(resolve, 50));
        }

        const user = useUserStore.getState().user;
        const isLoggedIn = useUserStore.getState().isLoggedIn;
        console.log('[BOOKING] userStore hydrated. isLoggedIn:', isLoggedIn, 'userId:', user?.id);

        if (isLoggedIn && user && user.id) {
          Database.setCurrentUserId(user.id);
        } else {
          console.warn('[BOOKING] User is not logged in or userId is missing on mount');
        }

        console.log('[BOOKING] Reloading database from Supabase on mount...');
        await Database.reload();
        useCoachStore.getState().syncFromDB();
        useAddressStore.getState().syncFromDB();
        console.log('[BOOKING] Database reloaded and stores synchronized.');
      } catch (err) {
        console.warn('Direct store sync failed on mount:', err);
      }
    };
    initData();
  }, []);

  const parseTimeToMinutesHelper = (timeStr: string): number => {
    const match = timeStr.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (!match) return 0;
    let hours = parseInt(match[1]);
    const minutes = parseInt(match[2]);
    const ampm = match[3].toUpperCase();
    if (ampm === 'PM' && hours < 12) hours += 12;
    if (ampm === 'AM' && hours === 12) hours = 0;
    return hours * 60 + minutes;
  };

  const getDevelopmentDiagnostics = () => {
    const targetCategory = WORKOUT_CATEGORY_MAPPING[selectedExperience.id] || '';
    const customerAddress = addresses.find(a => a.id === selectedAddressId);
    
    const candidates = coaches.length;
    let favFilter = 0;
    let onlineFilter = 0;
    let partnerFilter = 0;
    let workoutFilter = 0;
    let locationFilter = 0;
    let radiusFilter = 0;
    let workloadFilter = 0;

    if (!customerAddress || customerAddress.lat === undefined || customerAddress.lng === undefined || customerAddress.lat === null || customerAddress.lng === null) {
      return {
        candidates,
        favFilter,
        onlineFilter,
        partnerFilter,
        workoutFilter,
        locationFilter,
        radiusFilter,
        workloadFilter,
        customerLocationError: true
      };
    }

    const customerLat = customerAddress.lat;
    const customerLng = customerAddress.lng;

    for (const coach of coaches) {
      const isFavOk = (trainerPref !== 'favourite' || !selectedTrainerId || coach.id === selectedTrainerId);
      if (isFavOk) favFilter++;

      const isOnline = coach.preferences?.online !== false;
      if (isFavOk && isOnline) onlineFilter++;

      const isPartnerApproved = coach.verifiedBadge !== false;
      if (isFavOk && isOnline && isPartnerApproved) partnerFilter++;
      const assignments = Database.getWorkoutAssignments(coach.id);
      const isApproved = assignments.some(a => a.workoutCategory === targetCategory && a.status === 'APPROVED');
      const acceptsAll = assignments.some(a => a.workoutCategory === 'All Workouts' && a.status === 'APPROVED');
      const workoutApproved = acceptsAll || isApproved;
      if (isFavOk && isOnline && isPartnerApproved && workoutApproved) workoutFilter++;

      const locationStatus = coach.preferences?.operatingLocationStatus;
      const isLocationApproved = locationStatus === 'verified';
      if (isFavOk && isOnline && isPartnerApproved && workoutApproved && isLocationApproved) locationFilter++;

      const trainerLat = coach.preferences?.operatingLatitude;
      const trainerLng = coach.preferences?.operatingLongitude;
      const radiusLimit = coach.preferences?.radiusKm || 15;
      let distance = 999999;
      let insideRadius = false;
      if (trainerLat !== undefined && trainerLat !== null && trainerLng !== undefined && trainerLng !== null) {
        distance = calculateDistanceKm(trainerLat, trainerLng, customerLat, customerLng);
        insideRadius = distance <= radiusLimit;
      }
      if (isFavOk && isOnline && isPartnerApproved && workoutApproved && isLocationApproved && insideRadius) radiusFilter++;

      const activeCount = bookings.filter(b => 
        b.trainerId === coach.id && 
        normalizeDate(b.date) === normalizeDate(selectedDate) &&
        b.status === 'upcoming' &&
        (b.timelineStatus === 'booked' || b.timelineStatus === 'trainer_assigned' || b.timelineStatus === 'trainer_accepted' || b.timelineStatus === 'trainer_preparing' || b.timelineStatus === 'trainer_travelling' || b.timelineStatus === 'trainer_arrived' || b.timelineStatus === 'otp_verified' || b.timelineStatus === 'workout_started')
      ).length;
      const maxSessions = coach.preferences?.maxDailySessions || 5;
      const workloadOk = activeCount < maxSessions;
      if (isFavOk && isOnline && isPartnerApproved && workoutApproved && isLocationApproved && insideRadius && workloadOk) workloadFilter++;
    }

    return {
      candidates,
      favFilter,
      onlineFilter,
      partnerFilter,
      workoutFilter,
      locationFilter,
      radiusFilter,
      workloadFilter,
      customerLocationError: false
    };
  };

  const getDynamicAvailableSlots = (): any[] => {
    const targetCategory = WORKOUT_CATEGORY_MAPPING[selectedExperience.id] || '';
    if (!targetCategory) return [];

    const customerAddress = addresses.find(a => a.id === selectedAddressId);
    if (!customerAddress || customerAddress.lat === undefined || customerAddress.lng === undefined || customerAddress.lat === null || customerAddress.lng === null) {
      console.log('CUSTOMER_LOCATION_ERROR: Customer booking address has no coordinates');
      return [];
    }

    const customerLat = customerAddress.lat;
    const customerLng = customerAddress.lng;

    const normalizedDateStr = normalizeDate(selectedDate);
    const dateParts = normalizedDateStr.split('-');
    const targetYear = parseInt(dateParts[0], 10);
    const targetMonth = parseInt(dateParts[1], 10) - 1; // 0-indexed month
    const targetDay = parseInt(dateParts[2], 10);
    const targetDateObj = new Date(targetYear, targetMonth, targetDay);

    const monthlyDaySlots = generateMonthlySlots(targetMonth, targetYear);
    const defaultDaySlots = monthlyDaySlots.find(d => normalizeDate(d.date) === normalizedDateStr)?.slots || [];

    const trainerPool = coaches.map(coach => {
      // 1. Account approved
      const isOnline = coach.preferences?.online !== false;
      const isPartnerApproved = coach.verifiedBadge !== false;
      const accountApproved = isOnline && isPartnerApproved;

      // 2. Workout approved
      const assignments = Database.getWorkoutAssignments(coach.id);
      const isApproved = assignments.some(a => a.workoutCategory === targetCategory && a.status === 'APPROVED');
      const acceptsAll = assignments.some(a => a.workoutCategory === 'All Workouts' && a.status === 'APPROVED');
      const workoutApproved = acceptsAll || isApproved;

      // 3. Location approved
      const locationStatus = coach.preferences?.operatingLocationStatus;
      const locationApproved = locationStatus === 'verified' || locationStatus === 'pending' || !locationStatus;

      // 3b. Gender approved (using canonical lowercase comparison)
      const trainerGender = (coach.gender || '').toLowerCase();
      const genderValid = !trainerGender || trainerGender === 'male' || trainerGender === 'female';
      
      let genderApproved = false;
      if (genderValid) {
        if (trainerPref === 'any') {
          genderApproved = true;
        } else if (trainerPref === 'male') {
          genderApproved = trainerGender === 'male';
        } else if (trainerPref === 'female') {
          genderApproved = trainerGender === 'female';
        } else if (trainerPref === 'favourite') {
          const clientPref = (Database.getProfile(user.id || '')?.trainerPreference || 'no_preference').toLowerCase();
          if (clientPref === 'male') {
            genderApproved = trainerGender === 'male';
          } else if (clientPref === 'female') {
            genderApproved = trainerGender === 'female';
          } else {
            genderApproved = true;
          }
        }
      }

      // 4. Radius eligible
      const trainerLat = coach.preferences?.operatingLatitude;
      const trainerLng = coach.preferences?.operatingLongitude;
      const radiusLimit = coach.preferences?.radiusKm || 15;
      let distance = 999999;
      let radiusEligible = false;
      if (trainerLat !== undefined && trainerLat !== null && trainerLng !== undefined && trainerLng !== null) {
        distance = calculateDistanceKm(trainerLat, trainerLng, customerLat, customerLng);
        radiusEligible = distance <= radiusLimit;
      }

      // 5. Workload OK
      const activeCount = bookings.filter(b => 
        b.trainerId === coach.id && 
        normalizeDate(b.date) === normalizedDateStr &&
        b.status === 'upcoming' &&
        (b.timelineStatus === 'booked' || b.timelineStatus === 'trainer_assigned' || b.timelineStatus === 'trainer_accepted' || b.timelineStatus === 'trainer_preparing' || b.timelineStatus === 'trainer_travelling' || b.timelineStatus === 'trainer_arrived' || b.timelineStatus === 'otp_verified' || b.timelineStatus === 'workout_started')
      ).length;
      const maxSessions = coach.preferences?.maxDailySessions || 5;
      const workloadOk = activeCount < maxSessions;

      // 6. Slots availability mapping
      const overrides = coach.preferences?.availabilityOverrides || [];
      
      // Get current time in IST (UTC+5:30)
      const now = getCurrentServerTime();
      const nowUtc = now.getTime();
      const istOffset = 5.5 * 60 * 60 * 1000;
      const istTime = new Date(nowUtc + istOffset);
      const istYear = istTime.getUTCFullYear();
      const istMonth = istTime.getUTCMonth() + 1;
      const istDay = istTime.getUTCDate();
      const istHours = istTime.getUTCHours();
      const istMinutes = istTime.getUTCMinutes();
      const istSeconds = istTime.getUTCSeconds();
      const nowIst = new Date(Date.UTC(istYear, istMonth - 1, istDay, istHours, istMinutes, istSeconds));

      const dailySlots = defaultDaySlots.map(slot => {
        const override = overrides.find(o => 
          normalizeDate(o.date) === normalizedDateStr && 
          canonicalizeTimeRange(o.time) === canonicalizeTimeRange(slot.time)
        );
        const isAvailable = override ? override.isAvailable : true;
        const slotCategory = override?.category || '';
        return {
          ...slot,
          isAvailable,
          category: slotCategory
        };
      }).filter((s: any) => {
        if (!s.isAvailable) return false;

        const categoryMatch = !s.category || s.category === 'All Workouts' || s.category === 'ANY WORKOUT' || s.category === targetCategory;
        if (!categoryMatch) return false;

        // Apply universal 15-minute slot visibility rule
        const startPart = s.time.split('-')[0].trim(); // e.g. "07:00 PM"
        const match = startPart.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
        if (match) {
          let hour = parseInt(match[1], 10);
          const minute = parseInt(match[2], 10);
          const ampm = match[3].toUpperCase();
          if (ampm === 'PM' && hour < 12) hour += 12;
          if (ampm === 'AM' && hour === 12) hour = 0;

          const dateParts = normalizedDateStr.split('-');
          const slotYear = parseInt(dateParts[0], 10);
          const slotMonth = parseInt(dateParts[1], 10);
          const slotDay = parseInt(dateParts[2], 10);

          const slotStartIst = new Date(Date.UTC(slotYear, slotMonth - 1, slotDay, hour, minute, 0));
          const visibilityStartMs = slotStartIst.getTime() - 15 * 60 * 1000;

          if (nowIst.getTime() > visibilityStartMs) {
            return false; // Hide slot if after T-15 minutes
          }
        }
        return true;
      });

      let hasAvailableSlot = false;
      for (const slot of dailySlots) {
        const hasBooking = bookings.some(b => 
          b.trainerId === coach.id && 
          b.status === 'upcoming' && 
          normalizeDate(b.date) === normalizedDateStr && 
          canonicalizeTimeRange(b.time) === canonicalizeTimeRange(slot.time)
        );
        const targetMinutes = parseTimeToMinutesHelper(slot.time);
        const hasBufferConflict = bookings.some(b => {
          if (b.trainerId !== coach.id || b.status !== 'upcoming' || normalizeDate(b.date) !== normalizedDateStr) return false;
          const bMinutes = parseTimeToMinutesHelper(b.time);
          const diff = Math.abs(bMinutes - targetMinutes);
          const duration = b.durationMinutes || 60;
          return diff < (duration + 30);
        });
        const slotReservations = Database.schema.slot_reservations || [];
        const isReserved = slotReservations.some(r => 
          r.trainer_id === coach.id && 
          normalizeDate(r.slot_date) === normalizedDateStr && 
          canonicalizeTimeRange(r.slot_time) === canonicalizeTimeRange(slot.time) && 
          r.client_id !== user.id
        );
        if (!hasBooking && !hasBufferConflict && !isReserved) {
          hasAvailableSlot = true;
        }
      }
      const slotEligible = hasAvailableSlot;

      // 7. Favoring/Explicit selection checks
      const isFavOk = (trainerPref !== 'favourite' || !selectedTrainerId || coach.id === selectedTrainerId);

      // Final Eligibility
      const coachEligible = isFavOk && accountApproved && workoutApproved && locationApproved && radiusEligible && workloadOk && genderApproved && genderValid;
      const finalEligible = coachEligible && slotEligible;

      // 8. Exclusion reasons list
      const exclusionReasons: string[] = [];
      if (!genderValid) exclusionReasons.push('INVALID_GENDER');
      if (genderValid && !genderApproved) exclusionReasons.push('GENDER_MISMATCH');
      if (trainerPref === 'favourite' && selectedTrainerId && coach.id !== selectedTrainerId) exclusionReasons.push('NOT_SELECTED_FAVOURITE_TRAINER');
      if (!isOnline) exclusionReasons.push('TRAINER_OFFLINE');
      if (!isPartnerApproved) exclusionReasons.push('TRAINER_NOT_VERIFIED');
      if (!workoutApproved) exclusionReasons.push('WORKOUT_NOT_APPROVED');
      if (!locationApproved) exclusionReasons.push('TRAINER_LOCATION_NOT_VERIFIED');
      if (trainerLat === undefined || trainerLat === null || trainerLng === undefined || trainerLng === null) {
        exclusionReasons.push('TRAINER_LOCATION_MISSING');
      } else if (!radiusEligible) {
        exclusionReasons.push('OUTSIDE_SERVICE_RADIUS');
      }
      if (!workloadOk) exclusionReasons.push('DAILY_LIMIT');
      if (coachEligible && !slotEligible) exclusionReasons.push('NO_AVAILABLE_SLOTS');

      return {
        id: coach.id,
        name: coach.name,
        isRealBackendTrainer: !coach.id.startsWith('c-'),
        accountApproved,
        workoutApproved,
        locationApproved,
        radiusEligible,
        slotEligible,
        finalEligible,
        exclusionReasons
      };
    });

    const finalEligibleTrainers = trainerPool.filter(t => t.finalEligible);

    console.log('TRAINER_MATCH_DEBUG', JSON.stringify({
      databaseSource: Database.loadSource === 'supabase' ? 'REMOTE_SUPABASE' : 'LOCAL_FALLBACK',
      databaseTrainerCount: coaches.length,
      trainerPool,
      finalEligibleTrainerCount: finalEligibleTrainers.length,
      finalEligibleTrainerIds: finalEligibleTrainers.map(t => t.id),
      finalEligibleTrainerNames: finalEligibleTrainers.map(t => t.name)
    }, null, 2));

    if (typeof __DEV__ !== 'undefined' && __DEV__) {
      console.log('\n================ TRAINER MATCHING DIAGNOSTICS ================');
      trainerPool.forEach(tp => {
        const coachObj = coaches.find(c => c.id === tp.id);
        if (!coachObj) return;

        const trainerGender = (coachObj.gender || '').toLowerCase();
        const genderValid = trainerGender === 'male' || trainerGender === 'female';
        
        let genderApproved = false;
        if (genderValid) {
          if (trainerPref === 'any') {
            genderApproved = true;
          } else if (trainerPref === 'male') {
            genderApproved = trainerGender === 'male';
          } else if (trainerPref === 'female') {
            genderApproved = trainerGender === 'female';
          } else if (trainerPref === 'favourite') {
            const clientPref = (Database.getProfile(user.id || '')?.trainerPreference || 'no_preference').toLowerCase();
            if (clientPref === 'male') {
              genderApproved = trainerGender === 'male';
            } else if (clientPref === 'female') {
              genderApproved = trainerGender === 'female';
            } else {
              genderApproved = true;
            }
          }
        }

        const isOnline = coachObj.preferences?.online !== false;
        const isPartnerApproved = coachObj.verifiedBadge !== false;
        
        const assignments = Database.getWorkoutAssignments(coachObj.id);
        const isApproved = assignments.some(a => a.workoutCategory === targetCategory && a.status === 'APPROVED');
        const acceptsAll = assignments.some(a => a.workoutCategory === 'All Workouts' && a.status === 'APPROVED');
        const workoutApproved = acceptsAll || isApproved;

        const locationStatus = coachObj.preferences?.operatingLocationStatus;
        const locationApproved = locationStatus === 'verified';

        const trainerLat = coachObj.preferences?.operatingLatitude;
        const trainerLng = coachObj.preferences?.operatingLongitude;
        const radiusLimit = coachObj.preferences?.radiusKm || 15;
        let distance = 999999;
        let radiusEligible = false;
        if (trainerLat !== undefined && trainerLat !== null && trainerLng !== undefined && trainerLng !== null) {
          distance = calculateDistanceKm(trainerLat, trainerLng, customerLat, customerLng);
          radiusEligible = distance <= radiusLimit;
        }

        const activeCount = bookings.filter(b => 
          b.trainerId === coachObj.id && 
          normalizeDate(b.date) === normalizedDateStr &&
          b.status === 'upcoming'
        ).length;
        const maxSessions = coachObj.preferences?.maxDailySessions || 5;
        const workloadOk = activeCount < maxSessions;

        // Evaluate failed steps
        let firstFailedStep = '';
        if (!isOnline) firstFailedStep = 'Step 2: Trainer is offline';
        else if (!isPartnerApproved) firstFailedStep = 'Step 3: Trainer is not verified';
        else if (!genderValid) firstFailedStep = 'Step 4: Invalid/missing trainer gender in database';
        else if (!genderApproved) firstFailedStep = `Step 5: Trainer gender (${trainerGender}) does not match client preference (${trainerPref})`;
        else if (!workoutApproved) firstFailedStep = `Step 6: Trainer is not approved for category "${targetCategory}"`;
        else if (!locationApproved) firstFailedStep = `Step 12: Trainer operating location verification status is "${locationStatus}"`;
        else if (trainerLat === undefined || trainerLng === undefined) firstFailedStep = 'Step 12: Trainer has no operating coordinates configured';
        else if (!radiusEligible) firstFailedStep = `Step 11: Trainer is outside service radius (Distance: ${distance === 999999 ? 'N/A' : distance.toFixed(1) + ' km'}, Limit: ${radiusLimit} km)`;
        else if (!workloadOk) firstFailedStep = `Step 10: Maximum daily session limit reached (${activeCount}/${maxSessions})`;
        else if (!tp.slotEligible) firstFailedStep = 'Step 8: No time slots available on this date';

        console.log(`TRAINER MATCHING DIAGNOSTIC\n\n` +
          `Trainer: ${coachObj.name}\n` +
          `Trainer ID: ${coachObj.id}\n\n` +
          `Gender:\n` +
          `  Database gender: ${coachObj.gender || 'null'}\n` +
          `  Mapped gender: ${trainerGender}\n` +
          `  Gender valid: ${genderValid ? 'PASS' : 'FAIL'}\n` +
          `  Gender preference match: ${genderApproved ? 'PASS' : 'FAIL'}\n\n` +
          `Status:\n` +
          `  Trainer active: ${isOnline ? 'PASS' : 'FAIL'}\n` +
          `  Trainer verified: ${isPartnerApproved ? 'PASS' : 'FAIL'}\n\n` +
          `Workout:\n` +
          `  Requested workout: ${selectedExperience.title} (Category: ${targetCategory})\n` +
          `  Trainer workout approved: ${workoutApproved ? 'PASS' : 'FAIL'}\n\n` +
          `Date:\n` +
          `  Requested date: ${selectedDate} (${normalizedDateStr})\n` +
          `  Trainer available that date: PASS (no overrides blocking the day)\n\n` +
          `Location:\n` +
          `  Client location coordinates: ${customerLat}, ${customerLng}\n` +
          `  Trainer operating location coordinates: ${trainerLat || 'null'}, ${trainerLng || 'null'}\n` +
          `  Service radius limit: ${radiusLimit} km\n` +
          `  Distance calculated: ${distance === 999999 ? 'N/A' : distance.toFixed(2) + ' km'}\n` +
          `  Radius eligibility: ${radiusEligible ? 'PASS' : 'FAIL'}\n\n` +
          `Final:\n` +
          `  ELIGIBLE: ${tp.finalEligible ? 'YES' : 'NO'}\n` +
          (tp.finalEligible ? '' : `  REJECTION REASON: ${firstFailedStep}\n`)
        );
      });
      console.log('==============================================================\n');
    }

    // Construct slot mapping
    const aggregatedSlotsMap: Record<string, { slot: any; trainers: typeof coaches }> = {};
    const eligibleCoachesList = coaches.filter(c => {
      const matchStatus = trainerPool.find(tp => tp.id === c.id);
      return matchStatus ? matchStatus.finalEligible : false;
    });

    for (const coach of eligibleCoachesList) {
      const overrides = coach.preferences?.availabilityOverrides || [];
      const dailySlots = defaultDaySlots.map(slot => {
        const override = overrides.find(o => 
          normalizeDate(o.date) === normalizedDateStr && 
          canonicalizeTimeRange(o.time) === canonicalizeTimeRange(slot.time)
        );
        const isAvailable = override ? override.isAvailable : true;
        const slotCategory = override?.category || '';
        return {
          ...slot,
          isAvailable,
          category: slotCategory
        };
      }).filter((s: any) => 
        s.isAvailable && 
        (!s.category || s.category === 'All Workouts' || s.category === 'ANY WORKOUT' || s.category === targetCategory)
      );

      for (const slot of dailySlots) {
        const hasBooking = bookings.some(b => 
          b.trainerId === coach.id && 
          b.status === 'upcoming' && 
          normalizeDate(b.date) === normalizedDateStr && 
          canonicalizeTimeRange(b.time) === canonicalizeTimeRange(slot.time)
        );
        const targetMinutes = parseTimeToMinutesHelper(slot.time);
        const hasBufferConflict = bookings.some(b => {
          if (b.trainerId !== coach.id || b.status !== 'upcoming' || normalizeDate(b.date) !== normalizedDateStr) return false;
          const bMinutes = parseTimeToMinutesHelper(b.time);
          const diff = Math.abs(bMinutes - targetMinutes);
          const duration = b.durationMinutes || 60;
          return diff < (duration + 30);
        });
        const slotReservations = Database.schema.slot_reservations || [];
        const isReserved = slotReservations.some(r => 
          r.trainer_id === coach.id && 
          normalizeDate(r.slot_date) === normalizedDateStr && 
          canonicalizeTimeRange(r.slot_time) === canonicalizeTimeRange(slot.time) && 
          r.client_id !== user.id
        );

        if (!hasBooking && !hasBufferConflict && !isReserved) {
          if (!aggregatedSlotsMap[slot.time]) {
            aggregatedSlotsMap[slot.time] = { slot, trainers: [] };
          }
          aggregatedSlotsMap[slot.time].trainers.push(coach);
        }
      }
    }

    return Object.keys(aggregatedSlotsMap).map(time => {
      const { slot, trainers } = aggregatedSlotsMap[time];
      return {
        time,
        tag: slot.isPrime ? 'Prime Time' : '',
        isPrime: slot.isPrime,
        trainers: trainers.map(t => t.id)
      };
    });
  };

  const handleSelectGoogleSuggestion = async (suggestion: AutocompleteSuggestion) => {
    setIsSearchingLocation(true);
    setGoogleSuggestions([]);
    setShowSearchDropdown(false);
    try {
      const details = await fetchGooglePlaceDetails(suggestion.placeId);
      
      // Increment request counter and clear timers to prevent map pan geocodes from overwriting
      geocodeRequestCounterRef.current++;
      if (reverseGeocodeTimerRef.current) {
        clearTimeout(reverseGeocodeTimerRef.current);
      }
      setIsReverseGeocoding(false);

      setActiveCoords({ lat: details.latitude, lng: details.longitude });
      setSearchQuery(details.address);
      setPlaceId(suggestion.placeId || '');
      setHasConfirmedSearchSelection(true);
      setIsPinSelectionAuthoritative(false);
      
      let finalBuildingName = details.placeName || splitAddress(details.address).main;
      const isGenericName = !finalBuildingName || 
                            finalBuildingName === 'Selected Location' ||
                            /^\d/.test(finalBuildingName) ||
                            finalBuildingName.includes('°') ||
                            ['andheri west', 'mumbai suburban', 'mumbai', 'maharashtra', 'juhu', 'bandra west', 'bandra', 'colaba', 'powai'].includes(finalBuildingName.toLowerCase()) ||
                            /\b(road|rd|lane|nagar|gali|marg|street|st)\b/i.test(finalBuildingName);
      
      if (isGenericName) {
        const resolved = await resolveExactLocation(details.latitude, details.longitude, details.address, undefined);
        finalBuildingName = resolved.buildingName;
      }
      
      setResolvedPlaceName(finalBuildingName);
      setIsMapConfirmed(false);
      setGpsAccuracy(null);
      
      const centerMumbai = { lat: 19.0176, lng: 72.8164 };
      const dist = calculateDistanceKm(details.latitude, details.longitude, centerMumbai.lat, centerMumbai.lng);
      setDistanceText(`${dist.toFixed(1)} km`);
      setEtaText(`~${Math.round(dist * 2.5 + 5)} mins`);
      setIsLocationOutsideCoverage(dist > 30);

      // Animate map to coordinates
      mapRef.current?.animateToRegion({
        latitude: details.latitude,
        longitude: details.longitude,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005
      }, 800);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to load details.');
    } finally {
      setIsSearchingLocation(false);
    }
  };

  const handleUseCurrentGps = async () => {
    setIsSearchingLocation(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        throw new Error('Location permission was denied. Please allow location access in settings or enter your address manually.');
      }
      
      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced
      });
      const { latitude, longitude, accuracy } = loc.coords;
      setGpsAccuracy(accuracy || null);

      const res = await reverseGeocodeCoords(latitude, longitude);

      // Increment request counter and clear timers to prevent map pan geocodes from overwriting
      geocodeRequestCounterRef.current++;
      if (reverseGeocodeTimerRef.current) {
        clearTimeout(reverseGeocodeTimerRef.current);
      }
      setIsReverseGeocoding(false);

      setActiveCoords({ lat: latitude, lng: longitude });
      setSearchQuery(res.address);
      setPlaceId(res.placeId || '');
      setHasConfirmedSearchSelection(false);
      setIsPinSelectionAuthoritative(true);
      
      const resolved = await resolveExactLocation(latitude, longitude, res.address, res.results);
      setResolvedPlaceName(resolved.buildingName);
      setIsMapConfirmed(false);
      
      const centerMumbai = { lat: 19.0176, lng: 72.8164 };
      const dist = calculateDistanceKm(latitude, longitude, centerMumbai.lat, centerMumbai.lng);
      setDistanceText(`${dist.toFixed(1)} km`);
      setEtaText(`~${Math.round(dist * 2.5 + 5)} mins`);
      setIsLocationOutsideCoverage(dist > 30);

      // Animate map to current location coordinates
      mapRef.current?.animateToRegion({
        latitude,
        longitude,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005
      }, 800);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to resolve current location.');
    } finally {
      setIsSearchingLocation(false);
    }
  };

  const handleSelectSlot = useCallback((slotTime: string, eligibleTrainerIds: string[]) => {
    setSelectedTime(slotTime);
    const tempBooking = {
      id: 'temp-id',
      workoutTitle: (() => {
        switch (selectedExperience.id) {
          case 'exp-strength': return 'PowerForge';
          case 'exp-flow': return 'ZenFlow';
          case 'exp-rhythm': return 'RhythmX';
          case 'exp-reset': return 'KinetiX';
          case 'exp-combat': return 'FightLab';
          case 'exp-aerial': return 'ZenFlow Aerial';
          default: return 'PowerForge';
        }
      })(),
      date: selectedDate,
      time: slotTime,
      address: (() => {
        const addr = addresses.find(a => a.id === selectedAddressId);
        if (!addr) return 'Selected Location';
        const jsonPayload = {
          addressLine: addr.addressLine || '',
          lat: addr.lat,
          lng: addr.lng,
          place_id: addr.placeId || '',
          buildingName: addr.building || '',
          flatNumber: addr.apartment || '',
          floor: addr.floor || '',
          landmark: addr.landmark || '',
          arrivalInstructions: addr.notes || ''
        };
        return JSON.stringify(jsonPayload);
      })(),
      timelineStatus: 'booked' as const,
      status: 'upcoming' as const,
      createdAt: Date.now()
    };
    const rated = AssignmentEngine.rankTrainers(tempBooking as any);
    const matched = rated.find(rt => eligibleTrainerIds.includes(rt.coach.id));
    if (matched) {
      setMatchedCoach(matched.coach);
    } else {
      const coach = coaches.find(c => eligibleTrainerIds.includes(c.id));
      if (coach) setMatchedCoach(coach);
    }
  }, [selectedExperience, selectedDate, addresses, selectedAddressId, coaches]);

  const handleReleaseReservation = async () => {
    if (reservationId) {
      await Database.releaseSlot(reservationId);
      setReservationId('');
      setReservationTimeLeft(0);
    }
  };

  useEffect(() => {
    let timer: any;
    if (reservationTimeLeft > 0) {
      timer = setInterval(() => {
        setReservationTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            handleReleaseReservation();
            Alert.alert('Reservation Expired ⚠️', 'Your temporary slot holding time has expired. Please re-select the slot.');
            setStep(5);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [reservationTimeLeft, reservationId]);

  useEffect(() => {
    return () => {
      if (reservationId) {
        Database.releaseSlot(reservationId);
      }
    };
  }, [reservationId]);

  // Initial workout matching logic for Sprint 3 compatibility
  useEffect(() => {
    const searchString = [initialWorkoutId, initialWorkoutType, initialWorkoutName]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    if (searchString) {
      let matchedExp = EXPERIENCES[0];
      if (
        searchString.includes('aerial') ||
        searchString.includes('hammock') ||
        searchString.includes('w-aerial')
      ) {
        matchedExp = EXPERIENCES[5];
      } else if (
        searchString.includes('yoga') || 
        searchString.includes('flow') || 
        searchString.includes('pilates') || 
        searchString.includes('mind & body') || 
        searchString.includes('w-2') || 
        searchString.includes('w-3')
      ) {
        matchedExp = EXPERIENCES[1];
      } else if (
        searchString.includes('dance') || 
        searchString.includes('rhythm') || 
        searchString.includes('cardio') || 
        searchString.includes('w-4')
      ) {
        matchedExp = EXPERIENCES[2];
      } else if (
        searchString.includes('stretch') || 
        searchString.includes('recovery') || 
        searchString.includes('reset') || 
        searchString.includes('mobility') || 
        searchString.includes('w-5')
      ) {
        matchedExp = EXPERIENCES[3];
      } else if (
        searchString.includes('boxing') || 
        searchString.includes('combat') || 
        searchString.includes('kickboxing') || 
        searchString.includes('w-8')
      ) {
        matchedExp = EXPERIENCES[4];
      }
      setSelectedExperience(matchedExp);
    }
  }, [initialWorkoutId, initialWorkoutType, initialWorkoutName]);

  useEffect(() => {

    if (step === 3 && selectedAddressId) {
      const addr = addresses.find(a => a.id === selectedAddressId);
      if (addr) {
        if (addr.lat !== undefined && addr.lng !== undefined && addr.lat !== 0 && addr.lng !== 0) {
          setActiveCoords({ lat: addr.lat, lng: addr.lng });
          const centerMumbai = { lat: 19.0176, lng: 72.8164 };
          const dist = calculateDistanceKm(addr.lat, addr.lng, centerMumbai.lat, centerMumbai.lng);
          setDistanceText(`${dist.toFixed(1)} km`);
          setEtaText(`~${Math.round(dist * 2.5 + 5)} mins`);
          setIsLocationOutsideCoverage(dist > 30);
        } else {
          const lower = addr.addressLine.toLowerCase();
          if (lower.includes('pune') || lower.includes('delhi') || lower.includes('bangalore') || lower.includes('kolkata')) {
            setIsLocationOutsideCoverage(true);
            setEtaText('N/A (Out of bounds)');
            setDistanceText('> 100 km');
          } else if (lower.includes('juhu')) {
            setIsLocationOutsideCoverage(false);
            setEtaText('~18 mins travel');
            setDistanceText('6.5 km');
            setActiveCoords({ lat: 19.1076, lng: 72.8264 });
          } else if (lower.includes('bandra')) {
            setIsLocationOutsideCoverage(false);
            setEtaText('~12 mins travel');
            setDistanceText('3.2 km');
            setActiveCoords({ lat: 19.0596, lng: 72.8295 });
          } else if (lower.includes('worli')) {
            setIsLocationOutsideCoverage(false);
            setEtaText('~15 mins travel');
            setDistanceText('4.1 km');
            setActiveCoords({ lat: 18.9986, lng: 72.8174 });
          } else {
            setIsLocationOutsideCoverage(false);
            setEtaText('~15 mins travel');
            setDistanceText('4.2 km');
            setActiveCoords({ lat: 19.0176, lng: 72.8164 });
          }
        }
      }
    }
  }, [selectedAddressId, step, addresses]);

  const [isLoadingAvailability, setIsLoadingAvailability] = useState(false);

  const loadAvailabilityForSelectedDate = useCallback(async (dateStr: string) => {
    setIsLoadingAvailability(true);
    try {
      console.log(`[AVAILABILITY] Loading availability for date: ${dateStr}`);
      await Database.reload();
      useCoachStore.getState().syncFromDB();
      useBookingStore.getState().syncFromDB();
      useAddressStore.getState().syncFromDB();
    } catch (err) {
      console.warn('Failed to reload database for availability:', err);
    } finally {
      setIsLoadingAvailability(false);
    }
  }, []);

  // Pulse animation for radar scanning map
  useEffect(() => {

    if (step === 3) {
      radarAnim.setValue(0);
      Animated.loop(
        Animated.timing(radarAnim, {
          toValue: 1,
          duration: 3000,
          useNativeDriver: true,
        })
      ).start();
    }
  }, [step, radarAnim]);

  // Step transitions
  const triggerTransition = (nextStep: number) => {
    Animated.sequence([
      Animated.timing(slideAnim, {
        toValue: -10,
        duration: 120,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 10,
        duration: 0,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 180,
        useNativeDriver: true,
      })
    ]).start();
    
    if (nextStep === 6) {
      const activeCoach = matchedCoach || coaches[0];
      if (activeCoach) {
        Database.reserveSlot(user.id, activeCoach.id, selectedDate, selectedTime).then(resId => {
          if (resId) {
            setReservationId(resId);
            setReservationTimeLeft(300); // 5 mins countdown
            setStep(6);
          } else {
            Alert.alert('Slot Unavailable ⚠️', 'That slot has just been reserved by another user. Please choose another time.');
            setStep(5);
          }
        }).catch(() => {
          setStep(5);
        });
        return;
      }
    }

    setStep(nextStep);
  };

  const handleNext = () => {
    if (step === 1 && !selectedExperience) {
      Alert.alert('Selection Required', 'Please select a training experience.');
      return;
    }
    if (step === 2 && trainerPref === 'favourite' && !selectedTrainerId) {
      const favouritesExist = coaches.some(c => c.isFavourite);
      if (favouritesExist) {
        Alert.alert('Selection Required', 'Please select one of your favorite coaches.');
        return;
      }
      // If none exist, they are stuck, let them change preference
      Alert.alert('Preference Required', 'Please choose another trainer preference.');
      return;
    }
    if (step === 3) {
      if (!selectedAddressId) {
        Alert.alert('Location Required', 'Please choose a training address.');
        return;
      }
      if (isLocationOutsideCoverage) {
        Alert.alert('Outside Coverage', 'The selected address lies outside the VIRLA active fitness coverage zone.');
        return;
      }
      // Navigate to step 4 (Select Date) with Today selected by default
      setDateSelectionType('today');
      setShowCalendarPicker(false);
      const istNow = getCurrentServerTime();
      const info = getISTDateInfo(istNow);
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const formatted = `${months[info.month - 1]} ${info.day}, ${info.year}`;
      setSelectedDate(formatted);
      triggerTransition(4);
      loadAvailabilityForSelectedDate(formatted);
      return;
    }
    if (step === 4) {
      if (!selectedDate) {
        Alert.alert('Date Required', 'Please select a date.');
        return;
      }
      triggerTransition(5);
      return;
    }
    if (step === 5) {
      if (!selectedTime) {
        Alert.alert('Time Required', 'Please select a time slot.');
        return;
      }
      // Synchronously finalize coach match when transitioning to step 6
      finalizeMatch();
    }
    triggerTransition(step + 1);
  };

  const handleBack = () => {
    if (step === 6) {
      handleReleaseReservation();
    }
    if (step > 1) {
      triggerTransition(step - 1);
    } else {
      if (router.canGoBack()) {
        router.back();
      } else {
        router.replace('/(tabs)');
      }
    }
  };

  // Matchmaker simulation trigger
  const startMatchmaker = () => {
    setMatchStage(0);
    setMatchDone(false);
    
    const interval = setInterval(() => {
      setMatchStage((prev) => {
        if (prev >= 4) {
          clearInterval(interval);
          finalizeMatch();
          return 5;
        }
        return prev + 1;
      });
    }, 600);
  };

  const finalizeMatch = () => {
    // Check favourite trainer mismatch conflict if applicable
    if (trainerPref === 'favourite' && selectedTrainerId) {
      const fav = coaches.find(c => c.id === selectedTrainerId);
      if (fav) {
        const favGender = (fav.gender || '').toLowerCase();
        const clientPref = (Database.getProfile(user.id || '')?.trainerPreference || 'no_preference').toLowerCase();
        
        if ((clientPref === 'male' && favGender !== 'male') || (clientPref === 'female' && favGender !== 'female')) {
          Alert.alert(
            'Preference Mismatch ⚠️',
            'Your selected Trainer does not match your Trainer preference. Please choose another Trainer or update your preference.',
            [{ text: 'OK', onPress: () => setStep(2) }]
          );
          setMatchedCoach(undefined as any);
          setMatchDone(false);
          return;
        }
      }
    }

    // Select coach based on preference and workout specialty
    let pool = coaches;

    // Filter by gender if requested
    if (trainerPref === 'female') {
      pool = pool.filter(c => (c.gender || '').toLowerCase() === 'female');
    } else if (trainerPref === 'male') {
      pool = pool.filter(c => (c.gender || '').toLowerCase() === 'male');
    } else if (trainerPref === 'favourite') {
      const clientPref = (Database.getProfile(user.id || '')?.trainerPreference || 'no_preference').toLowerCase();
      if (clientPref === 'male') {
        pool = pool.filter(c => (c.gender || '').toLowerCase() === 'male');
      } else if (clientPref === 'female') {
        pool = pool.filter(c => (c.gender || '').toLowerCase() === 'female');
      }
    }

    // Filter by specialty if applicable
    let specFilter = 'Strength';
    if (selectedExperience.id === 'exp-flow') specFilter = 'Yoga';
    if (selectedExperience.id === 'exp-rhythm') specFilter = 'Dance';
    if (selectedExperience.id === 'exp-reset') specFilter = 'Mobility';
    if (selectedExperience.id === 'exp-combat') specFilter = 'Boxing';
    if (selectedExperience.id === 'exp-aerial') specFilter = 'Aerial Yoga';

    let specialtyPool = pool.filter(c => c.specialty.includes(specFilter) || c.workoutSpecialties?.some(s => s.includes(specFilter)));
    if (specialtyPool.length === 0) {
      if (selectedExperience.id === 'exp-aerial') {
        Alert.alert('No Trainers Available ⚠️', 'No certified Aerial Yoga trainers are currently available in your area.');
        setStep(2);
        setMatchedCoach(undefined as any);
        setMatchDone(false);
        return;
      }
      specialtyPool = pool;
    }

    // Pick specific coach
    let finalCoach = specialtyPool[0];
    if (trainerPref === 'favourite' && selectedTrainerId) {
      const fav = coaches.find(c => c.id === selectedTrainerId);
      if (fav) finalCoach = fav;
    }

    // Fallback if somehow undefined
    if (!finalCoach) finalCoach = coaches[0];

    setMatchedCoach(finalCoach);
    setMatchDone(true);
  };

  // Legacy add address handler removed in favor of Step 3 Redesign Add Address wizard modal

  const handleConfirmBooking = () => {
    if (isConfirming) return;
    setIsConfirming(true);

    const targetAddress = (() => {
      const addr = addresses.find(a => a.id === selectedAddressId);
      if (!addr) return 'Selected Location';
      const jsonPayload = {
        addressLine: addr.addressLine || '',
        lat: addr.lat,
        lng: addr.lng,
        place_id: addr.placeId || '',
        buildingName: addr.building || '',
        flatNumber: addr.apartment || '',
        floor: addr.floor || '',
        landmark: addr.landmark || '',
        arrivalInstructions: addr.notes || ''
      };
      return JSON.stringify(jsonPayload);
    })();
    const activeCoach = matchedCoach || coaches[0];

    if (!activeCoach) {
      Alert.alert('Selection Error', 'No matching trainer selected.');
      setIsConfirming(false);
      return;
    }

    const clientProfile = Database.getProfile(user.id || '');
    const isCouple = (clientProfile?.membershipStatus || '').toLowerCase().includes('couple');

    const tempBooking = {
      trainerId: activeCoach.id,
      trainerName: activeCoach.name,
      trainerPhoto: activeCoach.photo,
      workoutTitle: (() => {
        switch (selectedExperience.id) {
          case 'exp-strength': return 'PowerForge';
          case 'exp-flow': return 'ZenFlow';
          case 'exp-rhythm': return 'RhythmX';
          case 'exp-reset': return 'KinetiX';
          case 'exp-combat': return 'FightLab';
          case 'exp-aerial': return 'ZenFlow Aerial';
          default: return 'PowerForge';
        }
      })(),
      date: selectedDate,
      time: selectedTime,
      price: activeCoach.price || 1200,
      address: targetAddress,
      goal: selectedExperience.title,
      trainerLevel: activeCoach.level || 'Certified',
      trainerRating: activeCoach.rating,
      trainerCompletedSessions: activeCoach.completedSessions || 150,
      trainerSpeciality: activeCoach.specialty,
      trainerLanguages: activeCoach.languages,
      trainerDistance: `${(1.5 + Math.random() * 2).toFixed(1)} km`,
      trainerArrivalTime: `${Math.round(10 + Math.random() * 10)} mins`,
      assignedTrainersPool: [activeCoach.id],
      currentTrainerIndex: 0,
      trainerNote: trainerNote.trim() || undefined,
      durationMinutes: selectedExperience.duration || 60,
      createdAt: Date.now(),
      participantCount: isCouple ? 2 : 1,
      sessionType: (isCouple ? 'COUPLE' : 'SINGLE') as 'SINGLE' | 'COUPLE',
      originalPackageType: (isCouple ? 'COUPLE' : 'SINGLE') as 'SINGLE' | 'COUPLE',
    };

    setTimeout(async () => {
      try {
        // Enforce mid-flow slot availability check before confirmation
        const freshCoaches = Database.getCoaches();
        const freshCoach = freshCoaches.find(c => c.id === activeCoach.id);
        
        const overrides = freshCoach?.preferences?.availabilityOverrides || [];
        const override = overrides.find(o => 
          normalizeDate(o.date) === normalizeDate(selectedDate) && 
          canonicalizeTimeRange(o.time) === canonicalizeTimeRange(selectedTime)
        );
        const isAvailable = override ? override.isAvailable : true;
        
        const bookings = Database.schema.bookings || [];
        const isBooked = bookings.some((b: any) => 
          b.trainerId === activeCoach.id && 
          normalizeDate(b.date) === normalizeDate(selectedDate) && 
          canonicalizeTimeRange(b.time) === canonicalizeTimeRange(selectedTime) && 
          b.status === 'upcoming'
        );
        
        if (!isAvailable || isBooked) {
          throw new Error('This slot is no longer available. Please select another slot.');
        }

        // Call transactional add with validations
        const finalBooking = await Database.addBookingWithValidation(user.id, tempBooking);
        
        // Sync stores
        useBookingStore.getState().syncFromDB();

        // Release temporary reservation
        handleReleaseReservation();

        // Trigger notifications
        addNotification({
          title: 'Booking Confirmed 📅',
          body: `Your VIRLA ${selectedExperience.title} session is confirmed for ${selectedDate} @ ${selectedTime}. Waiting for Trainer Confirmation.`,
        });

        setSuccessBookingId(finalBooking.id);
        setStep(7);
      } catch (err: any) {
        Alert.alert('Booking Failed ⚠️', err.message || 'Unable to complete your booking. Please try again.');
      } finally {
        setIsConfirming(false);
      }
    }, 1800);
  };

  interface SlotItem {
    time: string;
    tag: string;
    isPrime: boolean;
    isBooked?: boolean;
    trainers?: string[];
  }

  const isTimeSlotPassed = (timeSlotStr: string, dateStr: string) => {
    const istNow = getCurrentServerTime();
    const info = getISTDateInfo(istNow);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const todayStr = `${months[info.month - 1]} ${info.day}, ${info.year}`;
    if (dateStr !== todayStr) {
      return false;
    }

    const startTimePart = timeSlotStr.split(' - ')[0]; // e.g. "06:00 AM"
    const [timeVal, modifier] = startTimePart.split(' '); // ["06:00", "AM"]
    let [hours, minutes] = timeVal.split(':').map(Number);

    if (modifier === 'PM' && hours < 12) {
      hours += 12;
    }
    if (modifier === 'AM' && hours === 12) {
      hours = 0;
    }

    const slotDateTime = new Date(Date.UTC(info.year, info.month - 1, info.day, hours, minutes, 0, 0));
    const slotTimeMs = slotDateTime.getTime() - 5.5 * 60 * 60 * 1000;

    return slotTimeMs <= istNow.getTime();
  };

  const getFilteredSlotsForPeriod = (): SlotItem[] => {
    const allAvailable = getDynamicAvailableSlots();
    const todayNormalized = normalizeDate(getCurrentServerTime());
    if (normalizeDate(selectedDate) === todayNormalized) {
      return allAvailable.filter(slot => !isTimeSlotPassed(slot.time, selectedDate));
    }
    return allAvailable;
  };

  const renderBadge = (slotObj: any) => {
    if (slotObj.isBooked) {
      return (
        <View className="bg-zinc-100 border border-zinc-200 px-2.5 py-1 rounded-full flex-row items-center gap-1">
          <Text className="text-zinc-500 text-[9px] font-black uppercase tracking-wider">⛔ Fully Booked</Text>
        </View>
      );
    }
    if (slotObj.tag === 'High Demand') {
      return (
        <View className="bg-red-50 border border-red-100 px-2.5 py-1 rounded-full flex-row items-center gap-1">
          <Text className="text-red-500 text-[9px] font-black uppercase tracking-wider">🔥 High Demand</Text>
        </View>
      );
    }
    if (slotObj.tag === 'Almost Full' || slotObj.tag === 'Only 2 left' || slotObj.tag === 'Only 1 left') {
      return (
        <View className="bg-amber-50 border border-amber-100 px-2.5 py-1 rounded-full flex-row items-center gap-1">
          <Text className="text-amber-600 text-[9px] font-black uppercase tracking-wider">⚠ Only 2 Left</Text>
        </View>
      );
    }
    if (slotObj.isPrime) {
      return (
        <View className="bg-indigo-50 border border-indigo-100 px-2.5 py-1 rounded-full flex-row items-center gap-1">
          <Text className="text-indigo-600 text-[9px] font-black uppercase tracking-wider">⭐ Prime Time</Text>
        </View>
      );
    }
    return null;
  };

  const getWorkoutImage = (id: string) => {
    switch (id) {
      case 'exp-strength':
        return 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80';
      case 'exp-flow':
        return 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=800&q=80';
      case 'exp-rhythm':
        return 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=80';
      case 'exp-reset':
        return 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?auto=format&fit=crop&w=800&q=80';
      case 'exp-combat':
        return 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&w=800&q=80';
      case 'exp-aerial':
        return 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=800&q=80';
      default:
        return 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80';
    }
  };

  const getFormattedDateLabel = () => {
    return formatToDDMMYYYY(selectedDate);
  };

  const handleChipPress = (chip: string) => {
    if (chip === 'Other') {
      noteInputRef.current?.focus();
      return;
    }
    setTrainerNote((prev) => {
      const trimmed = prev.trim();
      if (prev.includes(chip)) {
        const regex = new RegExp(`\\s*${chip},?\\s*|\\s*,?\\s*${chip}`, 'g');
        let next = prev.replace(regex, '').trim();
        next = next.replace(/,\s*,/g, ',').replace(/^,|,$/g, '').trim();
        return next;
      } else {
        if (trimmed.length === 0) {
          return chip;
        }
        const suffix = `, ${chip}`;
        if (trimmed.length + suffix.length <= 250) {
          return `${trimmed}${suffix}`;
        }
        return prev;
      }
    });
  };


  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#F7F8FC' }}>
      {/* Header back button */}
      <View className={`border-b border-[#E5E7EB] bg-white ${step === 6 ? 'py-3 px-6 flex-row items-center justify-between' : 'h-14 flex-row items-center px-6'}`}>
        {step < 7 ? (
          <TouchableOpacity onPress={handleBack} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }} className="w-8 h-8 items-center justify-center">
            <Ionicons name="arrow-back" size={20} color="#101828" />
          </TouchableOpacity>
        ) : (
          <View className="w-8" />
        )}
        {step === 6 ? (
          <View className="flex-1 items-center mr-8">
            <Text className="text-[#101828] text-base font-black tracking-tight">Review & Confirm Booking</Text>
            <Text className="text-[#6B7280] text-[9px] font-semibold mt-0.5">Please review your session details before confirming</Text>
          </View>
        ) : (
          <Text className="flex-1 text-center text-[#101828] text-sm font-black uppercase tracking-wider mr-8">
            {step <= 5 ? `Step ${step} of 5` : 'Success'}
          </Text>
        )}
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
      >
        <View style={{ flex: 1, backgroundColor: '#F7F8FC' }}>
          {step <= 7 ? (
          <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }} contentContainerStyle={{ padding: 24, paddingBottom: 100 }}>
            <View className="gap-6">
              
              {/* STEP 1: EXPERIENCE SELECTOR */}
              {step === 1 && (
                <View className="gap-5">
                  <View>
                    <Text className="text-[#6B7280] text-[10px] font-black uppercase tracking-widest">Training Experience</Text>
                    <Text className="text-[#101828] text-2xl font-black tracking-tight mt-1">Choose Workout Experience</Text>
                  </View>

                  <View className="gap-4">
                    {EXPERIENCES.map((exp) => {
                      const isSelected = selectedExperience.id === exp.id;
                      return (
                        <TouchableOpacity
                          key={exp.id}
                          activeOpacity={0.9}
                          onPress={() => {
                            setSelectedExperience(exp);
                            setTimeout(() => triggerTransition(2), 250);
                          }}
                          className={`p-5 rounded-[28px] border flex-row items-center justify-between ${
                            isSelected 
                              ? 'bg-zinc-950 border-zinc-950' 
                              : 'bg-white border-[#E5E7EB]'
                          }`}
                          style={{
                            shadowColor: '#101828',
                            shadowOffset: { width: 0, height: isSelected ? 4 : 1 },
                            shadowOpacity: isSelected ? 0.08 : 0.02,
                            shadowRadius: isSelected ? 8 : 2,
                            elevation: isSelected ? 3 : 1,
                          }}
                        >
                          <View className="flex-row items-center gap-4 flex-1">
                            <View 
                              style={{ 
                                backgroundColor: exp.gradientColors[0],
                                shadowColor: '#101828',
                                shadowOffset: { width: 0, height: 1 },
                                shadowOpacity: 0.02,
                                shadowRadius: 2,
                                elevation: 1,
                              }} 
                              className="w-12 h-12 rounded-2xl items-center justify-center"
                            >
                              <Text className="text-xl">{exp.emoji}</Text>
                            </View>
                            <View className="flex-1">
                              <Text className={`text-sm font-black tracking-tight ${isSelected ? 'text-white' : 'text-[#101828]'}`}>
                                {exp.title}
                              </Text>
                              <Text className={`text-[10px] font-bold mt-1 leading-relaxed ${isSelected ? 'text-zinc-400' : 'text-[#6B7280]'}`}>
                                {exp.description}
                              </Text>
                            </View>
                          </View>
                          {isSelected && (
                            <View className="w-5 h-5 rounded-full bg-indigo-500 items-center justify-center">
                              <Feather name="check" size={12} color="white" />
                            </View>
                          )}
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </View>
              )}

              {/* STEP 2: TRAINER PREFERENCE */}
              {step === 2 && (
                <View className="gap-5">
                  <View>
                    <Text className="text-[#6B7280] text-[10px] font-black uppercase tracking-widest">Concierge Match</Text>
                    <Text className="text-[#101828] text-2xl font-black tracking-tight mt-1">Trainer Preference</Text>
                  </View>

                  <View className="flex-row flex-wrap justify-between gap-y-4">
                    {[
                      { id: 'any', label: 'No Preference', icon: 'shuffle', desc: 'Any expert match' },
                      { id: 'female', label: 'Female Trainer', icon: 'smile', desc: 'Match female coach' },
                      { id: 'male', label: 'Male Trainer', icon: 'user', desc: 'Match male coach' },
                      { id: 'favourite', label: 'Favourite Trainer', icon: 'heart', desc: 'Choose saved favorites' }
                    ].map((pref) => {
                      const isSelected = trainerPref === pref.id;
                      return (
                        <TouchableOpacity
                          key={pref.id}
                          activeOpacity={0.8}
                          onPress={() => {
                            setTrainerPref(pref.id as any);
                            if (pref.id !== 'favourite') {
                              setSelectedTrainerId('');
                              if (user.id) {
                                const dbPref = pref.id === 'any' ? 'no_preference' : pref.id;
                                Database.updateProfile(user.id, { trainerPreference: dbPref });
                                useUserStore.getState().syncFromDB();
                              }
                              // Auto transition to step 3 on tap after small delay
                              setTimeout(() => triggerTransition(3), 300);
                            }
                          }}
                          className={`w-[47%] p-5 rounded-[24px] border items-center justify-center gap-2.5 ${
                            isSelected ? 'bg-zinc-950 border-zinc-950' : 'bg-white border-[#E5E7EB]'
                          }`}
                          style={{
                            shadowColor: '#101828',
                            shadowOffset: { width: 0, height: 1 },
                            shadowOpacity: 0.02,
                            shadowRadius: 2,
                            elevation: 1,
                          }}
                        >
                          <Feather name={pref.icon as any} size={20} color={isSelected ? '#F59E0B' : '#6B7280'} />
                          <View className="items-center">
                            <Text className={`text-xs font-black tracking-tight text-center ${isSelected ? 'text-white' : 'text-[#101828]'}`}>
                              {pref.label}
                            </Text>
                            <Text className={`text-[8px] text-center font-bold mt-1 ${isSelected ? 'text-zinc-500' : 'text-[#9CA3AF]'}`}>
                              {pref.desc}
                            </Text>
                          </View>
                        </TouchableOpacity>
                      );
                    })}
                  </View>

                  {/* Favourites Section */}
                  {trainerPref === 'favourite' && (
                    <View className="mt-4 gap-3">
                      <Text className="text-[#101828] text-xs font-black uppercase tracking-wider pl-1">Select Favorite Coach</Text>
                      {coaches.filter(c => c.isFavourite).length > 0 ? (
                        coaches.filter(c => c.isFavourite).map((coach) => {
                          const isSelected = selectedTrainerId === coach.id;
                          return (
                            <TouchableOpacity
                              key={coach.id}
                              activeOpacity={0.8}
                              onPress={() => {
                                setSelectedTrainerId(coach.id);
                                setTimeout(() => triggerTransition(3), 250);
                              }}
                              className={`p-4 rounded-2xl border flex-row items-center justify-between ${
                                isSelected ? 'bg-indigo-50/50 border-indigo-500' : 'bg-white border-[#E5E7EB]'
                              }`}
                            >
                              <View className="flex-row items-center gap-3">
                                <Image source={{ uri: coach.photo }} className="w-10 h-10 rounded-full" />
                                <View>
                                  <Text className="text-[#101828] text-xs font-black">{coach.name}</Text>
                                  <Text className="text-[#6B7280] text-[9px] font-bold mt-0.5">{coach.specialty} • ⭐ {coach.rating}</Text>
                                </View>
                              </View>
                              {isSelected ? (
                                <View className="w-4 h-4 rounded-full bg-[#4F46E5] items-center justify-center">
                                  <Feather name="check" size={10} color="white" />
                                </View>
                              ) : (
                                <View className="w-4 h-4 rounded-full border border-zinc-300" />
                              )}
                            </TouchableOpacity>
                          );
                        })
                      ) : (
                        <EmptyState type="no-favourite-trainer" />
                      )}
                    </View>
                  )}
                </View>
              )}

              {/* STEP 3: LOCATION & MAP */}
              {step === 3 && (
                <View className="gap-5">
                  <View>
                    <Text className="text-[#6B7280] text-[10px] font-black uppercase tracking-widest">Training Venue</Text>
                    <Text className="text-[#101828] text-2xl font-black tracking-tight mt-1">Select Training Location</Text>
                    <Text className="text-zinc-500 text-xs font-semibold mt-1">
                      Choose where your VIRLA Wellness Coach should visit.
                    </Text>
                  </View>

                  {/* Saved Locations List */}
                  <View className="gap-3.5">
                    {addresses.map((addr) => {
                      const isSelected = selectedAddressId === addr.id;
                      // Display dynamic mock ETA/distance for address cards context
                      let cardEta = '12–15 mins';
                      if (((addr.building || '') || '').toLowerCase().includes('worli')) cardEta = '18–22 mins';
                      if (((addr.building || '') || '').toLowerCase().includes('juhu')) cardEta = '15–18 mins';
                      if (((addr.building || '') || '').toLowerCase().includes('bandra')) cardEta = '10–12 mins';

                      return (
                        <TouchableOpacity
                          key={addr.id}
                          activeOpacity={0.9}
                          onPress={() => {
                            setSelectedAddressId(addr.id);
                            // Auto transition to step 4 on card tap after small delay
                            setTimeout(() => triggerTransition(4), 300);
                          }}
                          className={`p-5 rounded-[24px] border flex-row items-center justify-between  ${
                            isSelected 
                              ? 'bg-white border-[#E11D48]' 
                              : 'bg-white border-[#E5E7EB]'
                          }`}
                          style={{
                            shadowColor: isSelected ? '#E11D48' : '#101828',
                            shadowOffset: { width: 0, height: isSelected ? 6 : 2 },
                            shadowOpacity: isSelected ? 0.08 : 0.03,
                            shadowRadius: isSelected ? 12 : 6,
                            elevation: isSelected ? 4 : 2,
                          }}
                        >
                          <View className="flex-row items-center gap-4 flex-1">
                            <View className={`w-11 h-11 rounded-2xl items-center justify-center ${isSelected ? 'bg-rose-50' : 'bg-zinc-50'}`}>
                              <Text className="text-xl">
                                {addr.label === 'Home' ? '🏠' : addr.label === 'Office' ? '🏢' : addr.label === 'Gym' ? '🏋️' : '📍'}
                              </Text>
                            </View>
                            <View className="flex-1 gap-1">
                              <View className="flex-row items-center gap-2">
                                <Text className="text-[#101828] text-sm font-black">{addr.label}</Text>
                                {addr.isDefault && (
                                  <View className="bg-zinc-100 border border-zinc-200 px-2 py-0.5 rounded-full">
                                    <Text className="text-[#6B7280] text-[8px] font-black uppercase tracking-wider">Default</Text>
                                  </View>
                                )}
                                {isSelected && (
                                  <View className="bg-rose-50 border border-rose-100 px-2 py-0.5 rounded-full">
                                    <Text className="text-[#E11D48] text-[8px] font-black uppercase tracking-wider">Selected</Text>
                                  </View>
                                )}
                              </View>
                              <Text className="text-[#6B7280] text-xs font-semibold leading-relaxed">
                                {addr.addressLine}
                              </Text>
                              <View className="flex-row items-center gap-4 mt-1">
                                <Text className="text-green-600 text-[10px] font-bold">✓ Covered</Text>
                                <Text className="text-zinc-400 text-[10px] font-medium">• Est. arrival: {cardEta}</Text>
                              </View>
                            </View>
                          </View>

                          <View className="ml-2">
                            {isSelected ? (
                              <View className="w-6 h-6 rounded-full bg-[#E11D48] items-center justify-center">
                                <Feather name="check" size={14} color="white" />
                              </View>
                            ) : (
                              <View className="w-6 h-6 rounded-full border border-zinc-200 bg-zinc-50" />
                            )}
                          </View>
                        </TouchableOpacity>
                      );
                    })}

                    {addresses.length === 0 && (
                      <View className="p-8 rounded-[24px] border border-dashed border-[#CBD5E1] bg-white items-center justify-center gap-2">
                        <Text className="text-3xl">📍</Text>
                        <Text className="text-[#101828] text-sm font-bold">No Saved Addresses</Text>
                        <Text className="text-zinc-500 text-xs text-center">Add a training location to begin booking.</Text>
                      </View>
                    )}

                    {/* Add New Address Trigger */}
                    <TouchableOpacity
                      activeOpacity={0.8}
                      onPress={() => openAddressModal()}
                      className="p-5 rounded-[24px] border border-dashed border-[#CBD5E1] bg-[#F8FAFC] flex-row items-center justify-center gap-2"
                    >
                      <Feather name="plus" size={16} color="#475569" />
                      <Text className="text-[#475569] text-xs font-black uppercase tracking-wider">Add New Address</Text>
                    </TouchableOpacity>
                  </View>

                  {/* Compact Service Availability card */}
                  {selectedAddressId ? (
                    !isLocationOutsideCoverage ? (
                      <View className="bg-emerald-50 border border-emerald-100 p-5 rounded-[24px] flex-row items-center gap-4">
                        <View className="w-10 h-10 rounded-full bg-emerald-100 items-center justify-center">
                          <Feather name="check-circle" size={20} color="#059669" />
                        </View>
                        <View className="flex-1 gap-0.5">
                          <Text className="text-emerald-800 text-xs font-black uppercase tracking-wider">🟢 Service Available</Text>
                          <Text className="text-emerald-700 text-xs font-semibold">Your location is within the VIRLA service area.</Text>
                          
                          <View className="flex-row gap-6 mt-2">
                            <View>
                              <Text className="text-zinc-500 text-[8px] font-bold uppercase">Estimated Trainer Arrival</Text>
                              <Text className="text-zinc-900 text-xs font-extrabold">{etaText}</Text>
                            </View>
                            <View>
                              <Text className="text-zinc-500 text-[8px] font-bold uppercase">Coverage Status</Text>
                              <Text className="text-zinc-900 text-xs font-extrabold">Available</Text>
                            </View>
                          </View>
                        </View>
                      </View>
                    ) : (
                      <View className="bg-red-50 border border-red-150 p-5 rounded-[24px] gap-3">
                        <View className="flex-row items-center gap-3">
                          <View className="w-10 h-10 rounded-full bg-red-100 items-center justify-center">
                            <Feather name="alert-triangle" size={20} color="#DC2626" />
                          </View>
                          <View className="flex-1">
                            <Text className="text-red-800 text-xs font-black uppercase tracking-wider">⚠️ Outside Service Area</Text>
                            <Text className="text-red-700 text-xs font-semibold">Sorry, VIRLA is not yet available in this area.</Text>
                          </View>
                        </View>
                        <Text className="text-zinc-500 text-xs leading-relaxed pl-1">
                          Join our waitlist and we&apos;ll notify you when we launch here.
                        </Text>
                        <TouchableOpacity
                          activeOpacity={0.8}
                          onPress={() => Alert.alert('Waitlist Joined', 'Thank you! We will notify you as soon as VIRLA launches in your area.')}
                          className="bg-red-600 h-11 rounded-xl items-center justify-center self-start px-6"
                        >
                          <Text className="text-white text-xs font-black uppercase tracking-wider">Notify Me</Text>
                        </TouchableOpacity>
                      </View>
                    )
                  ) : null}

                  <Modal
                    visible={isAddAddressModalVisible}
                    animationType="slide"
                    onRequestClose={() => setIsAddAddressModalVisible(false)}
                  >
                    <SafeAreaView style={{ flex: 1, backgroundColor: '#F7F8FC' }}>
                      {/* Conditional Header for Stage 2 only */}
                      {addAddressStep === 2 && (
                        <View className="h-14 flex-row items-center px-6 border-b border-[#E5E7EB] bg-white">
                          <TouchableOpacity 
                            onPress={() => setAddAddressStep(1)} 
                            className="w-8 h-8 items-center justify-center rounded-full bg-zinc-50"
                          >
                            <Ionicons name="arrow-back" size={18} color="#101828" />
                          </TouchableOpacity>
                          <Text className="flex-1 text-center text-[#101828] text-sm font-black uppercase tracking-wider mr-8">
                            Enter address details
                          </Text>
                        </View>
                      )}

                      <View style={{ flex: 1, backgroundColor: '#F7F8FC' }}>
                        {/* STAGE 1: MAP + SEARCH */}
                        {addAddressStep === 1 && (
                          <View style={{ flex: 1, position: 'relative' }}>
                            <MapView
                              ref={mapRef}
                              provider={PROVIDER_DEFAULT}
                              style={{ flex: 1 }}
                              initialRegion={{
                                latitude: activeCoords.lat,
                                longitude: activeCoords.lng,
                                latitudeDelta: 0.005,
                                longitudeDelta: 0.005,
                              }}
                              onRegionChangeComplete={(region) => {
                                // Prevent geocoding cycle if region hasn't moved meaningfully
                                const latDiff = Math.abs(region.latitude - activeCoords.lat);
                                const lngDiff = Math.abs(region.longitude - activeCoords.lng);
                                if (latDiff > 0.00005 || lngDiff > 0.00005) {
                                  if (reverseGeocodeTimerRef.current) {
                                    clearTimeout(reverseGeocodeTimerRef.current);
                                  }
                                  setIsReverseGeocoding(true);
                                  const requestId = ++geocodeRequestCounterRef.current;
                                  
                                  reverseGeocodeTimerRef.current = setTimeout(async () => {
                                    try {
                                      const res = await reverseGeocodeCoords(region.latitude, region.longitude);
                                      if (requestId !== geocodeRequestCounterRef.current) {
                                        return;
                                      }
                                      
                                      setActiveCoords({ lat: region.latitude, lng: region.longitude });
                                      setSearchQuery(res.address);
                                      setPlaceId(res.placeId || '');
                                      setHasConfirmedSearchSelection(false);
                                      setIsPinSelectionAuthoritative(true);
                                      
                                      const resolved = await resolveExactLocation(region.latitude, region.longitude, res.address, res.results);
                                      setResolvedPlaceName(resolved.buildingName);
                                      
                                      const centerMumbai = { lat: 19.0176, lng: 72.8164 };
                                      const dist = calculateDistanceKm(region.latitude, region.longitude, centerMumbai.lat, centerMumbai.lng);
                                      setDistanceText(`${dist.toFixed(1)} km`);
                                      setEtaText(`~${Math.round(dist * 2.5 + 5)} mins`);
                                      setIsLocationOutsideCoverage(dist > 30);
                                    } catch (e) {
                                      console.warn('Map settle geocode failure:', e);
                                    } finally {
                                      if (requestId === geocodeRequestCounterRef.current) {
                                        setIsReverseGeocoding(false);
                                      }
                                    }
                                  }, 800);
                                }
                              }}
                            />

                            {/* Static Central pin overlay */}
                            <View 
                              pointerEvents="none" 
                              style={{
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                marginLeft: -24,
                                marginTop: -48,
                                width: 48,
                                height: 48,
                                alignItems: 'center',
                                justifyContent: 'center',
                                zIndex: 10,
                              }}
                            >
                              <View 
                                className={`w-12 h-12 rounded-full ${
                                  isLocationOutsideCoverage ? 'bg-red-500' : 'bg-[#E11D48]'
                                } border-4 border-white items-center justify-center shadow-lg`}
                              >
                                <Feather name={isLocationOutsideCoverage ? 'alert-triangle' : 'map-pin'} size={20} color="white" />
                              </View>
                            </View>

                            {/* Floating Header Card at Top */}
                            <View 
                              style={{
                                position: 'absolute',
                                top: 12,
                                left: 16,
                                right: 16,
                                backgroundColor: 'white',
                                borderRadius: 20,
                                padding: 14,
                                zIndex: 50,
                                borderWidth: 1,
                                borderColor: '#E5E7EB',
                                shadowColor: '#101828',
                                shadowOffset: { width: 0, height: 4 },
                                shadowOpacity: 0.08,
                                shadowRadius: 10,
                                elevation: 4,
                              }}
                            >
                              {/* Back button and title */}
                              <View className="flex-row items-center mb-3">
                                <TouchableOpacity 
                                  onPress={() => setIsAddAddressModalVisible(false)} 
                                  className="w-8 h-8 items-center justify-center rounded-full bg-zinc-50"
                                >
                                  <Ionicons name="arrow-back" size={18} color="#101828" />
                                </TouchableOpacity>
                                <Text className="flex-1 text-center text-[#101828] text-xs font-black uppercase tracking-wider mr-8">
                                  Select delivery location
                                </Text>
                              </View>

                              {/* Search Input field */}
                              <View className="flex-row items-center bg-zinc-50 border border-[#E5E7EB] px-3.5 py-1.5 rounded-xl">
                                <Feather name="search" size={14} color="#6B7280" />
                                <TextInput
                                  placeholder="Search society, street, building or area..."
                                  placeholderTextColor="#9CA3AF"
                                  value={searchQuery}
                                  onChangeText={(t) => handleSearchTextChange(t)}
                                  className="flex-1 text-xs font-semibold text-zinc-900 ml-2 py-0.5"
                                />
                                {searchQuery.trim().length > 0 && (
                                  <TouchableOpacity onPress={() => handleSearchTextChange('')}>
                                    <Feather name="x" size={14} color="#9CA3AF" />
                                  </TouchableOpacity>
                                )}
                              </View>

                              {/* Dropdown list of suggestions */}
                              {showSearchDropdown && googleSuggestions.length > 0 && (
                                <View className="bg-white border-t border-zinc-100 mt-2 max-h-48 overflow-y-scroll">
                                  {googleSuggestions.map((item, idx) => (
                                    <TouchableOpacity
                                      key={idx}
                                      onPress={() => handleSelectGoogleSuggestion(item)}
                                      className="py-3 border-b border-zinc-100 flex-row justify-between items-center bg-white"
                                    >
                                      <View className="flex-1 pr-2 gap-0.5">
                                        <Text className="text-zinc-900 text-xs font-bold">
                                          {item.mainText || item.description}
                                        </Text>
                                        {!!item.secondaryText && (
                                          <Text className="text-zinc-500 text-[10px] font-semibold">
                                            {item.secondaryText}
                                          </Text>
                                        )}
                                      </View>
                                      <Feather name="arrow-up-left" size={12} color="#9CA3AF" />
                                    </TouchableOpacity>
                                  ))}
                                </View>
                              )}
                            </View>

                            {/* Floating Current Location Button */}
                            <TouchableOpacity
                              activeOpacity={0.8}
                              onPress={handleUseCurrentGps}
                              style={{
                                position: 'absolute',
                                bottom: 220,
                                right: 16,
                                width: 44,
                                height: 44,
                                borderRadius: 22,
                                backgroundColor: 'white',
                                alignItems: 'center',
                                justifyContent: 'center',
                                borderWidth: 1,
                                borderColor: '#E5E7EB',
                                shadowColor: '#101828',
                                shadowOffset: { width: 0, height: 4 },
                                shadowOpacity: 0.1,
                                shadowRadius: 8,
                                elevation: 4,
                                zIndex: 30,
                              }}
                            >
                              <Feather name="navigation" size={18} color="#4F46E5" />
                            </TouchableOpacity>

                            {/* Bottom Sheet Address Panel */}
                            <View 
                              style={{
                                position: 'absolute',
                                bottom: 16,
                                left: 16,
                                right: 16,
                                backgroundColor: 'white',
                                borderRadius: 24,
                                padding: 16,
                                borderWidth: 1,
                                borderColor: '#E5E7EB',
                                shadowColor: '#101828',
                                shadowOffset: { width: 0, height: 6 },
                                shadowOpacity: 0.1,
                                shadowRadius: 16,
                                elevation: 6,
                                zIndex: 30,
                              }}
                            >
                              <Text className="text-zinc-950 text-[10px] font-black uppercase tracking-wider text-center mb-3">
                                Resolved location
                              </Text>

                              <View className="bg-zinc-50 border border-zinc-150 p-4 rounded-xl mb-4 flex-row items-start gap-3">
                                <View className="w-8 h-8 rounded-full bg-rose-50 items-center justify-center mt-0.5">
                                  <Feather name="map-pin" size={14} color="#E11D48" />
                                </View>
                                <View className="flex-1">
                                  <Text className="text-zinc-900 text-xs font-black mb-0.5 uppercase tracking-tight">
                                    {isReverseGeocoding
                                      ? 'Locating target entrance...'
                                      : ((!hasConfirmedSearchSelection && !isPinSelectionAuthoritative) ? 'Selected location' : resolvedPlaceName)}
                                  </Text>
                                  <Text className="text-zinc-500 text-[10px] font-semibold leading-relaxed">
                                    {isReverseGeocoding
                                      ? 'Fetching address details...'
                                      : ((!hasConfirmedSearchSelection && !isPinSelectionAuthoritative) ? 'Select a location from search or move the pin on the map' : searchQuery || 'Select your location on map')}
                                  </Text>

                                  {gpsAccuracy !== null && !isReverseGeocoding && (
                                    <Text className="text-indigo-600 text-[9px] font-bold mt-1.5">
                                      🛰️ Accuracy: {gpsAccuracy <= 15 ? `High (~${gpsAccuracy.toFixed(0)}m)` : `Medium (~${gpsAccuracy.toFixed(0)}m)`}
                                    </Text>
                                  )}
                                </View>
                              </View>

                              {isLocationOutsideCoverage && (
                                <View className="bg-rose-50 border border-rose-100 p-3 rounded-xl mb-4">
                                  <Text className="text-[#E11D48] text-[9px] font-bold uppercase text-center">Outside Service Area (Mumbai Only)</Text>
                                </View>
                              )}

                              <TouchableOpacity
                                activeOpacity={0.8}
                                disabled={isReverseGeocoding || (!hasConfirmedSearchSelection && !isPinSelectionAuthoritative)}
                                onPress={() => {
                                  setIsMapConfirmed(true);
                                  if (resolvedPlaceName && 
                                      resolvedPlaceName !== 'Selected Location' && 
                                      !/^\d/.test(resolvedPlaceName) && 
                                      !resolvedPlaceName.includes('°')) {
                                    setNewBuildingName(resolvedPlaceName);
                                  } else {
                                    setNewBuildingName('');
                                  }
                                  setAddAddressStep(2);
                                }}
                                className={`w-full h-12 rounded-xl items-center justify-center flex-row gap-2 ${
                                  (isReverseGeocoding || (!hasConfirmedSearchSelection && !isPinSelectionAuthoritative)) ? 'bg-zinc-200' : 'bg-zinc-950'
                                }`}
                              >
                                {isReverseGeocoding ? (
                                  <ActivityIndicator size="small" color="#6B7280" />
                                ) : (
                                  <Text className="text-white text-xs font-black uppercase tracking-wider">Confirm Location</Text>
                                )}
                              </TouchableOpacity>
                            </View>
                          </View>
                        )}

                        {/* STAGE 2: ADDRESS DETAILS FORM */}
                        {addAddressStep === 2 && (
                          <KeyboardAvoidingView
                            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                            style={{ flex: 1 }}
                          >
                            <ScrollView 
                              showsVerticalScrollIndicator={false}
                              contentContainerStyle={{ padding: 24, paddingBottom: 100 }}
                              className="flex-1"
                            >
                              <View className="gap-6">
                                {/* Map Preview reference */}
                                <View className="bg-white border border-[#E5E7EB] p-4 rounded-[24px] gap-3">
                                  <Text className="text-zinc-400 text-[9px] font-black uppercase tracking-wider pl-1">Confirmed Location</Text>
                                  <View className="bg-zinc-50 border border-zinc-150 p-4 rounded-xl flex-row items-start gap-3">
                                    <View className="w-8 h-8 rounded-full bg-rose-50 items-center justify-center mt-0.5">
                                      <Feather name="map-pin" size={14} color="#E11D48" />
                                    </View>
                                    <View className="flex-1">
                                      <Text className="text-zinc-900 text-xs font-black mb-0.5 uppercase tracking-tight">
                                        {resolvedPlaceName}
                                      </Text>
                                      <Text className="text-zinc-500 text-[10px] font-semibold leading-relaxed">
                                        {searchQuery}
                                      </Text>
                                    </View>
                                  </View>
                                </View>

                                {/* Form Input details */}
                                <View className="bg-white border border-[#E5E7EB] p-5 rounded-[24px] gap-4">
                                  <View className="gap-3.5">
                                    <View>
                                      <Text className="text-zinc-700 text-[10px] font-bold uppercase mb-1.5 pl-1">Flat / House No. *</Text>
                                      <TextInput
                                        value={newHouseNo}
                                        onChangeText={setNewHouseNo}
                                        placeholder="Enter flat or house number"
                                        placeholderTextColor="#9CA3AF"
                                        className="border border-[#E5E7EB] p-3.5 rounded-xl text-xs font-semibold bg-zinc-50"
                                      />
                                    </View>

                                    <View>
                                      <Text className="text-zinc-700 text-[10px] font-bold uppercase mb-1.5 pl-1">Building / Society Name *</Text>
                                      <TextInput
                                        value={newBuildingName}
                                        onChangeText={setNewBuildingName}
                                        placeholder="Enter building or society name"
                                        placeholderTextColor="#9CA3AF"
                                        className="border border-[#E5E7EB] p-3.5 rounded-xl text-xs font-semibold bg-zinc-50"
                                      />
                                    </View>

                                    <View className="flex-row justify-between">
                                      <View style={{ width: '48%' }}>
                                        <Text className="text-zinc-700 text-[10px] font-bold uppercase mb-1.5 pl-1">Floor</Text>
                                        <TextInput
                                          value={newFloor}
                                          onChangeText={setNewFloor}
                                          placeholder="e.g. 5th Floor"
                                          placeholderTextColor="#9CA3AF"
                                          className="border border-[#E5E7EB] p-3.5 rounded-xl text-xs font-semibold bg-zinc-50"
                                        />
                                      </View>
                                      <View style={{ width: '48%' }}>
                                        <Text className="text-zinc-700 text-[10px] font-bold uppercase mb-1.5 pl-1">Tower</Text>
                                        <TextInput
                                          value={newTower}
                                          onChangeText={setNewTower}
                                          placeholder="e.g. Tower A"
                                          placeholderTextColor="#9CA3AF"
                                          className="border border-[#E5E7EB] p-3.5 rounded-xl text-xs font-semibold bg-zinc-50"
                                        />
                                      </View>
                                    </View>

                                    <View>
                                      <Text className="text-zinc-700 text-[10px] font-bold uppercase mb-1.5 pl-1">Landmark</Text>
                                      <TextInput
                                        value={newLandmark}
                                        onChangeText={setNewLandmark}
                                        placeholder="e.g. Opposite Citi Mall"
                                        placeholderTextColor="#9CA3AF"
                                        className="border border-[#E5E7EB] p-3.5 rounded-xl text-xs font-semibold bg-zinc-50"
                                      />
                                    </View>

                                    <View>
                                      <Text className="text-zinc-700 text-[10px] font-bold uppercase mb-1.5 pl-1">Arrival instructions</Text>
                                      <TextInput
                                        value={newArrivalInstructions}
                                        onChangeText={setNewArrivalInstructions}
                                        placeholder="e.g. Call me when you reach the gate"
                                        placeholderTextColor="#9CA3AF"
                                        className="border border-[#E5E7EB] p-3.5 rounded-xl text-xs font-semibold bg-zinc-50"
                                      />
                                    </View>
                                  </View>
                                </View>

                                {/* Save As selector */}
                                <View className="gap-2.5">
                                  <Text className="text-[#101828] text-xs font-black uppercase tracking-wider pl-1">Save As</Text>
                                  <View className="flex-row justify-between">
                                    {[
                                      { id: 'Home', emoji: '🏠' },
                                      { id: 'Office', emoji: '🏢' },
                                      { id: 'Gym', emoji: '🏋️' },
                                      { id: 'Custom', emoji: '📍' }
                                    ].map((item) => {
                                      const isSel = newAddressLabelType === item.id;
                                      return (
                                        <TouchableOpacity
                                          key={item.id}
                                          activeOpacity={0.8}
                                          onPress={() => setNewAddressLabelType(item.id as any)}
                                          className={`w-[22%] py-3.5 rounded-xl border items-center justify-center flex-row gap-1 ${
                                            isSel ? 'bg-zinc-950 border-zinc-950' : 'bg-white border-[#E5E7EB]'
                                          }`}
                                        >
                                          <Text className="text-xs">{item.emoji}</Text>
                                          <Text className={`text-[9px] font-black uppercase ${isSel ? 'text-white' : 'text-zinc-800'}`}>{item.id}</Text>
                                        </TouchableOpacity>
                                      );
                                    })}
                                  </View>

                                  {newAddressLabelType === 'Custom' && (
                                    <TextInput
                                      value={newCustomLabel}
                                      onChangeText={setNewCustomLabel}
                                      placeholder="Custom label (e.g. Parents, Guest)"
                                      placeholderTextColor="#9CA3AF"
                                      className="border border-[#E5E7EB] p-3.5 rounded-xl text-xs font-semibold bg-zinc-50 mt-2"
                                    />
                                  )}
                                </View>

                                {/* Receiver details card */}
                                <View className="bg-white border border-[#E5E7EB] p-5 rounded-[24px] gap-3">
                                  <Text className="text-[#101828] text-xs font-black uppercase tracking-wider pl-1">
                                    Receiver details for this address
                                  </Text>
                                  <View className="bg-zinc-50 border border-zinc-150 p-4 rounded-xl gap-2">
                                    <View className="flex-row justify-between items-center">
                                      <Text className="text-zinc-500 text-[10px] font-bold uppercase">Name</Text>
                                      <Text className="text-zinc-800 text-xs font-black">{user.name}</Text>
                                    </View>
                                    <View className="flex-row justify-between items-center border-t border-zinc-100 pt-2 mt-1">
                                      <Text className="text-zinc-500 text-[10px] font-bold uppercase">Phone</Text>
                                      <Text className="text-zinc-800 text-xs font-black">
                                        {Database.schema.users.find(u => u.id === user?.id)?.phone || 'No phone number'}
                                      </Text>
                                    </View>
                                  </View>
                                  <Text className="text-zinc-400 text-[9px] font-semibold pl-1">
                                    To edit receiver details, update profile settings.
                                  </Text>
                                </View>

                                {/* Save Button */}
                                <TouchableOpacity
                                  activeOpacity={0.8}
                                  disabled={!newHouseNo.trim() || !newBuildingName.trim()}
                                  onPress={async () => {
                                    if (!activeCoords.lat || !activeCoords.lng || activeCoords.lat === 0 || activeCoords.lng === 0) {
                                      Alert.alert('Validation Error', 'Verified location coordinates are missing. Please confirm your location on the map.');
                                      return;
                                    }
                                    if (activeCoords.lat < -90 || activeCoords.lat > 90 || activeCoords.lng < -180 || activeCoords.lng > 180) {
                                      Alert.alert('Validation Error', 'Invalid location coordinates detected. Please confirm your location on the map again.');
                                      return;
                                    }
                                    if (!isMapConfirmed) {
                                      Alert.alert('Validation Error', 'Please confirm your location pin on the map.');
                                      return;
                                    }
                                    if (!newHouseNo.trim() || !newBuildingName.trim()) {
                                      Alert.alert('Validation Error', 'Please enter Flat/House No and Building Name.');
                                      return;
                                    }

                                    const finalLabel = newAddressLabelType === 'Custom'
                                      ? (newCustomLabel.trim() || 'Custom') as any
                                      : newAddressLabelType;

                                    // Prepend house number and combine building name and tower
                                    const displayBuilding = newTower.trim() 
                                      ? `${newBuildingName.trim()} (${newTower.trim()})` 
                                      : newBuildingName.trim();
                                    const fullBuilding = `${newHouseNo.trim()}, ${displayBuilding}`;
                                    
                                    // Combine floor and geocoded street info
                                    const fullStreet = [newFloor.trim() ? `${newFloor.trim()}` : '', searchQuery.trim()].filter(Boolean).join(', ');

                                    try {
                                      const added = await addAddress({
                                        label: finalLabel,
                                        building: fullBuilding,
                                        street: fullStreet,
                                        landmark: newLandmark.trim(),
                                        city: 'Mumbai',
                                        pinCode: '',
                                        isDefault: false,
                                        lat: activeCoords.lat,
                                        lng: activeCoords.lng,
                                        apartment: newHouseNo.trim(),
                                        floor: newFloor.trim(),
                                        notes: newArrivalInstructions.trim(),
                                        placeId: placeId || undefined
                                      });

                                      setSelectedAddressId(added.id);
                                      setIsAddAddressModalVisible(false);
                                      Alert.alert('Address Saved 🏠', 'Your training venue has been successfully saved with exact GPS coordinates.');
                                    } catch (err: any) {
                                      console.error('[DIAGNOSTIC] Saving address failed:', err);
                                      Alert.alert('Save Failed', `Database error: ${err?.message || 'Could not persist location.'}`);
                                    }
                                  }}
                                  className={`w-full h-14 rounded-2xl items-center justify-center mt-2 ${
                                    (!newHouseNo.trim() || !newBuildingName.trim()) ? 'bg-zinc-300' : 'bg-zinc-950'
                                  }`}
                                >
                                  <Text className="text-white text-xs font-black uppercase tracking-wider">Save Address</Text>
                                </TouchableOpacity>
                              </View>
                            </ScrollView>
                          </KeyboardAvoidingView>
                        )}
                      </View>
                    </SafeAreaView>
                  </Modal>
                </View>
              )}

              {/* STEP 4: DATE SELECTOR */}
              {step === 4 && (
                <View className="gap-5">
                  <View>
                    <Text className="text-[#6B7280] text-[10px] font-black uppercase tracking-widest">Schedule Day</Text>
                    <Text className="text-[#101828] text-2xl font-black tracking-tight mt-1">Select Date</Text>
                  </View>

                  {/* Horizontal Date Capsules (Feature 4) */}
                  <View className="flex-row justify-between gap-2.5">
                    {((istNow) => {
                      const infoToday = getISTDateInfo(istNow);
                      const tomorrowTime = new Date(istNow.getTime() + 24 * 60 * 60 * 1000);
                      const infoTomorrow = getISTDateInfo(tomorrowTime);
                      const dayAfterTime = new Date(istNow.getTime() + 2 * 24 * 60 * 60 * 1000);
                      const infoDayAfter = getISTDateInfo(dayAfterTime);
                      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                      const weekdays = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
                      
                      const dayAfterDate = new Date(infoDayAfter.year, infoDayAfter.month - 1, infoDayAfter.day);
                      const dayAfterLabel = weekdays[dayAfterDate.getDay()];

                      return [
                        { id: 'today', label: 'TODAY', sub: `${infoToday.day} ${months[infoToday.month - 1].toUpperCase()}` },
                        { id: 'tomorrow', label: 'TOMORROW', sub: `${infoTomorrow.day} ${months[infoTomorrow.month - 1].toUpperCase()}` },
                        { id: 'dayafter', label: dayAfterLabel, sub: `${infoDayAfter.day} ${months[infoDayAfter.month - 1].toUpperCase()}` },
                        { id: 'calendar', label: 'CALENDAR', sub: 'Open Grid' }
                      ];
                    })(getCurrentServerTime()).map((capsule) => {
                      const isSelected = dateSelectionType === capsule.id;
                      return (
                        <TouchableOpacity
                          key={capsule.id}
                          activeOpacity={0.8}
                          onPress={async () => {
                            setDateSelectionType(capsule.id as any);
                            setShowCalendarPicker(capsule.id === 'calendar');
                            if (capsule.id !== 'calendar') {
                              const istNow = getCurrentServerTime();
                              const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                              let targetDateFormatted = '';
                              if (capsule.id === 'today') {
                                const info = getISTDateInfo(istNow);
                                targetDateFormatted = `${months[info.month - 1]} ${info.day}, ${info.year}`;
                              } else if (capsule.id === 'tomorrow') {
                                const tomorrowTime = new Date(istNow.getTime() + 24 * 60 * 60 * 1000);
                                const info = getISTDateInfo(tomorrowTime);
                                targetDateFormatted = `${months[info.month - 1]} ${info.day}, ${info.year}`;
                              } else if (capsule.id === 'dayafter') {
                                const dayAfterTime = new Date(istNow.getTime() + 2 * 24 * 60 * 60 * 1000);
                                const info = getISTDateInfo(dayAfterTime);
                                targetDateFormatted = `${months[info.month - 1]} ${info.day}, ${info.year}`;
                              }
                              
                              setSelectedDate(targetDateFormatted);
                              triggerTransition(5);
                              await loadAvailabilityForSelectedDate(targetDateFormatted);
                            }
                          }}
                          className={`flex-1 px-1 py-3.5 rounded-2xl border items-center justify-center gap-1 ${
                            isSelected ? 'bg-zinc-950 border-zinc-950' : 'bg-white border-[#E5E7EB]'
                          }`}
                          style={{
                            shadowColor: '#101828',
                            shadowOffset: { width: 0, height: 1 },
                            shadowOpacity: 0.02,
                            shadowRadius: 2,
                            elevation: 1,
                          }}
                        >
                          <Text 
                            numberOfLines={1}
                            adjustsFontSizeToFit={true}
                            className={`text-[9px] font-black uppercase tracking-wider text-center ${isSelected ? 'text-white' : 'text-[#101828]'}`}
                          >
                            {capsule.label}
                          </Text>
                          <Text 
                            numberOfLines={1}
                            className={`text-[8px] font-bold text-center mt-0.5 ${isSelected ? 'text-zinc-400' : 'text-[#6B7280]'}`}
                          >
                            {capsule.sub}
                          </Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>

                  {/* Date picker grid panel */}
                  {showCalendarPicker && (
                    <View 
                      className="bg-white border border-[#E5E7EB] p-5 rounded-[28px] gap-4"
                      style={{
                        shadowColor: '#101828',
                        shadowOffset: { width: 0, height: 2 },
                        shadowOpacity: 0.04,
                        shadowRadius: 6,
                        elevation: 2,
                      }}
                    >
                      <Text className="text-[#101828] text-xs font-black uppercase tracking-wider text-center">Select Available Date</Text>
                      {(() => {
                        const istNow = getCurrentServerTime();
                        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                        const fullMonths = [
                          'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE',
                          'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'
                        ];
                        const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

                        const dates = Array.from({ length: 12 }).map((_, i) => {
                          const dateObj = new Date(istNow.getTime() + (i + 2) * 24 * 60 * 60 * 1000);
                          const info = getISTDateInfo(dateObj);
                          const dateString = `${months[info.month - 1]} ${info.day}, ${info.year}`;
                          
                          const dayObj = new Date(info.year, info.month - 1, info.day);
                          const weekdayName = weekdays[dayObj.getDay()];
                          
                          return {
                            dateString,
                            day: String(info.day).padStart(2, '0'),
                            monthName: fullMonths[info.month - 1],
                            displayDate: `${info.day} ${months[info.month - 1].toUpperCase()}`,
                            weekday: weekdayName,
                          };
                        });

                        const grouped: Record<string, typeof dates> = {};
                        const monthOrder: string[] = [];
                        for (const d of dates) {
                          if (!grouped[d.monthName]) {
                            grouped[d.monthName] = [];
                            monthOrder.push(d.monthName);
                          }
                          grouped[d.monthName].push(d);
                        }

                        return monthOrder.map((mName) => (
                          <View key={mName} className="gap-3.5 mb-2 w-full">
                            <Text className="text-zinc-900 text-xs font-black uppercase tracking-wider text-center mt-2">
                              {mName}
                            </Text>
                            <View className="flex-row flex-wrap justify-between gap-y-3">
                              {grouped[mName].map((dObj, idx) => {
                                const isPicked = selectedDate === dObj.dateString;
                                return (
                                  <TouchableOpacity
                                    key={idx}
                                    activeOpacity={0.8}
                                    onPress={async () => {
                                      setSelectedDate(dObj.dateString);
                                      triggerTransition(5);
                                      await loadAvailabilityForSelectedDate(dObj.dateString);
                                    }}
                                    className={`w-[47%] py-4 rounded-[18px] border items-center justify-center gap-1 ${
                                      isPicked ? 'bg-[#101828] border-[#101828]' : 'bg-white border-[#E5E7EB]'
                                    }`}
                                    style={{
                                      shadowColor: '#101828',
                                      shadowOffset: { width: 0, height: 1 },
                                      shadowOpacity: 0.01,
                                      shadowRadius: 2,
                                      elevation: 1,
                                    }}
                                  >
                                    <Text className={`text-xs font-black uppercase tracking-wider ${isPicked ? 'text-white' : 'text-zinc-900'}`}>
                                      {dObj.displayDate}
                                    </Text>
                                    <Text className={`text-[10px] font-bold ${isPicked ? 'text-zinc-400' : 'text-[#6B7280]'}`}>
                                      {dObj.weekday}
                                    </Text>
                                  </TouchableOpacity>
                                );
                              })}
                            </View>
                          </View>
                        ));
                      })()}
                    </View>
                  )}

                  {/* Summary date selected bar */}
                  <View className="bg-white border border-[#E5E7EB] px-5 py-5 rounded-[24px] flex-row justify-between items-center">
                    <View className="flex-row items-center gap-2.5">
                      <Feather name="calendar" size={16} color="#4F46E5" />
                      <Text className="text-[#101828] text-xs font-black uppercase tracking-wider">Selected Date</Text>
                    </View>
                    <Text className="text-[#4F46E5] text-xs font-extrabold">{formatToDDMMYYYY(selectedDate) || 'Select a date'}</Text>
                  </View>
                </View>
              )}

              {/* STEP 5: TIME SELECTOR */}
              {step === 5 && (
                <View className="gap-5">
                  <View>
                    <Text className="text-[#6B7280] text-[10px] font-black uppercase tracking-widest">Training Schedule</Text>
                    <Text className="text-[#101828] text-2xl font-black tracking-tight mt-1">Select Time Slot</Text>
                  </View>


                  {(() => {
                    if (isLoadingAvailability) {
                      return (
                        <View 
                          className="bg-white border border-[#E5E7EB] p-8 rounded-[28px] items-center justify-center mt-2 shadow-sm"
                          style={{
                            shadowColor: '#101828',
                            shadowOffset: { width: 0, height: 2 },
                            shadowOpacity: 0.02,
                            shadowRadius: 6,
                            elevation: 1,
                            minHeight: 200
                          }}
                        >
                          <ActivityIndicator size="large" color="#4F46E5" />
                          <Text className="text-zinc-650 text-xs font-black uppercase tracking-widest text-center mt-4">
                            Checking availability for {formatToDDMMYYYY(selectedDate)}...
                          </Text>
                        </View>
                      );
                    }

                    const customerAddress = addresses.find(a => a.id === selectedAddressId);
                    const customerHasNoCoords = selectedAddressId ? (!customerAddress || customerAddress.lat === undefined || customerAddress.lng === undefined || customerAddress.lat === null || customerAddress.lng === null) : false;

                    if (customerHasNoCoords) {
                      return (
                        <View 
                          className="bg-white border border-[#E5E7EB] p-8 rounded-[28px] items-center gap-6 mt-2 shadow-sm"
                          style={{
                            shadowColor: '#101828',
                            shadowOffset: { width: 0, height: 2 },
                            shadowOpacity: 0.02,
                            shadowRadius: 6,
                            elevation: 1
                          }}
                        >
                          <View className="w-16 h-16 rounded-full bg-rose-50 items-center justify-center">
                            <Feather name="map-pin" size={32} color="#E11D48" />
                          </View>
                          <View className="items-center gap-2">
                            <Text className="text-[#101828] text-base font-black tracking-tight text-center">
                              Location Coordinates Missing
                            </Text>
                            <Text className="text-[#6B7280] text-[10px] font-medium leading-relaxed text-center max-w-[80%]">
                              The selected address does not have valid GPS coordinates. Please select or edit your address with a valid location.
                            </Text>
                          </View>
                          <TouchableOpacity
                            activeOpacity={0.8}
                            onPress={() => triggerTransition(3)}
                            className="bg-[#101828] py-4 px-8 rounded-xl items-center justify-center w-full"
                          >
                            <Text className="text-white text-xs font-black uppercase tracking-wider">Select Location</Text>
                          </TouchableOpacity>
                        </View>
                      );
                    }

                    const availableSlots = getDynamicAvailableSlots();
                    const targetCategory = WORKOUT_CATEGORY_MAPPING[selectedExperience.id] || '';
                    const customerLat = customerAddress?.lat || 0;
                    const customerLng = customerAddress?.lng || 0;
                    const finalEligibleTrainers = coaches.filter(coach => {
                      const assignments = Database.getWorkoutAssignments(coach.id);
                      const isApproved = assignments.some(a => a.workoutCategory === targetCategory && a.status === 'APPROVED');
                      const acceptsAll = assignments.some(a => a.workoutCategory === 'All Workouts' && a.status === 'APPROVED');
                      const workoutApproved = acceptsAll || isApproved;

                      const isOnline = coach.preferences?.online !== false;
                      const isPartnerApproved = coach.verifiedBadge !== false;

                      const locationStatus = coach.preferences?.operatingLocationStatus;
                      const locationApproved = locationStatus === 'verified';

                      const trainerLat = coach.preferences?.operatingLatitude;
                      const trainerLng = coach.preferences?.operatingLongitude;
                      const radiusLimit = coach.preferences?.radiusKm || 15;

                      let distance = 999999;
                      let insideRadius = false;
                      if (trainerLat !== undefined && trainerLat !== null && trainerLng !== undefined && trainerLng !== null) {
                        distance = calculateDistanceKm(trainerLat, trainerLng, customerLat, customerLng);
                        insideRadius = distance <= radiusLimit;
                      }

                      // Apply gender filters
                      const trainerGender = (coach.gender || '').toLowerCase();
                      const genderValid = trainerGender === 'male' || trainerGender === 'female';
                      
                      let genderApproved = false;
                      if (genderValid) {
                        if (trainerPref === 'any') {
                          genderApproved = true;
                        } else if (trainerPref === 'male') {
                          genderApproved = trainerGender === 'male';
                        } else if (trainerPref === 'female') {
                          genderApproved = trainerGender === 'female';
                        } else if (trainerPref === 'favourite') {
                          const clientPref = (Database.getProfile(user.id || '')?.trainerPreference || 'no_preference').toLowerCase();
                          if (clientPref === 'male') {
                            genderApproved = trainerGender === 'male';
                          } else if (clientPref === 'female') {
                            genderApproved = trainerGender === 'female';
                          } else {
                            genderApproved = true;
                          }
                        }
                      }

                      return isOnline && isPartnerApproved && workoutApproved && locationApproved && insideRadius && genderValid && genderApproved;
                    });

                    const slotsToDisplay = getFilteredSlotsForPeriod();

                    console.log('CUSTOMER_EMPTY_STATE_DEBUG', JSON.stringify({
                      finalEligibleTrainerCount: finalEligibleTrainers.length,
                      finalEligibleTrainerIds: finalEligibleTrainers.map(t => t.id),
                      finalEligibleTrainerNames: finalEligibleTrainers.map(t => t.name),
                      uiTrainerCount: finalEligibleTrainers.length,
                      uiSlotCount: slotsToDisplay.length,
                      loading: false,
                      refreshing: false,
                      matching: false,
                      emptyStateCondition: slotsToDisplay.length === 0,
                      emptyStateReason: slotsToDisplay.length === 0 ? 'No available slot found for eligible trainers on selected date' : 'None'
                    }, null, 2));

                    if (slotsToDisplay.length === 0) {
                      const selectedNormalized = normalizeDate(selectedDate);
                      const todayNormalized = normalizeDate(getCurrentServerTime());
                      const tomorrowTime = new Date(getCurrentServerTime().getTime() + 24 * 60 * 60 * 1000);
                      const tomorrowNormalized = normalizeDate(tomorrowTime);

                      const isTodayVal = (selectedNormalized === todayNormalized);
                      const isTomorrowVal = (selectedNormalized === tomorrowNormalized);
                      
                      let dateLabel = '';
                      if (isTodayVal) {
                        dateLabel = 'today';
                      } else if (isTomorrowVal) {
                        dateLabel = 'tomorrow';
                      } else {
                        const parts = selectedNormalized.split('-');
                        const y = parseInt(parts[0], 10);
                        const m = parseInt(parts[1], 10) - 1;
                        const d = parseInt(parts[2], 10);
                        const dateObj = new Date(y, m, d);
                        const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        dateLabel = weekdays[dateObj.getDay()];
                      }

                      const mainText = `Sorry, we're fully booked for ${dateLabel}. Our trainers are in high demand and unfortunately, we don't have any sessions available ${isTodayVal ? 'today' : 'on this date'}.`;
                      const subText = `Try ${isTodayVal ? 'tomorrow or choose ' : ''}another date to find an available session.`;

                      return (
                        <View 
                          className="bg-white border border-[#E5E7EB] p-8 rounded-[28px] items-center gap-6 mt-2 shadow-sm"
                          style={{
                            shadowColor: '#101828',
                            shadowOffset: { width: 0, height: 2 },
                            shadowOpacity: 0.02,
                            shadowRadius: 6,
                            elevation: 1
                          }}
                        >
                          <View className="w-16 h-16 rounded-full bg-amber-50 items-center justify-center">
                            <Feather name="flame" size={30} color="#F59E0B" />
                          </View>
                          <View className="items-center gap-2">
                            <Text className="text-zinc-900 text-[10px] font-black uppercase tracking-widest text-center">
                              WE&apos;RE IN HIGH DEMAND
                            </Text>
                            <Text className="text-[#101828] text-base font-black tracking-tight text-center mt-1">
                              Fully Booked
                            </Text>
                            <Text className="text-[#6B7280] text-[11px] font-semibold leading-relaxed text-center max-w-[90%] mt-1">
                              {mainText}
                            </Text>
                            <Text className="text-zinc-400 text-[10px] font-bold text-center max-w-[90%] mt-1">
                              {subText}
                            </Text>
                          </View>
                          <View className="w-full gap-3">
                            <TouchableOpacity
                              activeOpacity={0.8}
                              onPress={() => {
                                Alert.alert('Notification Set 🔔', `We will alert you as soon as a coach for ${selectedExperience.title} becomes available on this date.`);
                              }}
                              className="bg-[#101828] py-4 rounded-xl items-center justify-center"
                            >
                              <Text className="text-white text-xs font-black uppercase tracking-wider">Notify Me</Text>
                            </TouchableOpacity>
                            
                            <TouchableOpacity
                              activeOpacity={0.8}
                              onPress={() => triggerTransition(1)}
                              className="bg-zinc-50 border border-zinc-200 py-4 rounded-xl items-center justify-center"
                            >
                              <Text className="text-zinc-800 text-xs font-black uppercase tracking-wider">Try Another Workout</Text>
                            </TouchableOpacity>

                            {trainerPref === 'favourite' && (
                              <TouchableOpacity
                                activeOpacity={0.8}
                                onPress={() => triggerTransition(2)}
                                className="bg-zinc-50 border border-zinc-200 py-4 rounded-xl items-center justify-center"
                              >
                                <Text className="text-zinc-800 text-xs font-black uppercase tracking-wider">Change Trainer Preference</Text>
                              </TouchableOpacity>
                            )}

                            <TouchableOpacity
                              activeOpacity={0.8}
                              onPress={() => triggerTransition(4)}
                              className="bg-zinc-50 border border-zinc-200 py-4 rounded-xl items-center justify-center"
                            >
                              <Text className="text-zinc-800 text-xs font-black uppercase tracking-wider">Change Date</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      );
                    }

                    return (
                      <>
                        {/* Slots listing for period */}
                        <View className="gap-3.5">
                          {slotsToDisplay.map((slotObj, idx) => {
                            const isPicked = selectedTime === slotObj.time;
                            const isDisabled = !!slotObj.isBooked;
                            const displayTime = getCustomerDisplayTime(slotObj.time);

                            return (
                              <TouchableOpacity
                                key={idx}
                                disabled={isDisabled}
                                activeOpacity={isDisabled ? 1 : 0.8}
                                onPress={() => {
                                  handleSelectSlot(slotObj.time, slotObj.trainers || []);
                                  setTimeout(() => handleNext(), 250);
                                }}
                                style={{
                                  height: 80,
                                  shadowColor: '#101828',
                                  shadowOffset: { width: 0, height: 2 },
                                  shadowOpacity: isPicked ? 0.12 : 0.03,
                                  shadowRadius: 8,
                                  elevation: 2,
                                }}
                                className={`px-5 rounded-2xl border flex-row justify-between items-center ${
                                  isDisabled
                                    ? 'bg-zinc-50 border-zinc-200 opacity-60'
                                    : isPicked
                                    ? 'bg-[#E11D48] border-[#E11D48]'
                                    : 'bg-white border-[#E5E7EB]'
                                }`}
                              >
                                <View className="flex-row items-center gap-4">
                                  <View className={`w-8 h-8 rounded-full items-center justify-center ${
                                    isDisabled ? 'bg-zinc-100' : isPicked ? 'bg-white/20' : 'bg-rose-50'
                                  }`}>
                                    <Feather 
                                      name="clock" 
                                      size={14} 
                                      color={isDisabled ? '#9CA3AF' : isPicked ? 'white' : '#E11D48'} 
                                    />
                                  </View>
                                  <View className="gap-1">
                                    <View className="flex-row items-center gap-2">
                                      <Text 
                                        className={`text-sm font-extrabold tracking-tight ${
                                          isDisabled ? 'text-zinc-400 line-through' : isPicked ? 'text-white' : 'text-zinc-900'
                                        }`}
                                      >
                                        {displayTime}
                                      </Text>
                                      <View className={`px-2 py-0.5 rounded-md ${
                                        isPicked ? 'bg-white/20' : 'bg-zinc-100'
                                      }`}>
                                        <Text className={`text-[8px] font-extrabold tracking-wider ${
                                          isPicked ? 'text-white' : 'text-zinc-500'
                                        }`}>1 HR SESSION</Text>
                                      </View>
                                    </View>
                                    <Text className={`text-[9px] font-black tracking-wider uppercase ${
                                      isPicked ? 'text-rose-100' : 'text-[#6B7280]'
                                    }`}>
                                      {isDisabled ? 'UNAVAILABLE' : 'AVAILABLE'}
                                    </Text>
                                  </View>
                                </View>
                                
                                {/* Right badge or checkmark indicator */}
                                <View className="flex-row items-center gap-2">
                                  {isPicked ? (
                                    <View className="w-6 h-6 rounded-full bg-white items-center justify-center">
                                      <Feather name="check" size={14} color="#E11D48" />
                                    </View>
                                  ) : isDisabled ? (
                                    <Text className="text-zinc-400 text-[10px] font-black uppercase tracking-wider">FULL</Text>
                                  ) : (
                                    <View className="w-6 h-6 rounded-full border border-zinc-200 bg-zinc-50" />
                                  )}
                                </View>
                              </TouchableOpacity>
                            );
                          })}
                        </View>
                      </>
                    );
                  })()}
                </View>
              )}

              {step === 6 && (
                <View className="gap-6 pb-6">
                  {/* Reservation countdown warning alert */}
                  {reservationTimeLeft > 0 && (
                    <View className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex-row items-center justify-between shadow-sm">
                      <View className="flex-row items-center gap-2">
                        <Feather name="clock" size={14} color="#D97706" />
                        <Text className="text-amber-800 text-[10px] font-bold">
                          Slot reserved. Complete checkout in:
                        </Text>
                      </View>
                      <Text className="text-amber-900 text-xs font-black">
                        {Math.floor(reservationTimeLeft / 60)}:{(reservationTimeLeft % 60).toString().padStart(2, '0')}
                      </Text>
                    </View>
                  )}

                  {/* Section 1 — Booking Summary Card */}
                  <View 
                    className="bg-white border border-[#E5E7EB] p-5 rounded-[28px] shadow-sm gap-4"
                    style={{
                      shadowColor: '#101828',
                      shadowOffset: { width: 0, height: 2 },
                      shadowOpacity: 0.02,
                      shadowRadius: 6,
                      elevation: 1,
                    }}
                  >
                    {/* Card Header: Calendar Icon, Title, Edit Button */}
                    <View className="flex-row justify-between items-center">
                      <View className="flex-row items-center gap-2.5">
                        <View className="w-7 h-7 rounded-full bg-rose-50 items-center justify-center">
                          <Feather name="calendar" size={13} color="#E11D48" />
                        </View>
                        <Text className="text-zinc-950 text-xs font-black uppercase tracking-wider">Booking Summary</Text>
                      </View>
                      <TouchableOpacity
                        activeOpacity={0.8}
                        onPress={() => triggerTransition(1)}
                        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                        className="bg-rose-50 border border-rose-100 rounded-lg px-2.5 py-1.5 flex-row items-center gap-1"
                      >
                        <Feather name="edit-2" size={10} color="#E11D48" />
                        <Text className="text-[#E11D48] text-[10px] font-black uppercase">Edit</Text>
                      </TouchableOpacity>
                    </View>

                    {/* Workout Info: Thumbnail, Title, Solo Badge */}
                    <View className="flex-row gap-4 items-center mt-1">
                      <Image 
                        source={{ uri: getWorkoutImage(selectedExperience.id) }} 
                        className="w-20 h-20 rounded-[20px] bg-zinc-50 border border-zinc-100" 
                      />
                      <View className="flex-1 gap-1.5">
                        <Text className="text-[#101828] text-base font-black tracking-tight">{selectedExperience.title}</Text>
                        <View className="flex-row">
                          <View className="bg-rose-50 border border-rose-100 px-2 py-0.5 rounded-full flex-row items-center gap-1.5">
                            <Feather name="user" size={8} color="#E11D48" />
                            <Text className="text-[#E11D48] text-[8px] font-black uppercase">Solo Session</Text>
                          </View>
                        </View>
                      </View>
                    </View>

                    {/* Summary Row Items */}
                    <View className="mt-2">
                      {/* Date Row */}
                      <View className="border-t border-dashed border-[#E5E7EB] py-3.5 flex-row justify-between items-center">
                        <View className="flex-row items-center gap-2">
                          <Feather name="calendar" size={13} color="#6B7280" />
                          <Text className="text-[#6B7280] text-xs font-semibold">Date</Text>
                        </View>
                        <Text className="text-[#101828] text-xs font-extrabold">{getFormattedDateLabel()}</Text>
                      </View>

                      {/* Time Row */}
                      <View className="border-t border-dashed border-[#E5E7EB] py-3.5 flex-row justify-between items-center">
                        <View className="flex-row items-center gap-2">
                          <Feather name="clock" size={13} color="#6B7280" />
                          <Text className="text-[#6B7280] text-xs font-semibold">Time</Text>
                        </View>
                        <Text className="text-[#101828] text-xs font-extrabold">
                          {getCustomerDisplayTime(selectedTime)} <Text className="text-[#6B7280] font-medium">({selectedExperience.duration} min workout)</Text>
                        </Text>
                      </View>

                      {/* Trainer Preference Row */}
                      <View className="border-t border-dashed border-[#E5E7EB] py-3.5 flex-row justify-between items-center">
                        <View className="flex-row items-center gap-2">
                          <Feather name="user" size={13} color="#6B7280" />
                          <Text className="text-[#6B7280] text-xs font-semibold">Trainer Preference</Text>
                        </View>
                        <Text className="text-[#101828] text-xs font-extrabold">
                          {trainerPref === 'any' ? 'No Preference' : trainerPref === 'female' ? 'Female Trainer' : trainerPref === 'male' ? 'Male Trainer' : 'Favorite Trainer'}
                        </Text>
                      </View>

                      {/* Location Row */}
                      <View className="border-t border-dashed border-[#E5E7EB] py-3.5 flex-row justify-between items-start">
                        <View className="flex-row items-center gap-2 mt-0.5">
                          <Feather name="map-pin" size={13} color="#6B7280" />
                          <Text className="text-[#6B7280] text-xs font-semibold">Location</Text>
                        </View>
                        <Text className="text-[#101828] text-xs font-extrabold max-w-[60%] text-right leading-relaxed">
                          {addresses.find(a => a.id === selectedAddressId)?.addressLine || 'Selected Location'}
                        </Text>
                      </View>

                      {/* Credits Row */}
                      <View className="border-t border-dashed border-[#E5E7EB] pt-3.5 flex-row justify-between items-center">
                        <View className="flex-row items-center gap-2">
                          <Feather name="credit-card" size={13} color="#6B7280" />
                          <Text className="text-[#6B7280] text-xs font-semibold">Credits</Text>
                        </View>
                        <Text className="text-[#101828] text-xs font-extrabold">1 Credit will be used</Text>
                      </View>
                    </View>
                  </View>

                  {/* Section 2 — Note to Your Trainer (Optional) */}
                  <View className="gap-3 mt-1">
                    {/* Header: Clipboard Icon, Title, Subtitle */}
                    <View className="flex-row gap-3 items-center">
                      <View className="w-9 h-9 rounded-full bg-rose-50 items-center justify-center">
                        <Feather name="edit-3" size={15} color="#E11D48" />
                      </View>
                      <View className="flex-1">
                        <View className="flex-row items-center gap-1">
                          <Text className="text-[#101828] text-xs font-black uppercase tracking-wider">Note to Your Trainer</Text>
                          <Text className="text-[#6B7280] text-[10px] font-semibold">(Optional)</Text>
                        </View>
                        <Text className="text-[#6B7280] text-[9px] font-medium leading-none mt-1">Share anything that will help your trainer prepare better.</Text>
                      </View>
                    </View>

                    {/* Chips horizontal scroll */}
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} className="flex-row gap-2 mt-1 py-1" contentContainerStyle={{ gap: 8 }}>
                      {[
                        { label: 'I have yoga mat', icon: 'award' },
                        { label: 'I have injury', icon: 'activity' },
                        { label: 'Security gate access', icon: 'shield' },
                        { label: 'Bring resistance bands', icon: 'gift' },
                        { label: 'Other', icon: 'chevron-down' }
                      ].map((chip) => {
                        const isSelected = trainerNote.includes(chip.label);
                        return (
                          <TouchableOpacity
                            key={chip.label}
                            activeOpacity={0.8}
                            onPress={() => handleChipPress(chip.label)}
                            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                            className={`px-3 py-1.5 rounded-full border flex-row items-center gap-1.5 ${
                              isSelected ? 'bg-rose-100/70 border-rose-300' : 'bg-rose-50/50 border-rose-100/60'
                            }`}
                          >
                            <Feather name={chip.icon as any} size={10} color="#E11D48" />
                            <Text className="text-[#E11D48] text-[9px] font-extrabold">{chip.label}</Text>
                          </TouchableOpacity>
                        );
                      })}
                    </ScrollView>

                    {/* Multiline text box */}
                    <View className="relative bg-white border border-[#E5E7EB] rounded-2xl p-4 mt-0.5">
                      <TextInput
                        ref={noteInputRef}
                        multiline
                        numberOfLines={4}
                        value={trainerNote}
                        onChangeText={(text) => {
                          if (text.length <= 250) {
                            setTrainerNote(text);
                          }
                        }}
                        placeholder="Anything else your trainer should know..."
                        placeholderTextColor="#9CA3AF"
                        className="text-[#101828] text-xs font-semibold h-20 text-start"
                        style={{ minHeight: 80, padding: 0, textAlignVertical: 'top' }}
                        maxLength={250}
                      />
                      <Text className="text-right text-[#9CA3AF] text-[9px] font-bold mt-1">
                        {trainerNote.length}/250
                      </Text>
                    </View>
                  </View>

                  {/* Section 3 — Session Policies */}
                  <View 
                    className="bg-amber-50/20 border border-amber-100/50 p-4.5 rounded-[28px] flex-row items-center justify-between mt-2"
                  >
                    <View className="flex-row items-center gap-3.5 flex-1 pr-3">
                      <View className="w-9 h-9 rounded-full bg-amber-100/40 items-center justify-center">
                        <Feather name="shield" size={15} color="#D97706" />
                      </View>
                      <View className="flex-1 gap-0.5">
                        <Text className="text-[#101828] text-xs font-black uppercase tracking-wider">Session Policies</Text>
                        <Text className="text-[#6B7280] text-[9px] font-medium leading-normal">
                          Important information about timing, cancellation, privacy, safety & more.
                        </Text>
                      </View>
                    </View>
                    <TouchableOpacity
                      activeOpacity={0.8}
                      onPress={() => router.push('/legal-center')}
                      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                      className="border border-rose-200 px-3.5 py-1.5 rounded-full flex-row items-center gap-0.5 bg-white shadow-sm"
                    >
                      <Text className="text-[#E11D48] text-[9px] font-black uppercase tracking-wide">View Details</Text>
                      <Feather name="chevron-right" size={10} color="#E11D48" />
                    </TouchableOpacity>
                  </View>

                  {/* Policy reminders grid icons */}
                  <View className="flex-row justify-between py-4 border-t border-b border-zinc-200/50 mt-2 bg-white rounded-2xl px-2">
                    <View className="flex-1 items-center px-1">
                      <Feather name="clock" size={14} color="#4F46E5" />
                      <Text className="text-zinc-950 text-[9px] font-black mt-1.5 text-center leading-none">15 Min Grace</Text>
                      <Text className="text-zinc-400 text-[7px] font-bold text-center mt-1 leading-relaxed">Grace period for preparation</Text>
                    </View>
                    
                    <View className="w-[1px] bg-zinc-100" />

                    <View className="flex-1 items-center px-1">
                      <Feather name="activity" size={14} color="#4B5563" />
                      <Text className="text-zinc-950 text-[9px] font-black mt-1.5 text-center leading-none">60 Min Workout</Text>
                      <Text className="text-zinc-400 text-[7px] font-bold text-center mt-1 leading-relaxed">Workout starts after OTP</Text>
                    </View>

                    <View className="w-[1px] bg-zinc-100" />

                    <View className="flex-1 items-center px-1">
                      <Feather name="shield" size={14} color="#E11D48" />
                      <Text className="text-zinc-950 text-[9px] font-black mt-1.5 text-center leading-none">Fair & Transparent</Text>
                      <Text className="text-zinc-400 text-[7px] font-bold text-center mt-1 leading-relaxed">Same rules for everyone</Text>
                    </View>

                    <View className="w-[1px] bg-zinc-100" />

                    <View className="flex-1 items-center px-1">
                      <Feather name="lock" size={14} color="#8B5CF6" />
                      <Text className="text-zinc-950 text-[9px] font-black mt-1.5 text-center leading-none">Secure & Private</Text>
                      <Text className="text-zinc-400 text-[7px] font-bold text-center mt-1 leading-relaxed">Your safety and privacy ensured</Text>
                    </View>
                  </View>

                  {/* Policy Reminder Banner */}
                  <View className="bg-indigo-50/50 border border-indigo-100/40 p-3.5 rounded-2xl flex-row items-center gap-2.5 mt-2">
                    <Feather name="info" size={13} color="#4F46E5" />
                    <Text className="text-zinc-600 text-[10px] font-medium flex-1">
                      By confirming this booking, you agree to the{' '}
                      <Text 
                        onPress={() => router.push('/legal-center')} 
                        className="text-indigo-600 font-extrabold underline"
                      >
                        VIRLA Session Policies
                      </Text>
                      .
                    </Text>
                  </View>

                  {/* Confirm Booking Primary Action */}
                  <TouchableOpacity
                    activeOpacity={0.85}
                    onPress={handleConfirmBooking}
                    disabled={isConfirming}
                    className="w-full bg-[#E11D48] items-center justify-center flex-row gap-2 mt-4"
                    style={{
                      height: 58,
                      borderRadius: 16,
                      shadowColor: '#E11D48',
                      shadowOffset: { width: 0, height: 4 },
                      shadowOpacity: 0.15,
                      shadowRadius: 8,
                      elevation: 3,
                    }}
                  >
                    {isConfirming ? (
                      <ActivityIndicator size="small" color="white" />
                    ) : (
                      <>
                        <Text className="text-white text-base font-extrabold">Confirm Booking</Text>
                        <Feather name="chevron-right" size={16} color="white" />
                      </>
                    )}
                  </TouchableOpacity>

                  {/* Secure booking guarantee lock label */}
                  <View className="flex-row items-center justify-center gap-1.5 mt-1">
                    <Feather name="lock" size={11} color="#9CA3AF" />
                    <Text className="text-[#9CA3AF] text-[9px] font-bold">Your booking is 100% secure</Text>
                  </View>
                </View>
              )}

              {/* STEP 7: SUCCESS EXPERIENCE */}
              {step === 7 && (
                <BookingSuccessAnimation
                  workoutTitle={selectedExperience.title}
                  workoutDuration={selectedExperience.duration}
                  selectedDate={selectedDate}
                  selectedTime={selectedTime}
                  locationAddress={addresses.find(a => a.id === selectedAddressId)?.addressLine || 'Selected Location'}
                  successBookingId={successBookingId}
                  onViewSession={(id) => {
                    router.replace({
                      pathname: '/session-detail',
                      params: { id },
                    });
                  }}
                  onBackToHome={() => {
                    router.replace('/(tabs)');
                  }}
                />
              )}

            </View>
          </ScrollView>
        ) : null}
      </View>
    </KeyboardAvoidingView>

      {/* Footer wizard navigation buttons (Steps 1 to 5) */}
      {step <= 5 && (
        <View className="p-6 bg-white border-t border-[#E5E7EB] flex-row gap-3">
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={handleBack}
            className="flex-1 bg-zinc-50 border border-[#E5E7EB] rounded-2xl items-center justify-center"
            style={{ height: 56 }}
          >
            <Text className="text-zinc-600 text-xs font-black uppercase tracking-wider">Back</Text>
          </TouchableOpacity>
          {(step < 5 || getFilteredSlotsForPeriod().length > 0) && (
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={handleNext}
              className="flex-1 bg-zinc-950 rounded-2xl items-center justify-center"
              style={{
                height: 56,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.05,
                shadowRadius: 4,
                elevation: 2,
              }}
            >
              <Text className="text-white text-xs font-black uppercase tracking-wider">Continue</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </SafeAreaView>
  );
}
