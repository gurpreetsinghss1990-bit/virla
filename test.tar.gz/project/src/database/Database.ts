import { supabase, setClientUserId } from './supabaseClient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User, Workout, Coach, Booking, NotificationItem, Invoice, TrainerEarning, ScheduleSlot, AssignmentLog, TrainerWorkoutAssignment } from '../types';
import { normalizeDate, canonicalizeTimeRange, getBookingISTDateRange } from '../utils/date';
import { geocodeAddress, geocodeAddressSync } from '../utils/distance';

// Simple UUID generator
export function generateUUID(prefix = 'id'): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
}

// Deterministic simple hash function to avoid storing plain-text passwords
export function hashPassword(password: string): string {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return `secure-hash-${hash}-${password.length}`;
}

// --- Authoritative NTP Clock & Timezone-Safe Asia/Kolkata (IST) Helpers ---
let serverTimeOffset = 0;

export async function syncServerTime(): Promise<void> {
  try {
    const start = Date.now();
    const { data, error } = await supabase.rpc('get_server_time');
    if (data && !error) {
      const serverMs = new Date(data).getTime();
      const end = Date.now();
      const latency = (end - start) / 2;
      serverTimeOffset = (serverMs + latency) - end;
      console.log(`[NTP CLOCK] Synced with Supabase server. Offset: ${serverTimeOffset}ms (latency: ${latency}ms)`);
    } else if (error) {
      console.warn('[NTP CLOCK] get_server_time RPC error:', error);
    }
  } catch (e) {
    console.error('[NTP CLOCK] Failed to sync server time:', e);
  }
}

export function getCurrentServerTime(): Date {
  return new Date(Date.now() + serverTimeOffset);
}

export function getISTDateInfo(date: Date) {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
  const parts = formatter.formatToParts(date);
  const info: any = {};
  for (const part of parts) {
    info[part.type] = part.value;
  }
  
  const year = parseInt(info.year, 10);
  const month = parseInt(info.month, 10); // 1-12
  const day = parseInt(info.day, 10);
  const hour = parseInt(info.hour, 10);
  const minute = parseInt(info.minute, 10);
  const second = parseInt(info.second, 10);
  
  const dateString = `${info.year}-${info.month}-${info.day}`;
  
  return { year, month, day, hour, minute, second, dateString };
}

export function parseISTToUTCDate(year: number, month: number, day: number, hour: number, minute: number): Date {
  // Construct Date assuming UTC components
  const utcDate = new Date(Date.UTC(year, month - 1, day, hour, minute, 0));
  // Subtract Asia/Kolkata offset (+5:30 = 330 minutes)
  return new Date(utcDate.getTime() - 330 * 60 * 1000);
}

export function calculateDurationFromTime(timeStr: string): number {
  if (!timeStr) return 60;
  const parts = timeStr.split('-');
  const startPart = parts[0]?.trim();
  const endPart = parts[1]?.trim();
  if (!startPart || !endPart) return 60;
  
  function parseTimePart(part: string) {
    const match = part.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (!match) return { hour: 0, minute: 0 };
    let h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    const ampm = match[3].toUpperCase();
    if (ampm === 'PM' && h < 12) h += 12;
    if (ampm === 'AM' && h === 12) h = 0;
    return { hour: h, minute: m };
  }
  
  const start = parseTimePart(startPart);
  const end = parseTimePart(endPart);
  
  let startMinutes = start.hour * 60 + start.minute;
  let endMinutes = end.hour * 60 + end.minute;
  
  if (endMinutes < startMinutes) {
    endMinutes += 24 * 60; // crossover midnight
  }
  
  return endMinutes - startMinutes;
}


export function isSessionGenuinelyActive(b: Booking, now: Date): boolean {
  if (!b || b.status !== 'upcoming') return false;
  if (!['trainer_travelling', 'trainer_arrived', 'otp_verified', 'workout_started'].includes(b.timelineStatus || '')) {
    return false;
  }
  const range = getBookingISTDateRange(b);
  const travelUnlockTime = range.start.getTime() - 25 * 60 * 1000;
  return now.getTime() >= travelUnlockTime && now.getTime() <= range.end.getTime();
}

export interface UserProfile {
  id: string;
  userId: string;
  age: number;
  gender: string;
  height: string;
  weight: string;
  fitnessGoal: string;
  preferredWorkout: string;
  emergencyContact: string; // JSON string
  medicalNotes: string;
  membershipStatus: string;
  creditsBalance: number;
  trainerPreference: string;
  dob: string;
  fitnessLevel: string;
  preferredLanguage: string;
  city: string;
  memberSince: string;
  selectedGoals: string[];
  homeAddress?: string;
  homeLatitude?: number;
  homeLongitude?: number;
  homePlaceId?: string;
}

export interface HydrationLog {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  amount: number; // ml
}

export interface CalorieLog {
  id: string;
  userId: string;
  date: string; // YYYY-MM-DD
  amount: number; // kcal
}

export interface ChatMessage {
  id: string;
  chatId: string;
  sender: 'user' | 'coach' | 'virla' | 'customer' | 'trainer';
  text: string;
  timestamp: string;
  isPinned?: boolean;
  isFavorite?: boolean;
}

export interface TrainerApplication {
  id: string;
  createdAt: string;
  updatedAt: string;
  status: 'pending' | 'approved' | 'rejected' | 'info_requested';
  
  // Step 1: Personal Info
  fullName: string;
  phone: string;
  email: string;
  dob: string;
  gender: string;
  avatar: string;
  address: string;
  city: string;
  state: string;
  pinCode: string;
  emergencyContact: string; // JSON string

  // Step 2: Professional Info
  primaryWorkout: string;
  secondarySkills: string;
  yearsOfExperience: number;
  languages: string;
  aboutMe: string;
  fitnessQualifications: string;

  // Step 3: Working Preferences
  workingDays: string[];
  availabilityMorning: boolean;
  availabilityAfternoon: boolean;
  availabilityEvening: boolean;
  maxSessionsPerDay: number;
  preferredWorkingRadius: number; // km
  preferredCities: string[];

  // Step 4: Bank Details
  bankAccountName: string;
  bankName: string;
  bankAccountNumber: string;
  bankIfsc: string;
  bankUpiId: string;
  panNumber: string;
  gstNumber?: string;

  // Step 5: Verification uploads
  documentAadhaar: string;
  documentPan: string;
  documentSelfie: string;
  documentCertifications: string; // JSON string array
  aadhaarStatus?: 'pending_verification' | 'verified' | 'rejected';
  panStatus?: 'pending_verification' | 'verified' | 'rejected';
  aadhaarVerificationNotes?: string;
  panVerificationNotes?: string;
  adminNotes?: string;
  acceptedAgreementTimestamp?: string;
  acceptedAgreementAppVersion?: string;
}

export interface SavedAddress {
  id: string;
  userId: string;
  label: 'Home' | 'Office' | 'Gym' | 'Custom';
  name: string;
  building: string;
  street: string;
  landmark: string;
  city: string;
  pinCode: string;
  gpsPlaceholder?: string;
  isDefault: boolean;
  
  lat?: number;
  lng?: number;
  apartment?: string;
  floor?: string;
  notes?: string;
  placeId?: string;
}

export interface DBUser {
  id: string;
  name: string;
  phone: string;
  email: string;
  passwordHash: string;
  avatar: string;
  role: 'customer' | 'trainer' | 'admin';
  status: 'active' | 'suspended';
  createdDate: string;
  lastLogin: string;
  deviceInfo: string;
  notificationPrefs: string; // JSON string
  registrationStatus?: string;
}

// ==================== MAPPERS ====================

export function mapDBUser(row: any): DBUser {
  let regStatus = 'name_pending';
  const rawStatus = row.registration_status || '';
  if (rawStatus === 'COMPLETE' || rawStatus === 'complete') {
    regStatus = 'complete';
  } else if (
    rawStatus === 'PROFILE_DETAILS_PENDING' || 
    rawStatus === 'PROFILE_NAME_PENDING' || 
    rawStatus === 'incomplete'
  ) {
    regStatus = 'incomplete';
  }

  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    email: row.email || '',
    passwordHash: row.password_hash || '',
    avatar: row.avatar || '',
    role: row.role,
    status: row.status,
    createdDate: row.created_date || '',
    lastLogin: row.last_login || '',
    deviceInfo: row.device_info || '',
    notificationPrefs: JSON.stringify(row.notification_prefs || {}),
    registrationStatus: regStatus
  };
}

export function mapDBUserToPostgres(user: DBUser): any {
  return {
    id: user.id,
    name: user.name,
    phone: user.phone,
    email: user.email,
    password_hash: user.passwordHash,
    avatar: user.avatar,
    role: user.role,
    status: user.status,
    created_date: user.createdDate,
    last_login: user.lastLogin,
    device_info: user.deviceInfo,
    notification_prefs: JSON.parse(user.notificationPrefs || '{}'),
    registration_status: user.registrationStatus || 'PROFILE_NAME_PENDING'
  };
}

export function mapUserProfile(row: any): UserProfile {
  return {
    id: row.id,
    userId: row.user_id,
    age: row.age || 0,
    gender: row.gender || '',
    height: row.height || '',
    weight: row.weight || '',
    fitnessGoal: row.fitness_goal || '',
    preferredWorkout: row.preferred_workout || '',
    emergencyContact: JSON.stringify(row.emergency_contact || {}),
    medicalNotes: row.medical_notes || '',
    membershipStatus: row.membership_status || '',
    creditsBalance: row.credits_balance || 0,
    trainerPreference: row.trainer_preference || '',
    dob: row.dob || '',
    fitnessLevel: row.fitness_level || '',
    preferredLanguage: row.preferred_language || '',
    city: row.city || '',
    memberSince: row.member_since || '',
    selectedGoals: row.selected_goals || [],
    homeAddress: row.home_address || '',
    homeLatitude: row.home_latitude !== null && row.home_latitude !== undefined ? Number(row.home_latitude) : undefined,
    homeLongitude: row.home_longitude !== null && row.home_longitude !== undefined ? Number(row.home_longitude) : undefined,
    homePlaceId: row.home_place_id || ''
  };
}

export function mapUserProfileToPostgres(profile: UserProfile): any {
  return {
    id: profile.id,
    user_id: profile.userId,
    age: profile.age,
    gender: profile.gender,
    height: profile.height,
    weight: profile.weight,
    fitness_goal: profile.fitnessGoal,
    preferred_workout: profile.preferredWorkout,
    emergency_contact: JSON.parse(profile.emergencyContact || '{}'),
    medical_notes: profile.medicalNotes,
    membership_status: profile.membershipStatus,
    credits_balance: profile.creditsBalance,
    trainer_preference: profile.trainerPreference,
    dob: profile.dob,
    fitness_level: profile.fitnessLevel,
    preferred_language: profile.preferredLanguage,
    city: profile.city,
    member_since: profile.memberSince,
    selected_goals: profile.selectedGoals,
    home_address: profile.homeAddress || null,
    home_latitude: profile.homeLatitude !== undefined ? profile.homeLatitude : null,
    home_longitude: profile.homeLongitude !== undefined ? profile.homeLongitude : null,
    home_place_id: profile.homePlaceId || null
  };
}

export function mapCoach(row: any): Coach {
  const prefs = row.preferences ? (typeof row.preferences === 'string' ? JSON.parse(row.preferences) : row.preferences) : { online: false, radiusKm: 15, maxDailySessions: 5, categories: [] };
  
  if (row.operating_address !== undefined) prefs.operatingAddress = row.operating_address || '';
  if (row.operating_latitude !== undefined && row.operating_latitude !== null) prefs.operatingLatitude = Number(row.operating_latitude);
  if (row.operating_longitude !== undefined && row.operating_longitude !== null) prefs.operatingLongitude = Number(row.operating_longitude);
  if (row.operating_place_id !== undefined) prefs.operatingPlaceId = row.operating_place_id || '';
  if (row.operating_location_status !== undefined) prefs.operatingLocationStatus = row.operating_location_status || 'pending';
  if (row.service_radius_km !== undefined && row.service_radius_km !== null) prefs.radiusKm = Number(row.service_radius_km);
  if (row.address_change_request !== undefined) prefs.addressChangeRequest = row.address_change_request || null;

  return {
    id: row.id,
    name: row.name,
    photo: row.photo || '',
    experience: row.experience || '',
    rating: Number(row.rating) || 5.0,
    specialty: row.specialty || '',
    yearsExperience: row.years_experience || 0,
    specialization: row.specialization || '',
    languages: row.languages || [],
    shortBio: row.short_bio || '',
    price: row.price || 1200,
    verifiedBadge: row.verified_badge ?? true,
    certifications: row.certifications || [],
    achievements: row.achievements || [],
    reviews: row.reviews || [],
    workoutSpecialties: row.workout_specialties || [],
    availability: row.availability || [],
    level: row.level || 'Associate',
    completedSessions: row.completed_sessions || 0,
    isFavourite: row.is_favourite ?? false,
    weeklySlotsSubmitted: row.weekly_slots_submitted || 0,
    remainingSlotChanges: row.remaining_slot_changes || 3,
    retainerStatus: row.retainer_status || 'not_eligible',
    attendanceRate: Number(row.attendance_rate) || 100.0,
    punctualityRate: Number(row.punctuality_rate) || 100.0,
    availabilityCompliance: Number(row.availability_compliance) || 100.0,
    bankDetails: row.bank_details ? JSON.stringify(row.bank_details) : '',
    emergencyContact: row.emergency_contact ? JSON.stringify(row.emergency_contact) : '',
    aboutText: row.about_text || '',
    workingRadius: row.working_radius || '',
    gender: row.gender || null,
    preferences: prefs
  };
}

export function mapCoachToPostgres(coach: Coach): any {
  const prefs = coach.preferences || { online: false, radiusKm: 15, maxDailySessions: 5, categories: [] };
  return {
    id: coach.id,
    name: coach.name,
    photo: coach.photo,
    experience: coach.experience,
    rating: coach.rating,
    specialty: coach.specialty,
    years_experience: coach.yearsExperience,
    specialization: coach.specialization,
    languages: coach.languages,
    short_bio: coach.shortBio,
    completed_sessions: coach.completedSessions,
    is_favourite: coach.isFavourite,
    weekly_slots_submitted: coach.weeklySlotsSubmitted,
    remaining_slot_changes: coach.remainingSlotChanges,
    retainer_status: coach.retainerStatus,
    attendance_rate: coach.attendanceRate,
    punctuality_rate: coach.punctualityRate,
    availability_compliance: coach.availabilityCompliance,
    bank_details: coach.bankDetails ? JSON.parse(coach.bankDetails) : null,
    emergency_contact: coach.emergencyContact ? JSON.parse(coach.emergencyContact) : null,
    about_text: coach.aboutText,
    availability: coach.availability,
    working_radius: coach.workingRadius,
    operating_address: prefs.operatingAddress || null,
    operating_latitude: prefs.operatingLatitude !== undefined ? prefs.operatingLatitude : null,
    operating_longitude: prefs.operatingLongitude !== undefined ? prefs.operatingLongitude : null,
    operating_place_id: prefs.operatingPlaceId || null,
    operating_location_status: prefs.operatingLocationStatus || 'pending',
    service_radius_km: prefs.radiusKm || 15,
    address_change_request: prefs.addressChangeRequest || null,
    gender: coach.gender ? coach.gender.toLowerCase() : null,
    preferences: prefs
  };
}

export function mapWorkout(row: any): Workout {
  return {
    id: row.id,
    title: row.title,
    icon: row.icon || '',
    description: row.description || '',
    calories: row.calories || 300,
    duration: row.duration || 45,
    heroImage: row.hero_image || '',
    category: row.category || '',
    benefits: row.benefits || [],
    difficulty: row.difficulty || 'Medium',
    equipment: row.equipment || [],
    homeVisitBadge: row.home_visit_badge ?? true,
    sessionPrice: row.session_price || 1200,
    rating: Number(row.rating) || 4.8,
    reviews: row.reviews || [],
    faqs: row.faqs || []
  };
}

export function mapWorkoutToPostgres(w: Workout): any {
  return {
    id: w.id,
    title: w.title,
    icon: w.icon,
    description: w.description,
    calories: w.calories,
    duration: w.duration,
    hero_image: w.heroImage || '',
    category: w.category || '',
    benefits: w.benefits || [],
    difficulty: w.difficulty || 'Medium',
    equipment: w.equipment || [],
    home_visit_badge: w.homeVisitBadge ?? true,
    session_price: w.sessionPrice || 1200,
    rating: w.rating || 5.0,
    reviews: w.reviews || [],
    faqs: w.faqs || []
  };
}

export function validateBookingData(row: any): { isValid: boolean; reason?: string } {
  if (!row) {
    return { isValid: false, reason: 'Null or undefined booking row' };
  }
  if (!row.id) {
    return { isValid: false, reason: 'Missing booking ID' };
  }
  if (!row.date || !row.time) {
    return { isValid: false, reason: 'Missing date or time string' };
  }

  const parts = row.time.split('-');
  const startPart = parts[0]?.trim();
  const endPart = parts[1]?.trim();
  if (!startPart || !endPart) {
    return { isValid: false, reason: `Malformed time range: "${row.time}"` };
  }

  const calculatedDuration = calculateDurationFromTime(row.time);
  const storedDuration = row.duration_minutes || 60;

  if (calculatedDuration <= 0) {
    return { isValid: false, reason: `Invalid time range: calculated duration is ${calculatedDuration} mins` };
  }

  if (calculatedDuration !== storedDuration) {
    return { 
      isValid: false, 
      reason: `Duration mismatch: calculated duration is ${calculatedDuration} mins but stored duration is ${storedDuration} mins` 
    };
  }

  return { isValid: true };
}

export function mapBooking(row: any): Booking {
  const validation = validateBookingData(row);
  if (!validation.isValid) {
    console.error(`[DATABASE DATA INTEGRITY ERROR] Booking ${row.id} is invalid. Reason: ${validation.reason}. Record: Date=${row.date}, Time=${row.time}, Stored Duration=${row.duration_minutes}`);
  }

  const calculatedDuration = calculateDurationFromTime(row.time);
  return {
    id: row.id,
    status: row.status,
    timelineStatus: row.timeline_status ? row.timeline_status.toLowerCase() as any : undefined,
    otp: row.otp,
    clientName: row.client_name || '',
    clientPhone: row.client_phone || '',
    trainerName: row.trainer_name || '',
    trainerPhoto: row.trainer_photo || '',
    date: row.date,
    time: row.time,
    workoutTitle: row.workout_title,
    price: row.price,
    address: row.address || '',
    clientId: row.client_id || '',
    trainerId: row.trainer_id || '',
    trainerLevel: row.trainer_level,
    trainerRating: Number(row.trainer_rating) || 5.0,
    trainerCompletedSessions: row.trainer_completed_sessions,
    trainerSpeciality: row.trainer_speciality,
    trainerLanguages: row.trainer_languages || [],
    trainerDistance: row.trainer_distance,
    trainerArrivalTime: row.trainer_arrival_time,
    caloriesBurned: row.calories_burned,
    durationMinutes: calculatedDuration,
    ratingDetails: row.rating_details ? (typeof row.rating_details === 'string' ? JSON.parse(row.rating_details) : row.rating_details) : undefined,
    trainerNote: row.trainer_note || undefined,
    createdAt: row.request_created_at ? new Date(row.request_created_at).getTime() : (row.created_at ? Number(row.created_at) : undefined),
    reminderSent: row.reminder_sent ?? false,
    acceptanceNotificationCount: row.acceptance_notification_count ? Number(row.acceptance_notification_count) : undefined,
    lastAcceptanceNotificationAt: row.last_acceptance_notification_at ? Number(row.last_acceptance_notification_at) : undefined,
    acceptanceMethod: row.acceptance_method === 'SYSTEM_AUTO_ACCEPT' || row.acceptance_method === 'auto' ? 'auto' : (row.acceptance_method === 'TRAINER_MANUAL_ACCEPT' || row.acceptance_method === 'manual' ? 'manual' : undefined),
    acceptanceDeadline: row.acceptance_deadline ? Number(row.acceptance_deadline) : undefined,
    autoAcceptedAt: row.auto_accepted_at ? new Date(row.auto_accepted_at).getTime() : undefined,
    trainerAcceptedAt: row.manual_accepted_at ? new Date(row.manual_accepted_at).getTime() : (row.trainer_accepted_at ? Number(row.trainer_accepted_at) : undefined),
    participantCount: row.participant_count || 1,
    sessionType: row.session_type || 'SINGLE',
    originalPackageType: row.original_package_type || 'SINGLE',
    partnerName: row.partner_name || undefined,
    partnerPhone: row.partner_phone || undefined,
    travelStartedAt: row.travel_started_at ? new Date(row.travel_started_at).getTime() : undefined,
    workoutCompletedAt: row.session_completed_at ? new Date(row.session_completed_at).getTime() : undefined,
    workoutStartedAt: row.session_started_at ? new Date(row.session_started_at).getTime() : undefined,
    gracePeriodStartedAt: row.grace_period_started_at ? new Date(row.grace_period_started_at).getTime() : (row.trainer_arrived_at ? new Date(row.trainer_arrived_at).getTime() : undefined),
    otpExpiresAt: row.otp_expires_at ? new Date(row.otp_expires_at).getTime() : undefined,
    scheduledStartAt: row.scheduled_start_at || undefined,
    scheduledEndAt: row.scheduled_end_at || undefined,
    trainerAcknowledgement: row.trainer_acknowledgement || undefined,
    isInvalidData: !validation.isValid,
    validationError: validation.reason,
  };
}

export function mapBookingToPostgres(b: Booking): any {
  const calculatedDuration = calculateDurationFromTime(b.time);
  return {
    id: b.id,
    status: b.status,
    timeline_status: b.timelineStatus ? b.timelineStatus.toUpperCase() : null,
    otp: b.otp,
    client_name: b.clientName || '',
    client_phone: b.clientPhone || '',
    trainer_name: b.trainerName,
    trainer_photo: b.trainerPhoto,
    date: b.date,
    time: b.time,
    workout_title: b.workoutTitle,
    price: b.price || 0,
    address: b.address || '',
    client_id: b.clientId || null,
    trainer_id: b.trainerId || null,
    trainer_level: b.trainerLevel,
    trainer_rating: b.trainerRating,
    trainer_completed_sessions: b.trainerCompletedSessions,
    trainer_speciality: b.trainerSpeciality,
    trainer_languages: b.trainerLanguages,
    trainer_distance: b.trainerDistance,
    trainer_arrival_time: b.trainerArrivalTime,
    calories_burned: b.caloriesBurned,
    duration_minutes: calculatedDuration,
    rating_details: b.ratingDetails ? JSON.stringify(b.ratingDetails) : null,
    trainer_note: b.trainerNote || null,
    created_at: b.createdAt || null,
    reminder_sent: b.reminderSent || false,
    acceptance_notification_count: b.acceptanceNotificationCount || 1,
    last_acceptance_notification_at: b.lastAcceptanceNotificationAt || null,
    acceptance_method: b.acceptanceMethod || null,
    acceptance_deadline: b.acceptanceDeadline || null,
    auto_accepted_at: b.autoAcceptedAt ? new Date(b.autoAcceptedAt).toISOString() : null,
    manual_accepted_at: b.trainerAcceptedAt ? new Date(b.trainerAcceptedAt).toISOString() : null,
    participant_count: b.participantCount || 1,
    session_type: b.sessionType || 'SINGLE',
    original_package_type: b.originalPackageType || 'SINGLE',
    partner_name: b.partnerName || null,
    partner_phone: b.partnerPhone || null,
    travel_started_at: b.travelStartedAt ? new Date(b.travelStartedAt).toISOString() : null,
    session_completed_at: b.workoutCompletedAt ? new Date(b.workoutCompletedAt).toISOString() : null,
    session_started_at: b.workoutStartedAt ? new Date(b.workoutStartedAt).toISOString() : null,
    grace_period_started_at: b.gracePeriodStartedAt ? new Date(b.gracePeriodStartedAt).toISOString() : null,
    otp_expires_at: b.otpExpiresAt ? new Date(b.otpExpiresAt).toISOString() : null,
    scheduled_start_at: b.scheduledStartAt || null,
    scheduled_end_at: b.scheduledEndAt || null,
  };
}

export function mapInvoice(row: any): Invoice {
  return {
    id: row.id,
    userId: row.user_id,
    type: row.type || 'paid',
    amount: row.amount || '',
    date: row.date || '',
    status: row.status || 'paid',
    credits: row.credits || 0
  };
}

export function mapInvoiceToPostgres(inv: Invoice, userId: string): any {
  return {
    id: inv.id,
    user_id: userId,
    type: inv.type,
    amount: inv.amount,
    date: inv.date,
    status: inv.status,
    credits: inv.credits
  };
}

export function mapHydrationLog(row: any): HydrationLog {
  return {
    id: row.id,
    userId: row.user_id,
    date: row.date,
    amount: row.amount
  };
}

export function mapHydrationLogToPostgres(log: HydrationLog): any {
  return {
    id: log.id,
    user_id: log.userId,
    date: log.date,
    amount: log.amount
  };
}

export function mapCalorieLog(row: any): CalorieLog {
  return {
    id: row.id,
    userId: row.user_id,
    date: row.date,
    amount: row.amount
  };
}

export function mapCalorieLogToPostgres(log: CalorieLog): any {
  return {
    id: log.id,
    user_id: log.userId,
    date: log.date,
    amount: log.amount
  };
}

export function mapNotificationItem(row: any): NotificationItem {
  let body = row.body || '';
  let type: any = 'System';
  let priority: any = 'medium';
  let actionLabel = '';
  let deepLink = '';
  let expiry = '';

  if (body.startsWith('{"is_meta":true')) {
    try {
      const parsed = JSON.parse(body);
      body = parsed.body || '';
      type = parsed.type || 'System';
      priority = parsed.priority || 'medium';
      actionLabel = parsed.actionLabel || '';
      deepLink = parsed.deepLink || '';
      expiry = parsed.expiry || '';
    } catch (e) {
      // fallback
    }
  }

  return {
    id: row.id,
    title: row.title,
    body: body,
    read: row.read ?? false,
    timestamp: row.timestamp || '',
    group: row.group || 'today',
    icon: row.icon || '',
    type,
    priority,
    actionLabel,
    deepLink,
    expiry
  };
}

export function mapNotificationItemToPostgres(n: NotificationItem, userId: string): any {
  const bodyPayload = JSON.stringify({
    is_meta: true,
    body: n.body,
    type: n.type || 'System',
    priority: n.priority || 'medium',
    actionLabel: n.actionLabel || '',
    deepLink: n.deepLink || '',
    expiry: n.expiry || ''
  });

  return {
    id: n.id,
    user_id: userId,
    title: n.title,
    body: bodyPayload,
    read: n.read,
    timestamp: n.timestamp,
    group: n.group,
    icon: n.icon || ''
  };
}

export function mapChatMessage(row: any): ChatMessage {
  return {
    id: row.id,
    chatId: row.chat_id,
    sender: row.sender,
    text: row.text,
    timestamp: row.timestamp,
    isPinned: row.is_pinned ?? false,
    isFavorite: row.is_favorite ?? false
  };
}

export function mapChatMessageToPostgres(msg: ChatMessage): any {
  return {
    id: msg.id,
    chat_id: msg.chatId,
    sender: msg.sender,
    text: msg.text,
    timestamp: msg.timestamp,
    is_pinned: msg.isPinned,
    is_favorite: msg.isFavorite
  };
}

export function mapSavedAddress(row: any): SavedAddress {
  return {
    id: row.id,
    userId: row.user_id,
    label: row.label,
    name: row.name,
    building: row.building,
    street: row.street,
    landmark: row.landmark || '',
    city: row.city,
    pinCode: row.pin_code,
    gpsPlaceholder: row.gps_placeholder || '',
    isDefault: row.is_default,
    lat: row.lat !== null && row.lat !== undefined ? Number(row.lat) : undefined,
    lng: row.lng !== null && row.lng !== undefined ? Number(row.lng) : undefined,
    apartment: row.apartment || '',
    floor: row.floor || '',
    notes: row.notes || '',
    placeId: row.place_id || ''
  };
}

export function mapSavedAddressToPostgres(addr: SavedAddress): any {
  return {
    id: addr.id,
    user_id: addr.userId,
    label: addr.label,
    name: addr.name,
    building: addr.building,
    street: addr.street,
    landmark: addr.landmark,
    city: addr.city,
    pin_code: addr.pinCode,
    gps_placeholder: addr.gpsPlaceholder,
    is_default: addr.isDefault,
    lat: addr.lat !== undefined && addr.lat !== null ? addr.lat : null,
    lng: addr.lng !== undefined && addr.lng !== null ? addr.lng : null,
    apartment: addr.apartment || '',
    floor: addr.floor || '',
    notes: addr.notes || '',
    place_id: addr.placeId || null
  };
}

export function mapWorkoutAssignment(row: any): TrainerWorkoutAssignment {
  return {
    id: row.id,
    trainerId: row.trainer_id,
    workoutCategory: row.workout_category,
    status: row.status,
    requestedAt: Number(row.requested_at) || Date.now(),
    approvedAt: row.approved_at ? Number(row.approved_at) : undefined,
    approvedBy: row.approved_by || undefined,
    rejectedAt: row.rejected_at ? Number(row.rejected_at) : undefined,
    rejectedBy: row.rejected_by || undefined,
    rejectionReason: row.rejection_reason || undefined,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

export function mapWorkoutAssignmentToPostgres(assignment: TrainerWorkoutAssignment): any {
  return {
    id: assignment.id,
    trainer_id: assignment.trainerId,
    workout_category: assignment.workoutCategory,
    status: assignment.status,
    requested_at: assignment.requestedAt,
    approved_at: assignment.approvedAt,
    approved_by: assignment.approvedBy,
    rejected_at: assignment.rejectedAt,
    rejected_by: assignment.rejectedBy,
    rejection_reason: assignment.rejectionReason
  };
}

export function mapTrainerEarning(row: any): TrainerEarning {
  return {
    id: row.id,
    bookingId: row.booking_id,
    clientName: row.client_name,
    amount: row.amount,
    date: row.date,
    type: row.type
  };
}

export function mapTrainerEarningToPostgres(earn: TrainerEarning, trainerId: string): any {
  return {
    id: earn.id,
    trainer_id: trainerId,
    booking_id: earn.bookingId,
    client_name: earn.clientName,
    amount: earn.amount,
    date: earn.date,
    type: earn.type
  };
}

export function mapTrainerApplication(row: any): TrainerApplication {
  let certsObj: any = {};
  try {
    certsObj = row.document_certifications ? (typeof row.document_certifications === 'string' ? JSON.parse(row.document_certifications) : row.document_certifications) : {};
  } catch (e) {
    certsObj = {};
  }

  const certsList = Array.isArray(certsObj) ? certsObj : (certsObj.certifications || []);
  const aadhaarStatus = certsObj.aadhaarStatus || 'pending_verification';
  const panStatus = certsObj.panStatus || 'pending_verification';
  const aadhaarVerificationNotes = certsObj.aadhaarVerificationNotes || '';
  const panVerificationNotes = certsObj.panVerificationNotes || '';
  const adminNotes = certsObj.adminNotes || '';
  const acceptedAgreementTimestamp = certsObj.acceptedAgreementTimestamp || '';
  const acceptedAgreementAppVersion = certsObj.acceptedAgreementAppVersion || '';

  return {
    id: row.id,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    status: row.status,
    fullName: row.full_name,
    phone: row.phone,
    email: row.email,
    dob: row.dob,
    gender: row.gender,
    avatar: row.avatar || '',
    address: row.address,
    city: row.city,
    state: row.state,
    pinCode: row.pin_code,
    emergencyContact: JSON.stringify(row.emergency_contact || {}),
    primaryWorkout: row.primary_workout,
    secondarySkills: row.secondary_skills,
    yearsOfExperience: row.years_of_experience,
    languages: row.languages,
    aboutMe: row.about_me,
    fitnessQualifications: row.fitness_qualifications,
    workingDays: row.working_days || [],
    availabilityMorning: row.availability_morning,
    availabilityAfternoon: row.availability_afternoon,
    availabilityEvening: row.availability_evening,
    maxSessionsPerDay: row.max_sessions_per_day,
    preferredWorkingRadius: row.preferred_working_radius,
    preferredCities: row.preferred_cities || [],
    bankAccountName: row.bank_account_name || '',
    bankName: row.bank_name || '',
    bankAccountNumber: row.bank_account_number || '',
    bankIfsc: row.bank_ifsc || '',
    bankUpiId: row.bank_upi_id || '',
    panNumber: row.pan_number,
    gstNumber: row.gst_number || '',
    documentAadhaar: row.document_aadhaar,
    documentPan: row.document_pan,
    documentSelfie: row.document_selfie,
    documentCertifications: JSON.stringify(certsList),
    aadhaarStatus,
    panStatus,
    aadhaarVerificationNotes,
    panVerificationNotes,
    adminNotes,
    acceptedAgreementTimestamp,
    acceptedAgreementAppVersion
  };
}

export function mapTrainerApplicationToPostgres(app: TrainerApplication): any {
  let certsList = [];
  try {
    certsList = JSON.parse(app.documentCertifications || '[]');
  } catch (e) {
    certsList = [];
  }

  const certsObj = {
    certifications: certsList,
    aadhaarStatus: app.aadhaarStatus || 'pending_verification',
    panStatus: app.panStatus || 'pending_verification',
    aadhaarVerificationNotes: app.aadhaarVerificationNotes || '',
    panVerificationNotes: app.panVerificationNotes || '',
    adminNotes: app.adminNotes || '',
    acceptedAgreementTimestamp: app.acceptedAgreementTimestamp || '',
    acceptedAgreementAppVersion: app.acceptedAgreementAppVersion || ''
  };

  return {
    id: app.id,
    created_at: app.createdAt,
    updated_at: app.updatedAt,
    status: app.status,
    full_name: app.fullName,
    phone: app.phone,
    email: app.email,
    dob: app.dob,
    gender: app.gender,
    avatar: app.avatar,
    address: app.address,
    city: app.city,
    state: app.state,
    pin_code: app.pinCode,
    emergency_contact: JSON.parse(app.emergencyContact || '{}'),
    primary_workout: app.primaryWorkout,
    secondary_skills: app.secondarySkills,
    years_of_experience: app.yearsOfExperience,
    languages: app.languages,
    about_me: app.aboutMe,
    fitness_qualifications: app.fitnessQualifications,
    working_days: app.workingDays,
    availability_morning: app.availabilityMorning,
    availability_afternoon: app.availabilityAfternoon,
    availability_evening: app.availabilityEvening,
    max_sessions_per_day: app.maxSessionsPerDay,
    preferred_working_radius: app.preferredWorkingRadius,
    preferred_cities: app.preferredCities,
    bank_account_name: app.bankAccountName || '',
    bank_name: app.bankName || '',
    bank_account_number: app.bankAccountNumber || '',
    bank_ifsc: app.bankIfsc || '',
    bank_upi_id: app.bankUpiId || '',
    pan_number: app.panNumber,
    gst_number: app.gstNumber,
    document_aadhaar: app.documentAadhaar,
    document_pan: app.documentPan,
    document_selfie: app.documentSelfie,
    document_certifications: certsObj
  };
}

const STORAGE_KEY = 'virla_production_database';

class DatabaseClient {
  public schema: {
    users: DBUser[];
    profiles: UserProfile[];
    coaches: Coach[];
    workouts: Workout[];
    bookings: Booking[];
    credit_transactions: Invoice[];
    payments: any[];
    hydration: HydrationLog[];
    calories: CalorieLog[];
    notifications: NotificationItem[];
    messages: ChatMessage[];
    addresses: SavedAddress[];
    earnings: TrainerEarning[];
    schedules: ScheduleSlot[];
    trainer_applications: any[];
    assignment_logs: AssignmentLog[];
    slot_reservations: any[];
    trainer_workout_assignments: TrainerWorkoutAssignment[];
    client_disputes: any[];
    kit_requests: any[];
  } = {
    users: [],
    profiles: [],
    coaches: [],
    workouts: [],
    bookings: [],
    credit_transactions: [],
    payments: [],
    hydration: [],
    calories: [],
    notifications: [],
    messages: [],
    addresses: [],
    earnings: [],
    schedules: [],
    trainer_applications: [],
    assignment_logs: [],
    slot_reservations: [],
    trainer_workout_assignments: [],
    client_disputes: [],
    kit_requests: []
  };

  private currentUserId: string | null = null;
  private isLoaded = false;
  public loadSource: 'supabase' | 'cache' | 'none' = 'none';

  constructor() {
    this.load();
  }

  generateUUID(prefix = 'id'): string {
    return generateUUID(prefix);
  }

  private log(action: string, details: string) {
    console.log(`[DB LOG] [${new Date().toISOString()}] Action: ${action} | Details: ${details}`);
  }

  async reload(): Promise<void> {
    console.log('[DEBUG-DB] Database.reload() invoked. Resetting isLoaded and fetching fresh collections...');
    this.isLoaded = false;
    await this.load();
  }

  async resetAndClearLocalOnly(): Promise<void> {
    console.log('[DEBUG-DB] Database.resetAndClearLocalOnly() called. Clearing session and local memory caches...');
    this.currentUserId = null;
    this.isLoaded = false;
    
    // Clear only local cached collections
    this.schema.bookings = [];
    this.schema.notifications = [];
    this.schema.messages = [];
    this.schema.addresses = [];
    this.schema.credit_transactions = [];
    this.schema.hydration = [];
    this.schema.calories = [];
    this.schema.earnings = [];
    
    if (typeof AsyncStorage !== 'undefined') {
      try {
        await AsyncStorage.removeItem(STORAGE_KEY);
      } catch (err) {
        console.error('[DB ERROR] Failed to clear offline database AsyncStorage cache:', err);
      }
    }
  }

  private async safeQuery(promise: any, tableName: string): Promise<any> {
    try {
      const res = await promise;
      if (res && res.error) {
        console.warn(`[DEBUG-DB] safeQuery error for table "${tableName}":`, res.error);
        return { data: [], error: null };
      }
      return res;
    } catch (err: any) {
      console.warn(`[DEBUG-DB] safeQuery exception for table "${tableName}":`, err);
      return { data: [], error: null };
    }
  }

  async load(): Promise<void> {
    console.log('[DEBUG-DB] Database.load() called. isLoaded:', this.isLoaded);
    if (this.isLoaded) return;
    try {
      this.log('LoadDatabase', 'Loading database collections from Supabase...');
      
      const fetchPromise = Promise.all([
        this.safeQuery(supabase.from('users').select('*'), 'users'),
        this.safeQuery(supabase.from('user_profiles').select('*'), 'user_profiles'),
        this.safeQuery(supabase.from('trainers').select('*'), 'trainers'),
        this.safeQuery(supabase.from('workouts').select('*'), 'workouts'),
        this.safeQuery(supabase.from('bookings').select('*'), 'bookings'),
        this.safeQuery(supabase.from('credit_transactions').select('*'), 'credit_transactions'),
        this.safeQuery(supabase.from('hydration_logs').select('*'), 'hydration_logs'),
        this.safeQuery(supabase.from('calorie_logs').select('*'), 'calorie_logs'),
        this.safeQuery(supabase.from('notifications').select('*'), 'notifications'),
        this.safeQuery(supabase.from('chat_messages').select('*'), 'chat_messages'),
        this.safeQuery(supabase.from('addresses').select('*'), 'addresses'),
        this.safeQuery(supabase.from('trainer_earnings').select('*'), 'trainer_earnings'),
        this.safeQuery(supabase.from('trainer_applications').select('*'), 'trainer_applications')
      ]);

      const timeoutPromise = new Promise<any>((_, reject) =>
        setTimeout(() => reject(new Error('Supabase load query timed out')), 15000)
      );

      const [
        resUsers,
        resProfiles,
        resTrainers,
        resWorkouts,
        resBookings,
        resTransactions,
        resHydration,
        resCalories,
        resNotifications,
        resMessages,
        resAddresses,
        resEarnings,
        resApps
      ] = await Promise.race([fetchPromise, timeoutPromise]);

      // Populate local caches using mapper functions
      this.schema.users = (resUsers.data || []).map(mapDBUser);
      this.schema.profiles = (resProfiles.data || []).map(mapUserProfile);
      this.schema.coaches = (resTrainers.data || []).map(mapCoach);
      this.schema.workouts = (resWorkouts.data || []).map(mapWorkout);
      this.schema.bookings = (resBookings.data || []).map(mapBooking).filter((b: Booking) => !b.isInvalidData);
      this.runBackgroundSyncChecks();
      this.schema.credit_transactions = (resTransactions.data || []).map(mapInvoice);
      this.schema.hydration = (resHydration.data || []).map(mapHydrationLog);
      this.schema.calories = (resCalories.data || []).map(mapCalorieLog);
      this.schema.notifications = (resNotifications.data || []).map(mapNotificationItem);
      this.schema.messages = (resMessages.data || []).map(mapChatMessage);
      this.schema.addresses = (resAddresses.data || []).map(mapSavedAddress);
      this.schema.earnings = (resEarnings.data || []).map(mapTrainerEarning);
      this.schema.trainer_applications = (resApps.data || []).map(mapTrainerApplication);

      // Seed workouts and trainers in Supabase if database is empty (Development only)
      // Disabled to prevent seed/mock data contamination
      /*
      if (typeof __DEV__ !== 'undefined' && __DEV__) {
        await this.seedData();
      }
      */

      // Safely query slot_reservations (in case SQL migrations haven't run yet)
      try {
        const { data: resReservations, error: resResError } = await supabase.from('slot_reservations').select('*');
        if (resReservations && !resResError) {
          this.schema.slot_reservations = resReservations;
        }
      } catch (resErr) {
        console.log('[DEBUG-DB] slot_reservations table not yet configured:', resErr);
      }

      // Safely query trainer_workout_assignments
      try {
        const { data: resAssignments, error: resAssError } = await supabase.from('trainer_workout_assignments').select('*');
        if (resAssignments && !resAssError) {
          this.schema.trainer_workout_assignments = resAssignments.map(mapWorkoutAssignment);
        }
      } catch (resErr) {
        console.log('[DEBUG-DB] trainer_workout_assignments table not yet configured:', resErr);
      }

      this.syncCoachesWithAssignments();
      await syncServerTime();
      console.log('[DEBUG-DB] Database.load() completed successfully from Supabase.');
      this.isLoaded = true;
      this.loadSource = 'supabase';
      this.log('LoadDatabase', 'Successfully synchronized local cache from Supabase');
      
      this.save();
      await this.syncLocalDataToSupabase();
    } catch (err) {
      console.log('[DEBUG-DB] Database.load() error caught. Falling back. Error:', err);
      console.error('[DB ERROR] Failed to load database from Supabase, trying AsyncStorage fallback:', err);
      // Fallback to AsyncStorage cache if offline/error
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        this.schema = {
          ...this.schema,
          ...parsed,
          trainer_applications: parsed.trainer_applications || [],
          client_disputes: parsed.client_disputes || [],
          kit_requests: parsed.kit_requests || []
        };
      }
      this.syncCoachesWithAssignments();
      this.isLoaded = true;
      this.loadSource = 'cache';
      await this.syncLocalDataToSupabase();
    }
  }

  async syncLocalDataToSupabase(): Promise<void> {
    const userId = this.getCurrentUserId();
    if (!userId) return;
    
    // 1. Sync disputes
    if (this.schema.client_disputes && this.schema.client_disputes.length > 0) {
      console.log(`[DB Sync] Syncing ${this.schema.client_disputes.length} local disputes to Supabase...`);
      for (const d of this.schema.client_disputes) {
        try {
          const { data, error } = await supabase
            .from('disputes')
            .select('id')
            .eq('description', d.description)
            .eq('category', d.category)
            .eq('trainer_id', d.trainerId || userId);
            
          if (!error && (!data || data.length === 0)) {
            await supabase.from('disputes').insert({
              trainer_id: d.trainerId || userId,
              booking_id: d.bookingId || null,
              category: d.category,
              description: d.description,
              status: d.status?.toUpperCase() || 'OPEN'
            });
          }
        } catch (err: any) {
          console.error('[DB Sync] Error syncing dispute:', err.message);
        }
      }
      this.schema.client_disputes = [];
      this.save();
    }

    // 2. Sync kit requests
    if (this.schema.kit_requests && this.schema.kit_requests.length > 0) {
      console.log(`[DB Sync] Syncing ${this.schema.kit_requests.length} local kit requests to Supabase...`);
      for (const k of this.schema.kit_requests) {
        try {
          const { data, error } = await supabase
            .from('kit_orders')
            .select('id')
            .eq('trainer_id', k.trainerId || userId)
            .eq('items', k.items);
            
          if (!error && (!data || data.length === 0)) {
            let normalizedItems: { [key: string]: number } = {};
            if (Array.isArray(k.items)) {
              k.items.forEach((item: string) => {
                normalizedItems[item] = 1;
              });
            } else if (typeof k.items === 'object' && k.items !== null) {
              normalizedItems = k.items;
            } else {
              normalizedItems = { 'T-shirt': 1 };
            }

            await supabase.from('kit_orders').insert({
              trainer_id: k.trainerId || userId,
              items: normalizedItems,
              tshirt_size: k.size || k.tshirt_size || null,
              status: k.status?.toUpperCase() || 'SUBMITTED'
            });
          }
        } catch (err: any) {
          console.error('[DB Sync] Error syncing kit request:', err.message);
        }
      }
      this.schema.kit_requests = [];
      this.save();
    }
  }

  syncCoachesWithAssignments(): void {
    if (!this.schema.coaches) return;
    const assignments = this.schema.trainer_workout_assignments || [];
    
    const CATEGORY_DISPLAY_MAP: Record<string, string> = {
      'Strength': 'Strength Training',
      'Mind & Body': 'Yoga',
      'Cardio': 'Dance Fitness',
      'Conditioning': 'Stretching',
      'Boxing': 'Boxing',
      'Aerial Yoga': 'Aerial Yoga',
      'All Workouts': 'All Workouts'
    };

    this.schema.coaches.forEach(coach => {
      const approvedCats = assignments
        .filter(a => a.trainerId === coach.id && a.status === 'APPROVED')
        .map(a => CATEGORY_DISPLAY_MAP[a.workoutCategory] || a.workoutCategory);
      coach.workoutSpecialties = approvedCats;

      // Sync missing gender from user profile if not set in trainers table
      if (!coach.gender) {
        const profile = this.schema.profiles?.find(p => p.userId === coach.id);
        if (profile && profile.gender) {
          coach.gender = profile.gender.toLowerCase();
        }
      }
    });
  }

  private async save(): Promise<void> {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(this.schema));
    } catch (err) {
      console.error('[DB ERROR] Failed to save database:', err);
    }
  }

  private async seedData() {
    let mutated = false;

    // Seed coaches if empty
    if (this.schema.coaches.length === 0) {
      const initialCoaches: Coach[] = [
        {
          id: 'c-1',
          name: 'Karan Sharma',
          photo: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&w=300&q=80',
          experience: '8 yrs exp',
          rating: 4.9,
          specialty: 'Strength & HIIT',
          yearsExperience: 8,
          specialization: 'Strength Training, Muscle Hypertrophy & High Intensity Cardio',
          languages: ['English', 'Hindi', 'Punjabi'],
          shortBio: 'Certified personal trainer with a passion for helping clients build long-term athletic strength and lean muscle from home.',
          price: 1200,
          verifiedBadge: true,
          certifications: ['ACE Certified Personal Trainer', 'ISSA Strength & Conditioning Specialist', 'CPR/AED Certified'],
          achievements: ['Trained 450+ clients across India', 'Featured in FitIndia Magazine 2025', 'Specialist Coach of the Year 2025 (VIRLA)'],
          reviews: [
            { reviewerName: 'Rahul V.', rating: 5, comment: 'Karan completely changed how I think about home workouts. High energy and great technique corrections!' },
            { reviewerName: 'Amit S.', rating: 4.8, comment: 'Punctual, professional, and very encouraging. Highly recommend him for strength training!' }
          ],
          workoutSpecialties: ['Strength Training', 'HIIT', 'Boxing', 'Mobility'],
          availability: ['07:00 AM - 08:00 AM', '08:00 AM - 09:00 AM', '09:00 AM - 10:00 AM', '05:00 PM - 06:00 PM', '07:00 PM - 08:00 PM'],
          level: 'Certified',
          completedSessions: 245,
          isFavourite: false
        },
        {
          id: 'c-2',
          name: 'Priya Patel',
          photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
          experience: '6 yrs exp',
          rating: 4.8,
          specialty: 'Yoga & Pilates',
          yearsExperience: 6,
          specialization: 'Vinyasa Flow, Ashtanga Yoga, Core Rehabilitation & Pilates',
          languages: ['English', 'Gujarati', 'Hindi'],
          shortBio: 'Dedicated Yoga and Pilates teacher focusing on posture correction, core alignment, and stress reduction through breathwork.',
          price: 1100,
          verifiedBadge: true,
          certifications: ['RYT 500 Yoga Alliance Certified', 'Balanced Body Pilates Instructor', 'Pre-Natal & Post-Natal Yoga Specialist'],
          achievements: ['Conducted 600+ wellness hours', 'Co-founded MindfulFlow Retreats', 'Yoga Expert panelist for Wellness Weekly'],
          reviews: [
            { reviewerName: 'Sneha M.', rating: 5, comment: 'Priya has a wonderful calming presence. Her posture adjustments are incredibly helpful!' },
            { reviewerName: 'Deepa K.', rating: 4.6, comment: 'Perfect mix of strength and mindfulness. Loved the pregnancy guidance.' }
          ],
          workoutSpecialties: ['Yoga', 'Pilates', 'Stretching', 'Pregnancy Fitness'],
          availability: ['07:00 AM - 08:00 AM', '09:00 AM - 10:00 AM', '10:00 AM - 11:00 AM', '05:00 PM - 06:00 PM', '09:00 PM - 10:00 PM'],
          level: 'Certified',
          completedSessions: 190,
          isFavourite: true
        },
        {
          id: 'c-3',
          name: 'Rohan Mehta',
          photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
          experience: '10 yrs exp',
          rating: 4.95,
          specialty: 'Boxing & Athletics',
          yearsExperience: 10,
          specialization: 'Boxing, Kickboxing, Functional Cardio & Speed-Agility training',
          languages: ['English', 'Hindi', 'Marathi'],
          shortBio: 'Former national level kickboxer offering dynamic boxing fitness and high-intensity agility workouts directly at your home.',
          price: 1500,
          verifiedBadge: true,
          certifications: ['WAKO Certified Kickboxing Coach', 'National Academy of Sports Medicine (NASM) CPT', 'FMS Level 1 Functional Movement Specialist'],
          achievements: ['National Kickboxing Bronze Medalist', 'Trainer to celebrity corporate executives', 'VIRLA Elite Master Trainer designation'],
          reviews: [
            { reviewerName: 'Vikram R.', rating: 5, comment: 'Rohan brings boxing gym energy to your living room. Brutal but incredibly satisfying workout!' },
            { reviewerName: 'Rohit J.', rating: 4.9, comment: 'Amazing pads drills. His attention to footwork and form is outstanding.' }
          ],
          workoutSpecialties: ['Boxing', 'HIIT', 'Strength Training', 'Mobility'],
          availability: ['07:00 AM - 08:00 AM', '08:00 AM - 09:00 AM', '05:00 PM - 06:00 PM', '07:00 PM - 08:00 PM', '09:00 PM - 10:00 PM'],
          level: 'Elite',
          completedSessions: 480,
          isFavourite: true
        },
        {
          id: 'c-4',
          name: 'Anjali Rao',
          photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
          experience: '5 yrs exp',
          rating: 4.75,
          specialty: 'Dance & Stretching',
          yearsExperience: 5,
          specialization: 'Zumba Fitness, Dance Conditioning & Passive Decompression Stretching',
          languages: ['English', 'Kannada', 'Hindi'],
          shortBio: 'High-energy dance fitness instructor and passive stretching therapist specializing in active recovery and cardiovascular conditioning.',
          price: 1000,
          verifiedBadge: false,
          certifications: ['Licensed Zumba Instructor (L1 & L2)', 'AFAA Group Fitness Certification', 'Therapeutic Stretching Specialist'],
          achievements: ['Choreographed virtual wellness events for corporate giants', 'VIRLA Rising Star Coach award nominee', 'Certified 100+ seniors in active aging exercises'],
          reviews: [
            { reviewerName: 'Priyanka D.', rating: 4.8, comment: 'So much fun! The dance routines fly by, and I burn close to 400 calories every time.' },
            { reviewerName: 'Nisha G.', rating: 4.7, comment: 'Anjali is super positive. Her stretching session cured my chronic lower back stiffness.' }
          ],
          workoutSpecialties: ['Dance Fitness', 'Stretching', 'Senior Fitness', 'Mobility'],
          availability: ['07:00 AM - 08:00 AM', '09:00 AM - 10:00 AM', '04:00 PM - 05:00 PM', '05:00 PM - 06:00 PM', '07:00 PM - 08:00 PM'],
          level: 'Associate',
          completedSessions: 95,
          isFavourite: false
        }
      ];
      this.schema.coaches = initialCoaches;
      await supabase.from('trainers').insert(initialCoaches.map(mapCoachToPostgres));
      mutated = true;
    }

    // Seed trainer users in database if missing
    for (const coach of this.schema.coaches) {
      const exists = this.schema.users.find(u => u.name === coach.name);
      if (!exists) {
        const phoneMap: any = {
          'Karan Sharma': '9999988888',
          'Priya Patel': '9999977777',
          'Rohan Mehta': '9999966666',
          'Anjali Rao': '9999955555'
        };
        const phone = phoneMap[coach.name] || `99999${coach.id.replace('c-', '')}`;
        const trainerUser: DBUser = {
          id: coach.id.replace('c-', 'u-'),
          name: coach.name,
          phone,
          email: `${coach.name.toLowerCase().replace(/ /g, '.')}@virla.in`,
          passwordHash: hashPassword('123456'),
          avatar: coach.photo,
          role: 'trainer',
          status: 'active',
          createdDate: new Date().toLocaleDateString(),
          lastLogin: new Date().toISOString(),
          deviceInfo: 'Seeded Trainer Account',
          notificationPrefs: JSON.stringify({
            bookingUpdates: true,
            trainerMessages: true,
            offers: false,
            membershipAlerts: true
          })
        };
        this.schema.users.push(trainerUser);
        await supabase.from('users').insert(mapDBUserToPostgres(trainerUser));
        mutated = true;
      }
    }

    // Seed workout assignments if empty
    if (!this.schema.trainer_workout_assignments || this.schema.trainer_workout_assignments.length === 0) {
      const initialAssignments: TrainerWorkoutAssignment[] = [];
      const coachSpecs: Record<string, string[]> = {
        'c-1': ['Strength', 'Boxing'],
        'c-2': ['Mind & Body', 'Conditioning'],
        'c-3': ['Boxing', 'Strength'],
        'c-4': ['Cardio', 'Conditioning']
      };

      for (const coachId in coachSpecs) {
        for (const cat of coachSpecs[coachId]) {
          initialAssignments.push({
            id: `twa-seed-${coachId}-${cat.replace(/ /g, '-')}`,
            trainerId: coachId,
            workoutCategory: cat,
            status: 'APPROVED',
            requestedAt: Date.now() - 1000 * 60 * 60 * 24 * 7, // 7 days ago
            approvedAt: Date.now() - 1000 * 60 * 60 * 24 * 6,
            approvedBy: 'admin-seed',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
        }
      }
      this.schema.trainer_workout_assignments = initialAssignments;
      await supabase.from('trainer_workout_assignments').insert(initialAssignments.map(mapWorkoutAssignmentToPostgres));
      mutated = true;
    }

    // Seed workouts if empty
    if (this.schema.workouts.length === 0) {
      const initialWorkouts: Workout[] = [
        {
          id: 'w-1',
          title: 'PowerForge',
          icon: '💪',
          description: 'Build Strength. Build Confidence. Elite resistance training structured around bodyweight, resistance bands, and custom weights to build lean muscle and speed up metabolism.',
          calories: 320,
          duration: 45,
          heroImage: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80',
          category: 'Strength',
          benefits: ['Increase muscle mass & bone density', 'Boost resting metabolic rate', 'Improve joint support & posture'],
          difficulty: 'Medium - Hard',
          equipment: ['Dumbbells or Resistance bands (Trainer will bring them)', 'Workout mat'],
          homeVisitBadge: true,
          sessionPrice: 1200,
          rating: 4.9,
          reviews: [{ reviewerName: 'Rohit K.', rating: 5, comment: 'Great strength workout! The coach brought all the resistance bands.' }],
          faqs: [{ question: 'What space do I need?', answer: 'A standard living room space (around 6x6 feet) is more than enough for a full session.' }]
        },
        {
          id: 'w-2',
          title: 'ZenFlow',
          icon: '🧘‍♀️',
          description: 'Balance Mind & Body. Gentle, guided yoga sequences focusing on alignment, breathing work, and deep flexibility to eliminate work stress and joint stiffness.',
          calories: 180,
          duration: 50,
          heroImage: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=800&q=80',
          category: 'Mind & Body',
          benefits: ['Enhance balance & posture', 'Reduce stress & mental fatigue', 'Improve core flexibility & mobility'],
          difficulty: 'Beginner - Medium',
          equipment: ['Yoga mat (Trainer will bring one if needed)', 'Yoga blocks'],
          homeVisitBadge: true,
          sessionPrice: 1100,
          rating: 4.8,
          reviews: [{ reviewerName: 'Sneha M.', rating: 5, comment: 'Very peaceful. Great breathing exercises at the end. Recommended!' }],
          faqs: [{ question: 'Do I need blocks?', answer: 'If you have blocks it is good, otherwise the trainer will provide them.' }]
        },
        {
          id: 'w-3',
          title: 'CoreAlign',
          icon: '🧘',
          description: 'Core Stability & Posture. Specialized Pilates sessions that target deep abdominal stabilizers, spinal alignment, and postural core balance.',
          calories: 220,
          duration: 45,
          heroImage: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=800&q=80',
          category: 'Mind & Body',
          benefits: ['Deep abdominal strength', 'Spinal alignment', 'Lean muscle toning'],
          difficulty: 'Medium',
          equipment: ['Pilates mat (provided)', 'Resistance circle (provided)'],
          homeVisitBadge: true,
          sessionPrice: 1300,
          rating: 4.85
        },
        {
          id: 'w-4',
          title: 'RhythmX',
          icon: '💃',
          description: 'Move. Sweat. Enjoy. Cardio-intensive dance cardio workouts syncing rhythm, music beats, and energetic movements to burn max calories while having fun.',
          calories: 380,
          duration: 45,
          heroImage: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=800&q=80',
          category: 'Cardio',
          benefits: ['Cardiovascular conditioning', 'Full body coordination', 'Endorphin release'],
          difficulty: 'Medium',
          equipment: ['Comfy sports shoes', 'Water bottle'],
          homeVisitBadge: true,
          sessionPrice: 1000,
          rating: 4.8
        },
        {
          id: 'w-5',
          title: 'KinetiX',
          icon: '⚡',
          description: 'Functional Agility & Balance. Multi-planar conditioning that mimics daily movement biomechanics to build strength, mobility, and lower injury risks.',
          calories: 300,
          duration: 45,
          heroImage: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?auto=format&fit=crop&w=800&q=80',
          category: 'Conditioning',
          benefits: ['Better daily life agility', 'Lower injury risk', 'Full body coordination'],
          difficulty: 'Medium',
          equipment: ['Kettlebells (provided)', 'Resistance bands (provided)', 'Mat'],
          homeVisitBadge: true,
          sessionPrice: 1200,
          rating: 4.8
        },
        {
          id: 'w-8',
          title: 'FightLab',
          icon: '🥊',
          description: 'Train Like a Champion. Learn kickboxing combos, speed pad punching, and conditioning drills with a professional personal trainer guiding your guard.',
          calories: 450,
          duration: 40,
          heroImage: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&w=800&q=80',
          category: 'Cardio',
          benefits: ['High calorie cardiovascular burn', 'Enhance hand-eye coordination & reflex', 'Relieve stress & build stamina'],
          difficulty: 'Hard',
          equipment: ['Boxing pads & gloves (Trainer will provide)', 'Hand wraps (optional)'],
          homeVisitBadge: true,
          sessionPrice: 1300,
          rating: 4.9,
          reviews: [{ reviewerName: 'Kabir B.', rating: 5, comment: 'Brutal but incredibly satisfying workout! Punching pads is the best.' }],
          faqs: [{ question: 'Do I need boxing gloves?', answer: 'No, the trainer will bring sanitized, high-quality focus pads and gloves for you.' }]
        },
        {
          id: 'w-aerial',
          title: 'ZenFlow Aerial',
          icon: '🧘‍♀️',
          description: 'Defy gravity. Perform guided yoga stretches and core decompression exercises supported by a premium silk hammock to boost spinal flexibility.',
          calories: 210,
          duration: 55,
          heroImage: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=800&q=80',
          category: 'Aerial Yoga',
          benefits: ['Spinal decompression & core alignment', 'Deep upper body & shoulder flexibility', 'Build functional core strength'],
          difficulty: 'Beginner - Medium',
          equipment: ['Aerial hammock', 'Yoga mat'],
          homeVisitBadge: true,
          sessionPrice: 1500,
          rating: 5.0,
          reviews: [],
          faqs: [{ question: 'How is the hammock anchored?', answer: 'The trainer will bring a premium portable suspension frame that does not damage ceiling or walls.' }]
        }
      ];
      this.schema.workouts = initialWorkouts;
      await supabase.from('workouts').insert(initialWorkouts.map(mapWorkoutToPostgres));
      mutated = true;
    }

    if (mutated) {
      await this.save();
    }
  }

  // Auth Operations
  async register(name: string, phone: string, passwordPlain: string): Promise<User> {
    await this.load();
    const existing = this.schema.users.find(u => u.phone === phone);
    if (existing) {
      throw new Error('An account with this mobile number already exists');
    }

    let userId = generateUUID('u');
    let userRole: 'customer' | 'trainer' | 'admin' = 'customer';

    // Identity-reconciliation strategy for approved trainers re-registering
    const approvedApp = this.schema.trainer_applications.find(a => a.phone === phone && a.status === 'approved');
    if (approvedApp) {
      const existingCoach = this.schema.coaches.find(c => c.name === approvedApp.fullName);
      if (existingCoach) {
        userId = existingCoach.id;
        userRole = 'trainer';
        // Make sure we delete any leftover user row under that same ID
        this.schema.users = this.schema.users.filter(u => u.id !== userId);
        await supabase.from('users').delete().eq('id', userId);
      }
    }

    const passwordHash = hashPassword(passwordPlain);

    const newUser: DBUser = {
      id: userId,
      name,
      phone,
      email: '',
      passwordHash,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      role: userRole,
      status: 'active',
      createdDate: new Date().toLocaleDateString(),
      lastLogin: new Date().toISOString(),
      deviceInfo: 'Simulator',
      notificationPrefs: JSON.stringify({
        bookingUpdates: true,
        trainerMessages: true,
        offers: false,
        membershipAlerts: true,
        workoutReminders: true,
        progressReports: true,
        promotions: false,
        emailNotifications: true,
        smsNotifications: true,
        pushNotifications: true
      })
    };

    const newProfile: UserProfile = {
      id: generateUUID('prof'),
      userId,
      age: 0,
      gender: '',
      height: '',
      weight: '',
      fitnessGoal: '',
      preferredWorkout: '',
      emergencyContact: '{}',
      medicalNotes: '',
      membershipStatus: 'Standard',
      creditsBalance: 0,
      trainerPreference: '',
      dob: '',
      fitnessLevel: '',
      preferredLanguage: 'English',
      city: '',
      memberSince: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      selectedGoals: []
    };

    this.schema.users.push(newUser);
    this.schema.profiles.push(newProfile);
    this.currentUserId = userId;

    const { error } = await supabase.rpc('create_user_with_profile', {
      user_row: mapDBUserToPostgres(newUser),
      profile_row: mapUserProfileToPostgres(newProfile)
    });

    if (error) {
      throw new Error(`Database signup failed: ${error.message}`);
    }

    await this.save();
    this.log('UserRegistration', `Registered user ${name} (${phone})`);
    return {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      avatar: newUser.avatar,
      location: 'Mumbai, India',
      role: newUser.role
    };
  }

  async login(phone: string, passwordPlain: string): Promise<User> {
    await this.load();
    const hash = hashPassword(passwordPlain);
    const user = this.schema.users.find(u => u.phone === phone && u.passwordHash === hash);
    if (!user) {
      throw new Error('Invalid mobile number or password');
    }

    user.lastLogin = new Date().toISOString();
    this.currentUserId = user.id;

    await supabase.from('users').update({ last_login: user.lastLogin }).eq('id', user.id);

    await this.save();
    this.log('UserLogin', `Logged in user ${user.name} (${phone})`);
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      avatar: user.avatar,
      location: 'Mumbai, India',
      role: user.role
    };
  }

  async oauthLogin(provider: string, providerId: string, name: string, email?: string, role: 'customer' | 'trainer' | 'admin' = 'customer'): Promise<User> {
    await this.load();
    const userEmail = email || `${providerId}@${provider}.com`;
    let user = this.schema.users.find(u => u.email === userEmail);
    if (!user) {
      const userId = generateUUID('u');
      user = {
        id: userId,
        name,
        phone: '',
        email: userEmail,
        passwordHash: hashPassword(providerId),
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        role,
        status: 'active',
        createdDate: new Date().toLocaleDateString(),
        lastLogin: new Date().toISOString(),
        deviceInfo: 'OAuth',
        notificationPrefs: JSON.stringify({
          bookingUpdates: true,
          trainerMessages: true,
          offers: false,
          membershipAlerts: true,
          workoutReminders: true,
          progressReports: true,
          promotions: false,
          emailNotifications: true,
          smsNotifications: true,
          pushNotifications: true
        })
      };

      const newProfile: UserProfile = {
        id: generateUUID('prof'),
        userId,
        age: 0,
        gender: '',
        height: '',
        weight: '',
        fitnessGoal: '',
        preferredWorkout: '',
        emergencyContact: '{}',
        medicalNotes: '',
        membershipStatus: 'Standard',
        creditsBalance: 0,
        trainerPreference: '',
        dob: '',
        fitnessLevel: '',
        preferredLanguage: 'English',
        city: '',
        memberSince: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        selectedGoals: []
      };

      this.schema.users.push(user);
      this.schema.profiles.push(newProfile);

      const { error } = await supabase.rpc('create_user_with_profile', {
        user_row: mapDBUserToPostgres(user),
        profile_row: mapUserProfileToPostgres(newProfile)
      });
      if (error) {
        throw new Error(`Database signup failed: ${error.message}`);
      }
    } else {
      user.lastLogin = new Date().toISOString();
      await supabase.from('users').update({ last_login: user.lastLogin }).eq('id', user.id);
    }

    this.currentUserId = user.id;
    await this.save();
    this.log('OAuthLogin', `OAuth login with ${provider} for user ${user.name}`);
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      avatar: user.avatar,
      location: 'Mumbai, India',
      role: user.role
    };
  }

  getCurrentUserId(): string | null {
    return this.currentUserId;
  }

  getIsLoaded(): boolean {
    return this.isLoaded;
  }

  setCurrentUserId(id: string | null) {
    if (this.currentUserId !== id) {
      this.isLoaded = false;
    }
    this.currentUserId = id;
    setClientUserId(id);
  }

  // Profile Operations
  getProfile(userId: string): UserProfile | null {
    const profile = this.schema.profiles.find(p => p.userId === userId) || null;
    return profile;
  }

  async updateUser(userId: string, fields: Partial<DBUser>): Promise<void> {
    const user = this.schema.users.find(u => u.id === userId);
    if (user) {
      Object.assign(user, fields);
      
      const pgUser = mapDBUserToPostgres(user);
      const updateFields: any = {};
      for (const k of Object.keys(fields)) {
        const snakeKey = k.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
        updateFields[snakeKey] = pgUser[snakeKey];
      }
      
      const { data, error } = await supabase.from('users').update(updateFields).eq('id', userId).select();
      if (error) {
        throw new Error(`Failed to update users table: ${error.message}`);
      }
      if (!data || data.length === 0) {
        throw new Error('Failed to update users table: No rows affected by the update (verify RLS policies).');
      }

      this.save();
      this.log('UpdateUser', `Updated user fields for ID ${userId}`);
    } else {
      throw new Error(`User with ID ${userId} not found in database cache.`);
    }
  }

  async updateProfile(userId: string, fields: Partial<UserProfile>): Promise<void> {
    const profile = this.getProfile(userId);
    if (profile) {
      Object.assign(profile, fields);
      
      const pgProfile = mapUserProfileToPostgres(profile);
      const updateFields: any = {};
      for (const k of Object.keys(fields)) {
        const snakeKey = k.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
        updateFields[snakeKey] = pgProfile[snakeKey];
      }
      
      const { data, error } = await supabase.from('user_profiles').update(updateFields).eq('user_id', userId).select();
      if (error) {
        throw new Error(`Failed to update user_profiles table: ${error.message}`);
      }
      if (!data || data.length === 0) {
        throw new Error('Failed to update user_profiles table: No rows affected by the update (verify RLS policies).');
      }

      this.save();
      this.log('UpdateProfile', `Updated profile fields for user ID ${userId}`);
    } else {
      throw new Error(`Profile for user ID ${userId} not found in database cache.`);
    }
  }

  // Workouts and Coaches
  getWorkouts(): Workout[] {
    return this.schema.workouts;
  }

  getCoaches(): Coach[] {
    return this.schema.coaches.filter(c => !c.id.startsWith('c-') && c.id !== 'c-1' && c.id !== 'c-2' && c.id !== 'c-3' && c.id !== 'c-4');
  }

  async updateCoach(coachId: string, fields: Partial<Coach>): Promise<void> {
    let coach = this.schema.coaches.find(c => c.id === coachId);
    if (!coach) {
      const user = this.schema.users.find(u => u.id === coachId);
      coach = {
        id: coachId,
        name: user ? user.name : 'Trainer Name',
        photo: user ? user.avatar : 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&w=300&q=80',
        experience: 'Not specified',
        rating: 5.0,
        specialty: 'Not specified',
        yearsExperience: 0,
        specialization: 'Not specified',
        languages: ['English'],
        shortBio: '',
        completedSessions: 0,
        aboutText: '',
        availability: [],
        workingRadius: '0 km',
        bankDetails: '{}',
        emergencyContact: '{}',
        level: 'Associate',
        isFavourite: false
      };
      this.schema.coaches.push(coach);
    }
    if (fields.gender !== undefined && coach && coach.gender) {
      if (coach.gender.toLowerCase() !== fields.gender.toLowerCase()) {
        throw new Error("Gender cannot be changed after trainer profile creation.");
      }
    }
    
    Object.assign(coach, fields);
    
    // Map TypeScript fields to database columns dynamically to only send modified properties
    const updatePayload: any = {};
    
    if (fields.name !== undefined) updatePayload.name = fields.name;
    if (fields.photo !== undefined) updatePayload.photo = fields.photo;
    if (fields.experience !== undefined) updatePayload.experience = fields.experience;
    if (fields.rating !== undefined) updatePayload.rating = fields.rating;
    if (fields.specialty !== undefined) updatePayload.specialty = fields.specialty;
    if (fields.yearsExperience !== undefined) updatePayload.years_experience = fields.yearsExperience;
    if (fields.specialization !== undefined) updatePayload.specialization = fields.specialization;
    if (fields.languages !== undefined) updatePayload.languages = fields.languages;
    if (fields.shortBio !== undefined) updatePayload.short_bio = fields.shortBio;
    if (fields.completedSessions !== undefined) updatePayload.completed_sessions = fields.completedSessions;
    if (fields.isFavourite !== undefined) updatePayload.is_favourite = fields.isFavourite;
    if (fields.weeklySlotsSubmitted !== undefined) updatePayload.weekly_slots_submitted = fields.weeklySlotsSubmitted;
    if (fields.remainingSlotChanges !== undefined) updatePayload.remaining_slot_changes = fields.remainingSlotChanges;
    if (fields.retainerStatus !== undefined) updatePayload.retainer_status = fields.retainerStatus;
    if (fields.attendanceRate !== undefined) updatePayload.attendance_rate = fields.attendanceRate;
    if (fields.punctualityRate !== undefined) updatePayload.punctuality_rate = fields.punctualityRate;
    if (fields.availabilityCompliance !== undefined) updatePayload.availability_compliance = fields.availabilityCompliance;
    if (fields.bankDetails !== undefined) updatePayload.bank_details = fields.bankDetails ? JSON.parse(fields.bankDetails) : null;
    if (fields.emergencyContact !== undefined) updatePayload.emergency_contact = fields.emergencyContact ? JSON.parse(fields.emergencyContact) : null;
    if (fields.aboutText !== undefined) updatePayload.about_text = fields.aboutText;
    if (fields.availability !== undefined) updatePayload.availability = fields.availability;
    if (fields.workingRadius !== undefined) updatePayload.working_radius = fields.workingRadius;
    if (fields.gender !== undefined) updatePayload.gender = fields.gender ? fields.gender.toLowerCase() : null;

    if (fields.preferences !== undefined) {
      const prefs = fields.preferences;
      updatePayload.preferences = prefs;
      updatePayload.service_radius_km = prefs.radiusKm || 15;
      updatePayload.address_change_request = prefs.addressChangeRequest || null;

      const currentUserRole = this.schema.users.find(u => u.id === this.currentUserId)?.role;
      const isAdmin = currentUserRole === 'admin';

      if (isAdmin) {
        updatePayload.operating_address = prefs.operatingAddress || null;
        updatePayload.operating_latitude = prefs.operatingLatitude !== undefined ? prefs.operatingLatitude : null;
        updatePayload.operating_longitude = prefs.operatingLongitude !== undefined ? prefs.operatingLongitude : null;
        updatePayload.operating_place_id = prefs.operatingPlaceId || null;
        updatePayload.operating_location_status = prefs.operatingLocationStatus || 'pending';
      }
    }

    let dbError;
    if (Object.keys(updatePayload).length > 0) {
      const { error } = await supabase.from('trainers').update(updatePayload).eq('id', coachId);
      dbError = error;
    } else {
      const pgCoach = mapCoachToPostgres(coach);
      const { error } = await supabase.from('trainers').upsert(pgCoach);
      dbError = error;
    }

    if (dbError) {
      throw new Error(`Failed to update trainer in database: ${dbError.message}`);
    }

    this.save();
    this.log('UpdateCoach', `Updated trainer record for ID ${coachId}`);
  }

  toggleFavouriteCoach(coachId: string): void {
    const coach = this.schema.coaches.find(c => c.id === coachId);
    if (coach) {
      coach.isFavourite = !coach.isFavourite;
      supabase.from('trainers').update({ is_favourite: coach.isFavourite }).eq('id', coachId).then();
      this.save();
      this.log('ToggleFavouriteCoach', `Toggled favourite status of coach ${coach.name}`);
    }
  }

  // Bookings & Sessions
  parseBookingDateHelper(booking: Booking): Date {
    try {
      const dateStr = normalizeDate(booking.date);
      if (!dateStr) return new Date();
      
      const timePart = booking.time.split('-')[0].trim();
      const match = timePart.match(/(\d+):(\d+)\s*(AM|PM)/i);
      if (match) {
        let hours = parseInt(match[1], 10);
        const minutes = parseInt(match[2], 10);
        const ampm = match[3].toUpperCase();
        if (ampm === 'PM' && hours < 12) hours += 12;
        if (ampm === 'AM' && hours === 12) hours = 0;
        
        const [year, month, day] = dateStr.split('-').map(x => parseInt(x, 10));
        const d = new Date(year, month - 1, day, hours, minutes, 0, 0);
        if (!isNaN(d.getTime())) {
          return d;
        }
      }
    } catch (e) {
      console.log('[DATABASE] Error parsing date:', e);
    }
    const fallback = new Date();
    fallback.setHours(fallback.getHours() + 2);
    return fallback;
  }

  autoExpireStaleBookingsLocal(): void {
    const now = getCurrentServerTime();
    let changed = false;
    this.schema.bookings.forEach(b => {
      if (b.status === 'upcoming') {
        const range = getBookingISTDateRange(b);
        
        // 1. Unstarted bookings: auto-expire 30 minutes after scheduled start time
        if (!b.timelineStatus || ['booked', 'trainer_assigned', 'trainer_accepted', 'trainer_preparing', 'trainer_travelling', 'trainer_arrived'].includes(b.timelineStatus)) {
          const expireTime = range.start.getTime() + 30 * 60 * 1000;
          if (now.getTime() > expireTime) {
            b.status = 'missed_session_not_started';
            b.timelineStatus = 'session_closed';
            changed = true;
            supabase.from('bookings').update({
              status: 'missed_session_not_started',
              timeline_status: 'session_closed'
            }).eq('id', b.id).then();
            console.log(`[AUTO-EXPIRE] Expired unstarted booking ${b.id} (Scheduled: ${b.time} on ${b.date})`);
          }
        }
        // 2. Started but unclosed bookings: auto-complete after scheduled end time
        else if (['otp_verified', 'workout_started'].includes(b.timelineStatus)) {
          if (now.getTime() > range.end.getTime()) {
            b.status = 'completed';
            b.timelineStatus = 'session_closed';
            changed = true;
            supabase.from('bookings').update({
              status: 'completed',
              timeline_status: 'session_closed'
            }).eq('id', b.id).then();
            console.log(`[AUTO-COMPLETE] Auto-completed unclosed booking ${b.id} (Scheduled end: ${range.end.toISOString()})`);
          }
        }
      }
    });
    if (changed) {
      this.save();
    }
  }

  checkAndSendLocalReminders(): void {
    const now = Date.now();
    let changed = false;
    this.schema.bookings.forEach(b => {
      if (b.status === 'upcoming' && b.trainerId && b.trainerId !== 'searching' && !b.reminderSent) {
        const bookedTime = this.parseBookingDateHelper(b);
        const diffMs = bookedTime.getTime() - now;
        
        if (diffMs > 0 && diffMs <= 60 * 60 * 1000) {
          b.reminderSent = true;
          changed = true;
          
          const formattedTime = b.time.split('-')[0].trim();
          
          // Generate client notification
          if (b.clientId) {
            this.addNotification(b.clientId, {
              title: 'Session Reminder ⏱️',
              body: `Your VIRLA session with Coach ${b.trainerName} starts at ${formattedTime}.`,
              icon: 'clock',
              type: 'Bookings',
              priority: 'medium',
              actionLabel: 'View Details',
              deepLink: `/session-detail?id=${b.id}`
            });
          }
          
          // Generate trainer notification
          if (b.trainerId) {
            this.addNotification(b.trainerId, {
              title: 'Session Reminder ⏱️',
              body: `Your VIRLA session starts at ${formattedTime}.`,
              icon: 'clock',
              type: 'Bookings',
              priority: 'medium',
              actionLabel: 'View Details',
              deepLink: `/session-detail?id=${b.id}`
            });
          }
          
          supabase.from('bookings').update({
            reminder_sent: true
          }).eq('id', b.id).then();
        }
      }
    });
    if (changed) {
      this.save();
    }
  }

  autoAcceptPendingBookingsLocal(): void {
    const now = Date.now();
    let changed = false;
    for (const b of this.schema.bookings) {
      if (b.status === 'upcoming' && b.timelineStatus === 'booked' && b.acceptanceDeadline && now >= b.acceptanceDeadline) {
        b.timelineStatus = 'trainer_accepted';
        b.acceptanceMethod = 'SYSTEM_AUTO_ACCEPT';
        b.autoAcceptedAt = now;
        
        supabase.from('bookings').update({
          timeline_status: 'trainer_accepted',
          acceptance_method: 'SYSTEM_AUTO_ACCEPT',
          auto_accepted_at: now
        }).eq('id', b.id).then();
        
        if (b.clientId) {
          this.addNotification(b.clientId, {
            title: 'Trainer Assigned ⚡',
            body: `Your booking is confirmed. Coach ${b.trainerName} is assigned to your session on ${b.date} @ ${b.time}.`,
            icon: 'check-circle',
            type: 'Bookings',
            priority: 'high',
            actionLabel: 'View Details',
            deepLink: `/session-detail?id=${b.id}`
          });
        }

        if (b.trainerId) {
          this.addNotification(b.trainerId, {
            title: 'Booking Automatically Accepted ⚠️',
            body: `Session automatically accepted because no response was received within 30 minutes.`,
            icon: 'alert-circle',
            type: 'Trainer Updates',
            priority: 'high',
            actionLabel: 'View Details',
            deepLink: `/session-detail?id=${b.id}`
          });
        }

        changed = true;
      }
    }
    if (changed) {
      this.save();
    }
  }

  runBackgroundSyncChecks(): void {
    // Disabled client-side mutations that conflict with One Brain database authority
    // this.autoAcceptPendingBookingsLocal();
    // this.autoExpireStaleBookingsLocal();
    this.checkAndSendLocalReminders();
  }

  getBookings(userId: string): Booking[] {
    this.runBackgroundSyncChecks();
    const userObj = this.schema.users.find(u => u.id === userId);
    if (userObj && userObj.role === 'admin') {
      return this.schema.bookings;
    }
    if (userObj && userObj.role === 'trainer') {
      return this.schema.bookings.filter(b => b.trainerId === userObj.id || b.trainerName === userObj.name);
    }
    return this.schema.bookings.filter(b => b.clientId === userId || b.id.includes(userId) || b.id.startsWith('b-'));
  }

  async refreshBookings(): Promise<void> {
    try {
      await supabase.rpc('expire_stale_bookings');
      await supabase.rpc('apply_auto_acceptances');
      const { data, error } = await supabase.from('bookings').select('*');
      if (data && !error) {
        this.schema.bookings = data.map(mapBooking).filter((b: Booking) => !b.isInvalidData);
        this.runBackgroundSyncChecks();
        this.save();
      }
    } catch (e) {
      console.error('refreshBookings error:', e);
    }
  }

  cleanExpiredReservations(): void {
    const now = Date.now();
    this.schema.slot_reservations = this.schema.slot_reservations.filter(r => {
      const isExpired = Number(r.expires_at) <= now;
      if (isExpired) {
        supabase.from('slot_reservations').delete().eq('id', r.id).then();
      }
      return !isExpired;
    });
  }

  async reserveSlot(clientId: string, trainerId: string, date: string, time: string): Promise<string | null> {
    this.cleanExpiredReservations();
    
    const range = getBookingISTDateRange({ date, time } as any);
    const scheduledStartAt = range.start.toISOString();
    const scheduledEndAt = range.end.toISOString();

    const id = `res-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
    
    // Check if already reserved by another client
    const isReserved = this.schema.slot_reservations.some(r => 
      r.trainer_id === trainerId && normalizeDate(r.slot_date) === normalizeDate(date) && r.slot_time === time && r.client_id !== clientId
    );
    if (isReserved) return null;

    const reservation = {
      id,
      slot_time: time,
      slot_date: date,
      trainer_id: trainerId,
      client_id: clientId,
      expires_at: expiresAt,
      scheduled_start_at: scheduledStartAt,
      scheduled_end_at: scheduledEndAt
    };

    this.schema.slot_reservations.push({
      id,
      slot_time: time,
      slot_date: date,
      trainer_id: trainerId,
      client_id: clientId,
      expires_at: Date.now() + 5 * 60 * 1000 as any
    });

    try {
      await supabase.from('slot_reservations').insert(reservation);
    } catch (e) {
      console.error('reserveSlot insert error:', e);
    }
    return id;
  }

  async releaseSlot(reservationId: string): Promise<void> {
    this.schema.slot_reservations = this.schema.slot_reservations.filter(r => r.id !== reservationId);
    try {
      await supabase.from('slot_reservations').delete().eq('id', reservationId);
    } catch (e) {
      console.error('releaseSlot delete error:', e);
    }
  }

  async addBookingWithValidation(userId: string, bookingData: Omit<Booking, 'id' | 'status' | 'timelineStatus'>): Promise<Booking> {
    const bookingId = generateUUID('booking');
    const range = getBookingISTDateRange(bookingData as any);
    const scheduledStartAt = range.start.toISOString();
    const scheduledEndAt = range.end.toISOString();

    const workout = this.schema.workouts.find(w => w.title === bookingData.workoutTitle);
    const workoutId = workout?.id || 'w-powerforge';
    const assignedTrainerId = bookingData.trainerId;
    if (!assignedTrainerId) throw new Error('Trainer ID is required.');

    const { data, error } = await supabase.rpc('create_booking', {
      p_booking_id: bookingId,
      p_workout_id: workoutId,
      p_scheduled_start_at: scheduledStartAt,
      p_scheduled_end_at: scheduledEndAt,
      p_assigned_trainer_id: assignedTrainerId,
      p_trainer_note: bookingData.trainerNote || null
    });

    if (error) {
      console.error('[DB ERROR] create_booking RPC failed:', error);
      if (error.message && (error.message.includes('unavailable') || error.message.includes('overlapping') || error.message.includes('buffer'))) {
        throw new Error('This slot is no longer available. Please select another slot.');
      }
      throw new Error(error.message || 'Database write operation failed. Rolled back booking transaction.');
    }

    await this.refreshBookings();
    await this.refreshUserData(userId);

    const newBooking = this.schema.bookings.find(b => b.id === bookingId);
    if (!newBooking) {
      throw new Error('Booking was created but could not be loaded.');
    }
    return newBooking;
  }

  // Helper utility function for time parsing
  parseTimeToMinutesHelper(timeStr: string): number {
    const match = timeStr.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (!match) return 0;
    let hours = parseInt(match[1]);
    const minutes = parseInt(match[2]);
    const ampm = match[3].toUpperCase();
    if (ampm === 'PM' && hours < 12) hours += 12;
    if (ampm === 'AM' && hours === 12) hours = 0;
    return hours * 60 + minutes;
  }

  async refreshUserData(userId: string): Promise<void> {
    try {
      const [resProfiles, resTransactions, resEarnings] = await Promise.all([
        supabase.from('user_profiles').select('*').eq('user_id', userId),
        supabase.from('credit_transactions').select('*').eq('user_id', userId),
        supabase.from('trainer_earnings').select('*').eq('trainer_id', userId)
      ]);
      if (resProfiles.data) {
        this.schema.profiles = this.schema.profiles.filter(p => p.userId !== userId).concat((resProfiles.data || []).map(mapUserProfile));
      }
      if (resTransactions.data) {
        this.schema.credit_transactions = this.schema.credit_transactions.filter(t => t.userId !== userId).concat((resTransactions.data || []).map(mapInvoice));
      }
      if (resEarnings.data) {
        this.schema.earnings = (resEarnings.data || []).map(mapTrainerEarning);
      }
      this.save();
    } catch (e) {
      console.error('refreshUserData error:', e);
    }
  }

  addBooking(userId: string, bookingData: Omit<Booking, 'id' | 'status' | 'timelineStatus'>): Booking {
    const bookingId = generateUUID('booking');
    const tempBooking: Booking = {
      ...bookingData,
      id: bookingId,
      status: 'upcoming',
      timelineStatus: 'booked',
      createdAt: Date.now()
    } as any;
    
    // Optimistically insert locally so UI shows it, but we will write it via RPC in background
    this.schema.bookings.unshift(tempBooking);
    this.save();

    // Call RPC asynchronously
    this.addBookingWithValidation(userId, bookingData)
      .then(() => {
        console.log(`[DB] Async booking creation succeeded for ID: ${bookingId}`);
      })
      .catch((err) => {
        console.error(`[DB ERROR] Async booking creation failed:`, err);
        // Rollback local cache
        this.schema.bookings = this.schema.bookings.filter(b => b.id !== bookingId);
        this.save();
      });

    return tempBooking;
  }

  async cancelBooking(userId: string, bookingId: string, reason = ''): Promise<void> {
    const { data, error } = await supabase.rpc('cancel_booking', {
      p_booking_id: bookingId
    });
    if (error) {
      console.error('[DB ERROR] cancel_booking RPC failed:', error);
      throw new Error(error.message);
    }
    await this.refreshBookings();
    await this.refreshUserData(userId);
  }

  async rescheduleBooking(bookingId: string, date: string, time: string): Promise<void> {
    const { data, error } = await supabase.rpc('reschedule_booking', {
      p_booking_id: bookingId,
      p_new_date: date,
      p_new_time: time
    });

    if (error) {
      console.error('[DB ERROR] reschedule_booking failed:', error);
      throw new Error(error.message);
    }

    await this.refreshBookings();
    
    const booking = this.schema.bookings.find(b => b.id === bookingId);
    if (booking) {
      booking.date = date;
      booking.time = time;
      booking.status = 'upcoming';
      booking.timelineStatus = 'booked';
      this.save();
    }
    this.log('RescheduleBooking', `Rescheduled booking ${bookingId} to ${date} at ${time}`);
  }

  generateDaySlotsHelper(dateStr: string): { id: string; time: string; isAvailable: boolean; isBooked: boolean }[] {
    const dateParts = dateStr.split('-');
    const year = parseInt(dateParts[0], 10);
    const month = parseInt(dateParts[1], 10) - 1;
    const day = parseInt(dateParts[2], 10);
    
    const startHour = 6;
    const endHour = 23;
    const durationMinutes = 60;
    const gapMinutes = 30;
    
    const slots = [];
    let current = new Date(year, month, day, startHour, 0);
    const endLimit = new Date(year, month, day, endHour, 0);
    
    let slotIndex = 1;
    while (true) {
      const slotEnd = new Date(current.getTime() + durationMinutes * 60 * 1000);
      if (slotEnd.getTime() > endLimit.getTime()) {
        break;
      }
      
      const formatTime = (d: Date) => {
        let hr = d.getHours();
        const min = String(d.getMinutes()).padStart(2, '0');
        const ampm = hr >= 12 ? 'PM' : 'AM';
        hr = hr % 12;
        hr = hr ? hr : 12;
        return `${String(hr).padStart(2, '0')}:${min} ${ampm}`;
      };

      const timeRange = `${formatTime(current)} - ${formatTime(slotEnd)}`;
      slots.push({
        id: `${dateStr}-s${slotIndex}`,
        time: timeRange,
        isAvailable: true,
        isBooked: false,
      });

      slotIndex++;
      current = new Date(slotEnd.getTime() + gapMinutes * 60 * 1000);
    }
    return slots;
  }

  getTrainerAvailableSlots(trainerId: string, dateStr: string, bookingIdToExclude?: string): { time: string; isAvailable: boolean }[] {
    const normalizedDateStr = normalizeDate(dateStr);
    const dateParts = normalizedDateStr.split('-');
    if (dateParts.length < 3) return [];
    
    const targetYear = parseInt(dateParts[0], 10);
    const targetMonth = parseInt(dateParts[1], 10) - 1; // 0-indexed month
    const targetDay = parseInt(dateParts[2], 10);
    
    const defaultDaySlots = this.generateDaySlotsHelper(normalizedDateStr);
    
    const coaches = this.getCoaches();
    const bookings = this.schema.bookings || [];
    
    let eligibleCoaches = [];
    if (trainerId === 'searching') {
      eligibleCoaches = coaches.filter(c => c.preferences?.online !== false && c.verifiedBadge !== false);
    } else {
      const coach = coaches.find(c => c.id === trainerId);
      if (coach) {
        eligibleCoaches.push(coach);
      }
    }
    
    const aggregatedSlotsMap: { [time: string]: boolean } = {};
    
    const parseTime = (timeStr: string) => {
      const match = timeStr.match(/(\d+):(\d+)\s*(AM|PM)/i);
      if (!match) return 0;
      let h = parseInt(match[1], 10);
      const m = parseInt(match[2], 10);
      const ampm = match[3].toUpperCase();
      if (ampm === 'PM' && h < 12) h += 12;
      if (ampm === 'AM' && h === 12) h = 0;
      return h * 60 + m;
    };

    const nowServer = getCurrentServerTime();
    const istOffset = 5.5 * 60 * 60 * 1000;
    const nowIst = new Date(nowServer.getTime() + istOffset);
    const istYear = nowIst.getUTCFullYear();
    const istMonth = nowIst.getUTCMonth();
    const istDay = nowIst.getUTCDate();
    const istHours = nowIst.getUTCHours();
    const istMinutes = nowIst.getUTCMinutes();
    const nowIstFixed = new Date(Date.UTC(istYear, istMonth, istDay, istHours, istMinutes, 0));

    let customerLat = 19.0176;
    let customerLng = 72.8561;
    let targetCategory = 'Strength';
    
    if (bookingIdToExclude) {
      const targetB = bookings.find(b => b.id === bookingIdToExclude);
      if (targetB) {
        const t = (targetB.workoutTitle || '').toLowerCase();
        if (t.includes('forge') || t.includes('strength')) targetCategory = 'Strength';
        else if (t.includes('flow') || t.includes('motion')) targetCategory = 'Mind & Body';
        else if (t.includes('rhythm') || t.includes('burn')) targetCategory = 'Cardio';
        else if (t.includes('reset') || t.includes('studio') || t.includes('stretch')) targetCategory = 'Conditioning';
        else if (t.includes('combat') || t.includes('boxing')) targetCategory = 'Boxing';
      }
    }

    for (const coach of eligibleCoaches) {
      if (coach.preferences?.online === false) continue;
      
      if (trainerId === 'searching') {
        const trainerLat = coach.preferences?.operatingLatitude;
        const trainerLng = coach.preferences?.operatingLongitude;
        const radiusLimit = coach.preferences?.radiusKm || 15;
        let insideRadius = false;
        
        if (trainerLat !== undefined && trainerLng !== undefined && trainerLat !== null && trainerLng !== null) {
          const lat1 = trainerLat;
          const lon1 = trainerLng;
          const lat2 = customerLat;
          const lon2 = customerLng;
          const R = 6371;
          const dLat = (lat2 - lat1) * Math.PI / 180;
          const dLon = (lon2 - lon1) * Math.PI / 180;
          const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) *
                    Math.sin(dLon/2) * Math.sin(dLon/2);
          const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
          const distance = R * c;
          insideRadius = distance <= radiusLimit;
        }
        if (!insideRadius) continue;
        
        const assignments = this.getWorkoutAssignments(coach.id);
        const isApproved = assignments.some(a => a.workoutCategory === targetCategory && a.status === 'APPROVED');
        const acceptsAll = assignments.some(a => a.workoutCategory === 'All Workouts' && a.status === 'APPROVED');
        if (!acceptsAll && !isApproved) continue;
      }

      const overrides = coach.preferences?.availabilityOverrides || [];
      
      const dailySlots = defaultDaySlots.map(slot => {
        const override = overrides.find(o => 
          normalizeDate(o.date) === normalizedDateStr && 
          canonicalizeTimeRange(o.time) === canonicalizeTimeRange(slot.time)
        );
        const isAvailable = override ? override.isAvailable : true;
        return {
          ...slot,
          isAvailable
        };
      }).filter(s => {
        if (!s.isAvailable) return false;
        
        const startPart = s.time.split('-')[0].trim();
        const match = startPart.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
        if (match) {
          let hour = parseInt(match[1], 10);
          const minute = parseInt(match[2], 10);
          const ampm = match[3].toUpperCase();
          if (ampm === 'PM' && hour < 12) hour += 12;
          if (ampm === 'AM' && hour === 12) hour = 0;
          
          const slotStartIst = new Date(Date.UTC(targetYear, targetMonth, targetDay, hour, minute, 0));
          const visibilityStartMs = slotStartIst.getTime() - 15 * 60 * 1000;
          if (nowIstFixed.getTime() > visibilityStartMs) {
            return false;
          }
        }
        return true;
      });
      
      for (const slot of dailySlots) {
        const hasBooking = bookings.some(b => 
          b.id !== bookingIdToExclude &&
          b.trainerId === coach.id &&
          b.status === 'upcoming' &&
          normalizeDate(b.date) === normalizedDateStr &&
          canonicalizeTimeRange(b.time) === canonicalizeTimeRange(slot.time)
        );
        
        const targetMinutes = parseTime(slot.time);
        
        const hasBufferConflict = bookings.some(b => {
          if (b.id === bookingIdToExclude || b.trainerId !== coach.id || b.status !== 'upcoming' || normalizeDate(b.date) !== normalizedDateStr) return false;
          const bMinutes = parseTime(b.time);
          const diff = Math.abs(bMinutes - targetMinutes);
          const duration = b.durationMinutes || 60;
          return diff < (duration + 30);
        });
        
        const slotReservations = this.schema.slot_reservations || [];
        const isReserved = slotReservations.some(r => 
          r.trainer_id === coach.id &&
          normalizeDate(r.slot_date) === normalizedDateStr &&
          canonicalizeTimeRange(r.slot_time) === canonicalizeTimeRange(slot.time) &&
          r.client_id !== this.getCurrentUserId()
        );
        
        if (!hasBooking && !hasBufferConflict && !isReserved) {
          aggregatedSlotsMap[slot.time] = true;
        }
      }
    }
    
    return Object.keys(aggregatedSlotsMap).map(time => ({
      time,
      isAvailable: true
    })).sort((a, b) => parseTime(a.time) - parseTime(b.time));
  }

  async updateTimelineStatus(bookingId: string, timelineStatus: Booking['timelineStatus']): Promise<void> {
    const booking = this.schema.bookings.find(b => b.id === bookingId);
    if (!booking) return;

    console.log('[TRAVEL-DEBUG]', JSON.stringify({
      authenticatedUserId: this.currentUserId,
      trainerId: booking.trainerId,
      bookingId: bookingId,
      timelineId: bookingId,
      sessionStatus: booking.timelineStatus || booking.status,
      currentServerTime: getCurrentServerTime().toISOString(),
      sessionStartTime: getBookingISTDateRange(booking).start.toISOString(),
      travelWindowStatus: `diff: ${((getBookingISTDateRange(booking).start.getTime() - getCurrentServerTime().getTime()) / 60000).toFixed(1)} mins, inside: ${((getBookingISTDateRange(booking).start.getTime() - getCurrentServerTime().getTime()) / 60000) <= 25 && ((getBookingISTDateRange(booking).start.getTime() - getCurrentServerTime().getTime()) / 60000) >= -30}`,
      authorizationResult: this.currentUserId === booking.trainerId ? 'AUTHORIZED' : 'UNAUTHORIZED'
    }, null, 2));

    let res: { error: any } = { error: null };
    const statusUpper = timelineStatus ? timelineStatus.toUpperCase() : '';

    if (timelineStatus === 'trainer_accepted') {
      res = await supabase.rpc('trainer_accept_booking', { p_booking_id: bookingId });
    } else if (timelineStatus === 'trainer_travelling') {
      res = await supabase.rpc('start_travel', { p_booking_id: bookingId });
    } else if (timelineStatus === 'trainer_arrived') {
      res = await supabase.rpc('mark_trainer_arrived', { p_booking_id: bookingId });
    } else if (timelineStatus === 'workout_started') {
      res = await supabase.rpc('start_session', { p_booking_id: bookingId });
    } else if (timelineStatus === 'workout_completed') {
      res = await supabase.rpc('complete_session', { p_booking_id: bookingId });
    } else if (timelineStatus === 'session_closed') {
      res = await supabase.rpc('close_session', { p_booking_id: bookingId });
    } else {
      res = await supabase.rpc('update_session_timeline', {
        p_booking_id: bookingId,
        p_target_status: statusUpper
      });
    }

    if (res.error) {
      console.error(`[DB ERROR] updateTimelineStatus failed for ${timelineStatus}:`, res.error);
      throw new Error(res.error.message);
    }

    await this.refreshBookings();
    const userId = this.currentUserId || booking.clientId || '';
    if (userId) {
      await this.refreshUserData(userId);
    }
  }

  updateBookingNote(bookingId: string, trainerNote: string): void {
    const booking = this.schema.bookings.find(b => b.id === bookingId);
    if (booking) {
      booking.trainerNote = trainerNote;
      supabase.from('bookings').update({
        trainer_note: trainerNote
      }).eq('id', bookingId).then();
      this.save();
      this.log('UpdateBookingNote', `Updated note for booking ${bookingId} to: ${trainerNote}`);
    }
  }

  async updateBookingTrainer(bookingId: string, trainer?: any): Promise<void> {
    const { error } = await supabase.rpc('reassign_booking_trainer', {
      p_booking_id: bookingId,
      p_action: trainer?.action || 'timeout'
    });
    if (error) {
      console.error('[DB ERROR] reassign_booking_trainer failed:', error);
      if (error.code === '23505' || (error.message && error.message.includes('23505'))) {
        const booking = this.schema.bookings.find(b => b.id === bookingId);
        console.log(`[BOOKING-LIFECYCLE] duplicate assignment detected
bookingId: ${bookingId}
existing assignment: ${booking ? `${booking.trainerId} (${booking.date} @ ${booking.time})` : 'Unknown'}
requested assignment: Reassignment attempt via ${trainer?.action || 'timeout'}`);
        await this.refreshBookings();
        return; // Resolve gracefully to stop the retry loop
      }
      throw new Error(error.message);
    }
    await this.refreshBookings();
  }

  async updateBookingSessionDetails(bookingId: string, details: any): Promise<void> {
    if (details.timelineStatus) {
      await this.updateTimelineStatus(bookingId, details.timelineStatus);
    }
  }

  async updateBookingRating(bookingId: string, ratingDetails: Booking['ratingDetails']): Promise<void> {
    const booking = this.schema.bookings.find(b => b.id === bookingId);
    if (!booking) return;

    const { error } = await supabase.rpc('submit_customer_review', {
      p_booking_id: bookingId,
      p_rating_details: {
        rating: ratingDetails?.overallRating || 5,
        overallRating: ratingDetails?.overallRating || 5,
        trainerRating: ratingDetails?.trainerRating || 5,
        workoutRating: ratingDetails?.workoutRating || 5,
        difficulty: ratingDetails?.difficulty || 'Medium',
        energy: ratingDetails?.energy || 'Medium',
        comments: ratingDetails?.comments || ''
      }
    });

    if (error) {
      console.error('[DB ERROR] submit_customer_review RPC failed:', error);
      throw new Error(error.message);
    }

    await this.refreshBookings();
    const userId = this.currentUserId || booking.clientId || '';
    if (userId) {
      await this.refreshUserData(userId);
    }
  }

  async handleNoShow(bookingId: string, actor: 'client' | 'trainer'): Promise<void> {
    const booking = this.schema.bookings.find(b => b.id === bookingId);
    if (!booking) return;

    const { error } = await supabase.rpc('handle_no_show', {
      p_booking_id: bookingId,
      p_no_show_type: actor
    });

    if (error) {
      console.error('[DB ERROR] handle_no_show RPC failed:', error);
      throw new Error(error.message);
    }

    await this.refreshBookings();
    const userId = this.currentUserId || booking.clientId || '';
    if (userId) {
      await this.refreshUserData(userId);
    }
  }

  async acknowledgeAutoAccept(bookingId: string): Promise<void> {
    const booking = this.schema.bookings.find(b => b.id === bookingId);
    if (!booking) return;

    const { error } = await supabase.rpc('acknowledge_auto_accept', {
      p_booking_id: bookingId
    });

    if (error) {
      console.error('[DB ERROR] acknowledge_auto_accept RPC failed:', error);
      throw new Error(error.message);
    }

    await this.refreshBookings();
    const userId = this.currentUserId || booking.clientId || '';
    if (userId) {
      await this.refreshUserData(userId);
    }
  }

  async submitTrainerReport(bookingId: string, report: NonNullable<Booking['questionnaire']>): Promise<void> {
    const booking = this.schema.bookings.find(b => b.id === bookingId);
    if (!booking) return;

    const { error } = await supabase.rpc('submit_trainer_report', {
      p_booking_id: bookingId,
      p_questionnaire: {
        mobilityScore: report.mobilityScore || 0,
        workoutSummary: report.workoutSummary || '',
        coachNotes: report.coachNotes || '',
        coachSignature: report.coachSignature || ''
      }
    });

    if (error) {
      console.error('[DB ERROR] submit_trainer_report RPC failed:', error);
      throw new Error(error.message);
    }

    await this.refreshBookings();
    const userId = this.currentUserId || booking.clientId || '';
    if (userId) {
      await this.refreshUserData(userId);
    }
  }

  async getClientAssessmentHistory(clientId: string): Promise<{ bookingId: string; date: string; time: string; coachName: string; assessment: string }[]> {
    const { data, error } = await supabase.rpc('get_client_assessment_history', {
      p_client_id: clientId
    });

    if (error) {
      console.error('[DB ERROR] get_client_assessment_history failed:', error);
      return [];
    }

    return (data || []).map((row: any) => ({
      bookingId: row.booking_id,
      date: row.session_date,
      time: row.session_time,
      coachName: row.coach_name,
      assessment: row.assessment
    }));
  }

  // Hydration Operations
  getHydration(userId: string, date: string): number {
    const logs = this.schema.hydration.filter(l => l.userId === userId && l.date === date);
    return logs.reduce((sum, current) => sum + current.amount, 0);
  }

  logHydration(userId: string, date: string, amount: number): number {
    const id = generateUUID('hyd');
    const newLog = { id, userId, date, amount };
    this.schema.hydration.push(newLog);
    
    supabase.from('hydration_logs').insert(mapHydrationLogToPostgres(newLog)).then();

    this.save();
    this.log('LogHydration', `Logged ${amount}ml of water for user ${userId}`);
    return this.getHydration(userId, date);
  }

  // Calories Operations
  getCalories(userId: string, date: string): number {
    const logs = this.schema.calories.filter(l => l.userId === userId && l.date === date);
    const manualKcal = logs.reduce((sum, curr) => sum + curr.amount, 0);

    const sessionsKcal = this.schema.bookings
      .filter(b => b.status === 'completed' && b.clientId === userId && b.date === date)
      .reduce((sum, curr) => sum + (curr.caloriesBurned || 300), 0);

    return manualKcal + sessionsKcal;
  }

  logCalories(userId: string, date: string, amount: number): number {
    const id = generateUUID('cal');
    const newLog = { id, userId, date, amount };
    this.schema.calories.push(newLog);
    
    supabase.from('calorie_logs').insert(mapCalorieLogToPostgres(newLog)).then();

    this.save();
    this.log('LogCalories', `Logged ${amount}kcal for user ${userId}`);
    return this.getCalories(userId, date);
  }

  // Streaks calculation
  getStreak(userId: string): number {
    const completedDates = this.schema.bookings
      .filter(b => b.status === 'completed')
      .map(b => b.date);

    if (completedDates.length === 0) return 0;

    const uniqueDates = Array.from(new Set(completedDates)).map(d => new Date(d));
    uniqueDates.sort((a, b) => b.getTime() - a.getTime());

    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let checkDate = new Date(today);
    
    let workoutFound = uniqueDates.some(d => d.toDateString() === today.toDateString());
    if (!workoutFound) {
      checkDate.setDate(today.getDate() - 1);
      workoutFound = uniqueDates.some(d => d.toDateString() === checkDate.toDateString());
    }

    if (!workoutFound) return 0;

    while (true) {
      const match = uniqueDates.some(d => d.toDateString() === checkDate.toDateString());
      if (match) {
        streak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }

    return streak;
  }

  // Recovery Score Calculation
  getRecoveryScore(userId: string, date: string): number | null {
    const workoutsCount = this.schema.bookings.filter(b => b.status === 'completed').length;
    const waterToday = this.getHydration(userId, date);

    if (workoutsCount === 0 && waterToday === 0) {
      return null;
    }

    const hydrationPercentage = Math.min(100, (waterToday / 2500) * 100);
    const streakBonus = Math.min(20, this.getStreak(userId) * 4);
    const score = Math.round(50 + (hydrationPercentage * 0.3) + streakBonus);
    return Math.min(100, score);
  }

  // Invoices & Purchases
  getLedgerTransactions(userId: string): Invoice[] {
    return this.schema.credit_transactions.filter(t => t.userId === userId);
  }

  addLedgerTransaction(userId: string, tx: Invoice): void {
    console.log('[DB] addLedgerTransaction client call ignored. Ledger is authoritative on Supabase.');
  }

  // Disputes & Kit requests
  async fetchClientDisputes(userId: string): Promise<any[]> {
    const { data, error } = await supabase
      .from('disputes')
      .select('*')
      .eq('trainer_id', userId)
      .order('created_at', { ascending: false });
    if (error) {
      console.error('[DB ERROR] fetchClientDisputes failed:', error);
      return [];
    }
    return data || [];
  }

  async addClientDispute(userId: string, dispute: any): Promise<void> {
    const { error } = await supabase
      .from('disputes')
      .insert({
        trainer_id: userId,
        booking_id: dispute.bookingId || null,
        category: dispute.category,
        description: dispute.description
      });
    if (error) {
      console.error('[DB ERROR] addClientDispute failed:', error);
      throw error;
    }
  }

  async fetchKitRequests(userId: string): Promise<any[]> {
    const { data, error } = await supabase
      .from('kit_orders')
      .select('*')
      .eq('trainer_id', userId)
      .order('created_at', { ascending: false });
    if (error) {
      console.error('[DB ERROR] fetchKitRequests failed:', error);
      return [];
    }
    return data || [];
  }

  async addKitRequest(userId: string, request: any): Promise<void> {
    const { error } = await supabase
      .from('kit_orders')
      .insert({
        trainer_id: userId,
        items: request.items,
        tshirt_size: request.size || null
      });
    if (error) {
      console.error('[DB ERROR] addKitRequest failed:', error);
      throw error;
    }
  }

  async fetchAllDisputes(): Promise<any[]> {
    const { data, error } = await supabase
      .from('disputes')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) {
      console.error('[DB ERROR] fetchAllDisputes failed:', error);
      return [];
    }
    return data || [];
  }

  async updateDisputeStatus(disputeId: string, status: string): Promise<void> {
    const { error } = await supabase
      .from('disputes')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', disputeId);
    if (error) {
      console.error('[DB ERROR] updateDisputeStatus failed:', error);
      throw error;
    }
  }

  async fetchAllKitOrders(): Promise<any[]> {
    const { data, error } = await supabase
      .from('kit_orders')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) {
      console.error('[DB ERROR] fetchAllKitOrders failed:', error);
      return [];
    }
    return data || [];
  }

  async updateKitOrderStatus(orderId: string, status: string): Promise<void> {
    const { error } = await supabase
      .from('kit_orders')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', orderId);
    if (error) {
      console.error('[DB ERROR] updateKitOrderStatus failed:', error);
      throw error;
    }
  }

  async addPartnerToBooking(bookingId: string, partnerName: string, partnerPhone: string): Promise<Booking> {
    await this.load();
    const booking = this.schema.bookings.find(b => b.id === bookingId);
    if (!booking) {
      throw new Error('Booking not found.');
    }

    const userId = booking.clientId;
    if (!userId) {
      throw new Error('Client ID not found on booking.');
    }

    // 1. Verify eligibility (Single PT booking type, etc.)
    if (booking.participantCount && booking.participantCount >= 2) {
      throw new Error('This session already has a partner added.');
    }

    // 2. Verify booking status
    if (booking.status !== 'upcoming') {
      throw new Error('Cannot add partner to past, cancelled, or completed bookings.');
    }

    // 3. Verify OTP has not been verified & workout has not started
    if (booking.timelineStatus === 'otp_verified' || booking.timelineStatus === 'workout_started' || booking.timelineStatus === 'workout_completed' || booking.timelineStatus === 'session_closed') {
      throw new Error('Cannot add a partner after the session has started.');
    }

    // 4. Verify additional credit requirement
    const profile = this.getProfile(userId);
    if (!profile || profile.creditsBalance < 1) {
      throw new Error('You need 1 additional credit to add a partner to this session. Please recharge your wallet.');
    }

    // Deduct credit
    profile.creditsBalance -= 1;

    // Create ledger transaction
    const tx: Invoice = {
      id: generateUUID('tx'),
      userId,
      type: 'spend',
      amount: '₹0',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
      status: 'paid',
      credits: 1 // 1 credit consumed
    };

    // Update booking fields
    booking.participantCount = 2;
    booking.sessionType = 'COUPLE';
    booking.partnerName = partnerName;
    booking.partnerPhone = partnerPhone;

    this.schema.credit_transactions.unshift(tx);
    this.save();

    // Notify trainer
    if (booking.trainerId) {
      this.addNotification(booking.trainerId, {
        title: 'SESSION UPDATED — 2 PARTICIPANTS 🔔',
        body: `Your ${booking.workoutTitle} session on ${booking.date} @ ${booking.time} is now a 2-person session.`,
        icon: 'users',
        type: 'Trainer Updates',
        priority: 'high',
        actionLabel: 'View Details',
        deepLink: `/session-detail?id=${booking.id}`
      });
    }

    // Send partner invitation notification
    this.addNotification(userId, {
      title: 'Partner Added! 🤝',
      body: `You've successfully added ${partnerName} (+91 ${partnerPhone}) to your session.`,
      icon: 'user-plus',
      type: 'Bookings',
      priority: 'medium',
      actionLabel: 'View Details',
      deepLink: `/session-detail?id=${booking.id}`
    });

    // Write to Supabase (Atomic) via secure RPC
    const { data: rpcRes, error: rpcErr } = await supabase.rpc('add_partner_to_booking', {
      p_booking_id: bookingId,
      p_partner_name: partnerName,
      p_partner_phone: partnerPhone
    });

    if (rpcErr) {
      console.error('[DB ERROR] add_partner_to_booking RPC failed:', rpcErr);
      throw new Error(rpcErr.message);
    }

    if (rpcRes && rpcRes.tx_id) {
      tx.id = rpcRes.tx_id;
    }

    return booking;
  }

  getPayments(userId: string): any[] {
    return this.schema.payments;
  }

  async purchasePlan(userId: string, planName: string, credits: number, priceText: string, gstText: string, totalText: string): Promise<void> {
    const invoiceNo = `VR-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const date = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });

    try {
      const { data, error } = await supabase.rpc('purchase_credits', {
        p_plan_name: planName,
        p_credits: credits,
        p_amount: priceText
      });

      if (error) {
        console.error('[DB ERROR] purchase_credits RPC failed:', error);
        throw new Error(error.message);
      }

      const newPay = {
        id: data?.tx_id || generateUUID('pay'),
        invoiceNo,
        date,
        planName,
        credits,
        amount: priceText,
        gst: gstText,
        total: totalText,
        method: 'Apple Pay (•••• 4920)',
        status: 'completed' as const
      };

      this.schema.payments.unshift(newPay);
      await this.refreshUserData(userId);
      this.save();
      this.log('PurchaseCredits', `User ${userId} bought ${planName} for ${totalText} adding ${credits} credits`);
    } catch (e: any) {
      console.error('[DB ERROR] purchasePlan failed:', e);
      throw e;
    }
  }

  // Notifications Operations
  getNotifications(userId: string): NotificationItem[] {
    return this.schema.notifications;
  }

  addNotification(userId: string, item: Omit<NotificationItem, 'id' | 'read' | 'timestamp' | 'group'>): NotificationItem {
    const newNotify: NotificationItem = {
      ...item,
      id: generateUUID('notify'),
      read: false,
      timestamp: 'Just now',
      group: 'today'
    };
    this.schema.notifications.unshift(newNotify);
    
    // Only write to Supabase if the notification is for the currently logged in user.
    // Direct inserts for other users are blocked by RLS.
    if (!this.currentUserId || userId === this.currentUserId) {
      supabase.from('notifications').insert(mapNotificationItemToPostgres(newNotify, userId)).then();
    }

    this.save();
    this.log('AddNotification', `Logged notification for user ${userId}: ${item.title}`);
    return newNotify;
  }

  markNotificationAsRead(userId: string, id: string): void {
    const n = this.schema.notifications.find(item => item.id === id);
    if (n) {
      n.read = true;
      supabase.from('notifications').update({ read: true }).eq('id', id).then();
      this.save();
    }
  }

  markAllNotificationsRead(userId: string): void {
    this.schema.notifications.forEach(n => {
      n.read = true;
    });
    supabase.from('notifications').update({ read: true }).eq('user_id', userId).then();
    this.save();
  }

  clearAllNotifications(userId: string): void {
    this.schema.notifications = [];
    supabase.from('notifications').delete().eq('user_id', userId).then();
    this.save();
  }

  deleteNotification(userId: string, id: string): void {
    this.schema.notifications = this.schema.notifications.filter(n => n.id !== id);
    supabase.from('notifications').delete().eq('id', id).then();
    this.save();
  }

  // Chats & Chat Messages
  getChats(userId: string): any[] {
    return [
      {
        id: 'chat-c-1',
        name: 'Coach Karan Sharma',
        avatar: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&w=150&q=80',
        lastMessage: this.getLastChatMessage('chat-c-1') || "I'll be bringing the resistance bands today. See you at 10 AM!",
        time: '20m ago',
        unread: this.hasUnreadMessages('chat-c-1')
      },
      {
        id: 'chat-c-2',
        name: 'Coach Priya Patel',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
        lastMessage: this.getLastChatMessage('chat-c-2') || 'Great job during yesterday yoga session! Take plenty of fluids.',
        time: 'Yesterday',
        unread: this.hasUnreadMessages('chat-c-2')
      }
    ];
  }

  getChatMessages(chatId: string): ChatMessage[] {
    const list = this.schema.messages.filter(m => m.chatId === chatId);
    if (list.length === 0) {
      if (chatId === 'chat-c-1') {
        return [
          { id: 'm-init-1', chatId, sender: 'coach', text: "Hello! I'm preparing for our Strength session today.", timestamp: '10:05 AM' },
          { id: 'm-init-2', chatId, sender: 'coach', text: 'Do you have any specific areas of muscle soreness we should prioritize?', timestamp: '10:06 AM' }
        ];
      }
    }
    return list;
  }

  sendChatMessage(chatId: string, text: string, sender: ChatMessage['sender']): ChatMessage {
    const timeStr = new Date().toISOString();
    const msg: ChatMessage = {
      id: generateUUID('msg'),
      chatId,
      sender,
      text,
      timestamp: timeStr
    };
    this.schema.messages.push(msg);
    
    supabase.from('chat_messages').insert(mapChatMessageToPostgres(msg)).then();

    this.save();
    this.log('SendMessage', `Sent message: "${text}" in chat ${chatId}`);
    return msg;
  }

  private getLastChatMessage(chatId: string): string | null {
    const list = this.getChatMessages(chatId);
    return list.length > 0 ? list[list.length - 1].text : null;
  }

  private hasUnreadMessages(chatId: string): boolean {
    const list = this.getChatMessages(chatId);
    return list.some(m => m.sender !== 'user' && m.id.startsWith('msg-u-'));
  }

  // Address Management
  getAddresses(userId: string): SavedAddress[] {
    return this.schema.addresses.filter(a => a.userId === userId);
  }

  addAddress(userId: string, addr: Omit<SavedAddress, 'id' | 'userId'>): SavedAddress {
    const id = generateUUID('addr');
    const newAddr: SavedAddress = {
      ...addr,
      id,
      userId,
      isDefault: addr.isDefault
    };

    if (addr.isDefault) {
      this.schema.addresses.forEach(a => {
        a.isDefault = false;
      });
      supabase.from('addresses').update({ is_default: false }).eq('user_id', userId).then();
    }

    this.schema.addresses.push(newAddr);
    supabase.from('addresses').insert(mapSavedAddressToPostgres(newAddr)).then();

    this.save();
    return newAddr;
  }

  updateAddress(id: string, fields: Partial<SavedAddress>): void {
    const addr = this.schema.addresses.find(a => a.id === id);
    if (addr) {
      Object.assign(addr, fields);
      if (fields.isDefault) {
        this.schema.addresses.forEach(a => {
          if (a.id !== id) a.isDefault = false;
        });
        if (addr.userId) {
          supabase.from('addresses').update({ is_default: false }).eq('user_id', addr.userId).neq('id', id).then();
        }
      }
      
      const pgAddr = mapSavedAddressToPostgres(addr);
      const updateFields: any = {};
      for (const k of Object.keys(fields)) {
        const snakeKey = k.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
        updateFields[snakeKey] = pgAddr[snakeKey];
      }
      supabase.from('addresses').update(updateFields).eq('id', id).then();

      this.save();
    }
  }

  deleteAddress(id: string): void {
    this.schema.addresses = this.schema.addresses.filter(a => a.id !== id);
    supabase.from('addresses').delete().eq('id', id).then();
    this.save();
  }

  // AI Wellness Coach Recommendations
  getAIRecommendations(userId: string): { title: string; desc: string }[] {
    const profile = this.getProfile(userId);
    if (!profile || !profile.fitnessGoal) {
      return [
        { title: 'Complete Profile 📋', desc: 'Add your fitness goals to generate custom AI wellness briefs.' },
        { title: 'Book First Session 🏋️', desc: 'Schedule a recovery or conditioning session to begin metrics tracking.' }
      ];
    }

    const workoutsCount = this.schema.bookings.filter(b => b.status === 'completed').length;
    if (workoutsCount === 0) {
      return [
        { title: 'Start with PowerForge', desc: `Ready to target "${profile.fitnessGoal}"? Schedule a low-intensity mobility session.` },
        { title: 'Hydration Briefing', desc: 'Drinking 2.5L water daily optimizes your recovery indices.' },
        { title: 'Add Emergency Contact', desc: 'Secure verification: double-check emergency contact notes are set.' }
      ];
    }

    return [
      { title: 'Increase Intensity 🔥', desc: `Optimal Recovery: Great day to book a strength PowerForge session based on your goal "${profile.fitnessGoal}".` },
      { title: 'Try ZenFlow Yoga 🧘‍♀️', desc: 'Active recovery: loosen muscle tightness with 45 mins gentle mobility yoga.' },
      { title: 'Streak Boost ⏱', desc: 'You are building a great workout habit. Log 1 session tomorrow to continue.' }
    ];
  }

  // Trainer Earnings & Schedules
  getEarnings(userId: string): TrainerEarning[] {
    return this.schema.earnings;
  }

  addEarning(earning: Omit<TrainerEarning, 'id' | 'date'>): void {
    console.log('[DB] addEarning client call ignored. Earnings are authoritative on Supabase.');
  }

  private normalizePhone(phone: string): string {
    const digits = phone.replace(/\D/g, '');
    if (digits.startsWith('91') && digits.length === 12) {
      return digits;
    }
    if (digits.length === 10) {
      return '91' + digits;
    }
    return digits;
  }

  async submitTrainerApplication(appData: Omit<TrainerApplication, 'id' | 'createdAt' | 'updatedAt' | 'status'>): Promise<TrainerApplication> {
    const gender = (appData.gender || '').toLowerCase();
    if (gender !== 'male' && gender !== 'female') {
      throw new Error('Please select a valid gender (Male or Female) to submit your application.');
    }
    const normalizedPhone = this.normalizePhone(appData.phone);
    const normalizedApp = {
      ...appData,
      phone: normalizedPhone,
      gender: gender
    };

    const id = generateUUID('app');
    const newApp: TrainerApplication = {
      ...normalizedApp,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'pending'
    };
    this.schema.trainer_applications.unshift(newApp);
    
    const { error } = await supabase.from('trainer_applications').insert(mapTrainerApplicationToPostgres(newApp));
    if (error) {
      throw new Error(`Failed to submit application: ${error.message}`);
    }

    await this.save();
    return newApp;
  }

  async updateTrainerApplication(appId: string, appData: Partial<TrainerApplication>): Promise<TrainerApplication> {
    await this.load();
    const appIndex = this.schema.trainer_applications.findIndex(a => a.id === appId);
    if (appIndex === -1) {
      throw new Error('Application not found');
    }
    if (appData.gender !== undefined) {
      const gender = (appData.gender || '').toLowerCase();
      if (gender !== 'male' && gender !== 'female') {
        throw new Error('Please select a valid gender (Male or Female) to submit your application.');
      }
      appData.gender = gender;
    }
    const updatedApp = {
      ...this.schema.trainer_applications[appIndex],
      ...appData,
      updatedAt: new Date().toISOString(),
      status: 'pending' as const
    };
    this.schema.trainer_applications[appIndex] = updatedApp;
    
    const { error } = await supabase
      .from('trainer_applications')
      .update(mapTrainerApplicationToPostgres(updatedApp))
      .eq('id', appId);
      
    if (error) {
      throw new Error(`Failed to update application: ${error.message}`);
    }
    
    await this.save();
    return updatedApp;
  }

  getTrainerApplication(phone: string): TrainerApplication | null {
    return this.schema.trainer_applications.find(a => a.phone === phone) || null;
  }

  async fetchAllTrainerApplications(): Promise<TrainerApplication[]> {
    const { data, error } = await supabase.from('trainer_applications').select('*');
    if (error) {
      throw new Error(`Failed to fetch applications: ${error.message}`);
    }
    this.schema.trainer_applications = (data || []).map(mapTrainerApplication);
    return this.schema.trainer_applications;
  }

  async approveTrainerApplication(appId: string): Promise<void> {
    const { error } = await supabase.rpc('approve_trainer_application', { app_id: appId });
    if (error) {
      throw new Error(`Failed to approve trainer application: ${error.message}`);
    }
    await this.reload();
  }

  async rejectTrainerApplication(appId: string): Promise<void> {
    const { error } = await supabase.rpc('reject_trainer_application', { app_id: appId });
    if (error) {
      throw new Error(`Failed to reject trainer application: ${error.message}`);
    }
    await this.reload();
  }

  async requestMoreInfoTrainerApplication(appId: string): Promise<void> {
    const app = this.schema.trainer_applications.find(a => a.id === appId);
    if (app) {
      if (app.status === 'approved') {
        throw new Error('Cannot request additional information for an approved application');
      }
      app.status = 'info_requested';
      app.updatedAt = new Date().toISOString();
      
      const pgApp = mapTrainerApplicationToPostgres(app);
      const { error } = await supabase.from('trainer_applications').update({ 
        status: 'info_requested', 
        updated_at: app.updatedAt,
        document_certifications: pgApp.document_certifications
      }).eq('id', appId);
      
      if (error) {
        throw new Error(`Failed to request info: ${error.message}`);
      }

      await this.save();
      this.log('RequestMoreInfoTrainer', `Requested additional info for application of ${app.fullName}.`);
    }
  }

  logAssignmentEvent(event: Omit<AssignmentLog, 'id' | 'timestamp'>): void {
    const log: AssignmentLog = {
      ...event,
      id: generateUUID('log'),
      timestamp: Date.now()
    };
    if (!this.schema.assignment_logs) {
      this.schema.assignment_logs = [];
    }
    this.schema.assignment_logs.push(log);
    
    // Asynchronously update supabase schema log if possible
    supabase.from('assignment_logs').insert([log]).then(() => {});
    
    this.save();
    console.log(`[ASSIGNMENT ENGINE EVENT] Booking ID: ${log.bookingId} | Trainer ID: ${log.trainerId} | Action: ${log.action.toUpperCase()} | Score: ${log.score.toFixed(1)} | Reason: ${log.reason}`);
  }

  async updateTrainerOnlineStatus(coachId: string, isOnline: boolean): Promise<void> {
    const coach = this.schema.coaches.find(c => c.id === coachId);
    if (coach) {
      coach.isOnline = isOnline;
      if (!coach.preferences) {
        coach.preferences = { online: isOnline, radiusKm: 15, maxDailySessions: 5, categories: [] };
      } else {
        coach.preferences.online = isOnline;
      }
      await this.updateCoach(coachId, { preferences: coach.preferences });
    }
  }

  async updateTrainerPreferences(coachId: string, preferences: any): Promise<void> {
    const coach = this.schema.coaches.find(c => c.id === coachId);
    if (coach) {
      coach.preferences = {
        ...(coach.preferences || { online: false, radiusKm: 15, maxDailySessions: 5, categories: [] }),
        ...preferences
      };
      await this.updateCoach(coachId, { preferences: coach.preferences });
    }
  }

  // Workout Assignment queries and mutations
  getWorkoutAssignments(trainerId: string): TrainerWorkoutAssignment[] {
    return (this.schema.trainer_workout_assignments || []).filter(a => a.trainerId === trainerId);
  }

  async requestWorkoutAssignment(trainerId: string, category: string): Promise<void> {
    const id = generateUUID('twa');
    const newAssignment: TrainerWorkoutAssignment = {
      id,
      trainerId,
      workoutCategory: category,
      status: 'PENDING',
      requestedAt: Date.now()
    };
    
    if (!this.schema.trainer_workout_assignments) {
      this.schema.trainer_workout_assignments = [];
    }
    
    // Check if there is an existing PENDING or REMOVED request to update/replace
    const existingIdx = this.schema.trainer_workout_assignments.findIndex(
      a => a.trainerId === trainerId && a.workoutCategory === category
    );
    
    if (existingIdx >= 0) {
      this.schema.trainer_workout_assignments[existingIdx] = {
        ...this.schema.trainer_workout_assignments[existingIdx],
        status: 'PENDING',
        requestedAt: Date.now(),
        rejectedAt: undefined,
        rejectionReason: undefined
      };
      const assignment = this.schema.trainer_workout_assignments[existingIdx];
      const { error } = await supabase.from('trainer_workout_assignments').upsert(mapWorkoutAssignmentToPostgres(assignment));
      if (error) {
        throw new Error(`Failed to submit request in database: ${error.message}`);
      }
    } else {
      this.schema.trainer_workout_assignments.unshift(newAssignment);
      const { error } = await supabase.from('trainer_workout_assignments').insert(mapWorkoutAssignmentToPostgres(newAssignment));
      if (error) {
        // Rollback local change if DB call fails
        this.schema.trainer_workout_assignments.shift();
        throw new Error(`Failed to insert request in database: ${error.message}`);
      }
    }
    
    await this.save();
    this.syncCoachesWithAssignments();
    this.log('RequestWorkoutAssignment', `Trainer ${trainerId} requested assignment for ${category}.`);
  }

  async requestWorkoutRemoval(trainerId: string, category: string): Promise<void> {
    if (!this.schema.trainer_workout_assignments) return;
    const assignment = this.schema.trainer_workout_assignments.find(
      a => a.trainerId === trainerId && a.workoutCategory === category && a.status === 'APPROVED'
    );
    if (assignment) {
      const prevStatus = assignment.status;
      assignment.status = 'REMOVAL_REQUESTED';
      assignment.updatedAt = new Date().toISOString();
      const { error } = await supabase.from('trainer_workout_assignments')
        .update({ status: 'REMOVAL_REQUESTED' })
        .eq('id', assignment.id);
      
      if (error) {
        assignment.status = prevStatus; // Rollback
        throw new Error(`Failed to request removal in database: ${error.message}`);
      }
      
      await this.save();
      this.syncCoachesWithAssignments();
      this.log('RequestWorkoutRemoval', `Trainer ${trainerId} requested removal of ${category}.`);
    }
  }

  async adminApproveAssignment(assignmentId: string, adminId: string): Promise<void> {
    if (!this.schema.trainer_workout_assignments) return;
    const assignment = this.schema.trainer_workout_assignments.find(a => a.id === assignmentId);
    if (assignment) {
      const isRemoval = assignment.status === 'REMOVAL_REQUESTED';
      assignment.status = isRemoval ? 'REMOVED' : 'APPROVED';
      assignment.approvedAt = Date.now();
      assignment.approvedBy = adminId;
      assignment.updatedAt = new Date().toISOString();

      // Update in Supabase
      const { error } = await supabase.from('trainer_workout_assignments')
        .update(mapWorkoutAssignmentToPostgres(assignment))
        .eq('id', assignmentId);

      if (error) {
        throw new Error(`Failed to approve assignment in database: ${error.message}`);
      }

      // Update trainer categories in Supabase/local cache
      const coach = this.schema.coaches.find(c => c.id === assignment.trainerId);
      if (coach) {
        const currentCats = coach.preferences?.categories || [];
        let updatedCats = [...currentCats];
        if (isRemoval) {
          updatedCats = updatedCats.filter(cat => cat !== assignment.workoutCategory);
        } else {
          if (!updatedCats.includes(assignment.workoutCategory)) {
            updatedCats.push(assignment.workoutCategory);
          }
        }
        
        const updatedPrefs = {
          ...(coach.preferences || { online: false, radiusKm: 15, maxDailySessions: 5, categories: [] }),
          categories: updatedCats
        };
        await this.updateCoach(coach.id, { preferences: updatedPrefs });
      }

      await this.save();
      this.syncCoachesWithAssignments();
      this.log('ApproveWorkoutAssignment', `Admin ${adminId} approved ${assignment.workoutCategory} for trainer ${assignment.trainerId} (Result: ${assignment.status}).`);
    }
  }

  async adminRejectAssignment(assignmentId: string, adminId: string, reason: string): Promise<void> {
    if (!this.schema.trainer_workout_assignments) return;
    const assignment = this.schema.trainer_workout_assignments.find(a => a.id === assignmentId);
    if (assignment) {
      const prevStatus = assignment.status;
      assignment.status = prevStatus === 'REMOVAL_REQUESTED' ? 'APPROVED' : 'REJECTED';
      assignment.rejectedAt = Date.now();
      assignment.rejectedBy = adminId;
      assignment.rejectionReason = reason;
      assignment.updatedAt = new Date().toISOString();

      // Update in Supabase
      const { error } = await supabase.from('trainer_workout_assignments')
        .update(mapWorkoutAssignmentToPostgres(assignment))
        .eq('id', assignmentId);

      if (error) {
        throw new Error(`Failed to reject assignment: ${error.message}`);
      }

      await this.save();
      this.syncCoachesWithAssignments();
      this.log('RejectWorkoutAssignment', `Admin ${adminId} rejected ${assignment.workoutCategory} request for trainer ${assignment.trainerId}. Reason: ${reason}`);
    }
  }

  async fetchTrainerVerificationDocs(trainerId: string): Promise<any[]> {
    const { data, error } = await supabase
      .from('trainer_verification_documents')
      .select('*')
      .eq('trainer_id', trainerId)
      .order('uploaded_at', { ascending: false });

    if (error) {
      throw new Error(`Failed to fetch verification documents: ${error.message}`);
    }
    return data || [];
  }

  async createTrainerVerificationDoc(data: {
    id: string;
    trainer_id: string;
    storage_path: string;
    file_type: string;
    verification_status: string;
    extracted_name?: string;
    confidence?: number;
    match_result?: string;
    trainer_attested?: boolean;
  }): Promise<any> {
    const { data: inserted, error } = await supabase
      .from('trainer_verification_documents')
      .insert(data)
      .select()
      .single();

    if (error) {
      throw new Error(`Failed to create verification document record: ${error.message}`);
    }
    return inserted;
  }

  async updateTrainerVerificationDoc(docId: string, status: string, attested: boolean): Promise<void> {
    const { error } = await supabase
      .from('trainer_verification_documents')
      .update({
        verification_status: status,
        trainer_attested: attested,
        updated_at: new Date().toISOString()
      })
      .eq('id', docId);

    if (error) {
      throw new Error(`Failed to update verification document: ${error.message}`);
    }
  }
}

export const Database = new DatabaseClient();
