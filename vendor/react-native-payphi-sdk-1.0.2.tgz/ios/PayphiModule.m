#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

// This declares the module name that will be exposed to JS (NativeModules.PayphiSdk)
@interface RCT_EXTERN_MODULE(PayphiSdk, RCTEventEmitter)

// Expose setAppInfo. Notice how we use RCTPromiseResolveBlock for success and RCTPromiseRejectBlock for errors.
RCT_EXTERN_METHOD(setAppInfo:(NSDictionary *)params
                  withResolver:(RCTPromiseResolveBlock)resolve
                  withRejecter:(RCTPromiseRejectBlock)reject)

// Expose makePayment. It takes the parameters but doesn't return a promise because we use the EventEmitter.
RCT_EXTERN_METHOD(makePayment:(NSDictionary *)params)

// Required to allow running on the Main UI Thread
+ (BOOL)requiresMainQueueSetup
{
  return YES;
}

@end