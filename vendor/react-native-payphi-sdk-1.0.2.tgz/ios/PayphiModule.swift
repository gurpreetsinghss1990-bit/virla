import Foundation
import React
import UIKit
import CommonCrypto
import customersdk // Your vendored framework

// MARK: - Listeners

public final class SampleAppListener: AppInitializationListener {
    private let callback: (String?) -> Void
    public init(callback: @escaping (String?) -> Void) { self.callback = callback }
    public func onSuccess(status: String?) { callback(status) }
    public func onFailure(errorCode: String?) { callback(nil) }
}

public final class SamplePaymentListener: PayPhiSdk.IAppPaymentResponseListenerEx {
    private let completion: (_ resultCode: Int, _ data: [String: Any]?) -> Void
    public init(completion: @escaping (_ resultCode: Int, _ data: [String: Any]?) -> Void) {
        self.completion = completion
    }
    public func onPaymentResponse(resultCode: Int, data: [String : Any]?, additionalInfo: [String : String]?) {
        completion(resultCode, data)
    }
    public func onPaymentResponse1(resultCode: Int, data: [String : Any]?) {
        // Older callback – ignore.
    }
}

// MARK: - Module

@objc(PayphiSdk)
class PayphiSdk: RCTEventEmitter {
    
    // Keep strong refs to listeners so they don't dealloc before callback
    private var initListener: SampleAppListener?
    private var paymentListener: SamplePaymentListener?

    // Declares the events that this module can send to JavaScript
    override func supportedEvents() -> [String]! {
        return ["payment_response"]
    }

    // Tells RN that these methods should run on the main UI thread
    @objc override var methodQueue: DispatchQueue {
        return .main
    }

    @objc
    func setAppInfo(_ params: NSDictionary, withResolver resolve: @escaping RCTPromiseResolveBlock, withRejecter reject: @escaping RCTPromiseRejectBlock) {
        guard let mid = params["merchantId"] as? String,
              let appId = params["appId"] as? String,
              let env = params["environment"] as? String else {
            reject("ARG_ERROR", "merchantId/appId/environment required", nil)
            return
        }

        let merchantName = (params["merchantName"] as? String) ?? "PayPhi Demo (RN)"

        print("[PayphiSdk-iOS] Calling Application.shared.setEnv(\(env)) & setMerchantName(\(merchantName))")
        Application.shared.setEnv(type: env)
        Application.shared.setMerchantName(name: merchantName)

        // Add a local thread-safe boolean to track if we've already responded
        var hasResponded = false

        initListener = SampleAppListener { status in
            // Check if we already resolved this promise
            guard !hasResponded else { return }
            hasResponded = true

            let statusStr = status ?? ""
            print("[PayphiSdk-iOS] Application.shared.setAppInfo callback received: \(statusStr)")
            if statusStr == "0000" {
                resolve("0000")
            } else {
                reject(statusStr.isEmpty ? "INIT_FAIL" : statusStr, "SDK initialization failed with status: \(statusStr)", nil)
            }
        }

        print("[PayphiSdk-iOS] Invoking Application.shared.setAppInfo mid: \(mid), appId: \(appId)")
        Application.shared.setAppInfo(mid: mid, appId: appId, listener: initListener!)

        // Native safety timeout after 10 seconds if callback doesn't fire
        DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) {
            guard !hasResponded else { return }
            hasResponded = true
            print("[PayphiSdk-iOS] Native setAppInfo timed out waiting for server callback")
            reject("TIMEOUT", "PayPhi gateway did not respond within 10 seconds. Check network or credentials.", nil)
        }
    }

    @objc
    func makePayment(_ params: NSDictionary) {
        guard let amount = params["amount"] as? String,
              let merchantId = params["merchantId"] as? String,
              let merchantTxnNo = params["merchantTxnNo"] as? String,
              let currencyCode = params["currencyCode"] as? String,
              let customerEmailID = params["customerEmailID"] as? String,
              let secretKey = params["secretKey"] as? String else {
            self.sendEvent(withName: "payment_response", body: ["error": true, "code": "ARG_ERROR", "message": "Missing required payment fields."])
            return
        }

        let formattedAmount = formatAmount(amount)
        let tokenInput = "\(formattedAmount)\(currencyCode)\(merchantId)\(merchantTxnNo)"
        let secureToken = hmacSHA256(message: tokenInput, key: secretKey)

        var paymentData: [String: Any] = [
            "Amount": formattedAmount,
            "MerchantID": merchantId,
            "MerchantTxnNo": merchantTxnNo,
            "CurrencyCode": currencyCode,
            "CustomerEmailID": customerEmailID,
            "SecureToken": secureToken
        ]
        
        // Add optionals just like the Flutter version
        if let allow = params["allowDisablePaymentMode"] as? String { paymentData["allowDisablePaymentMode"] = allow }
        if let cust = params["CustomerID"] as? String { paymentData["CustomerID"] = cust }
        if let p1 = params["addlParam1"] as? String { paymentData["addlParam1"] = p1 }
        if let p2 = params["addlParam2"] as? String { paymentData["addlParam2"] = p2 }
        if let payType = params["paymentType"] as? String { paymentData["PaymentType"] = payType }
        if let vpa = params["vpa"] as? String { paymentData["vpa"] = vpa }
        if let agg = params["aggregatorID"] as? String { paymentData["aggregatorID"] = agg }
        if let api = params["apiVersion"] as? String { paymentData["apiVersion"] = api }

        paymentListener = SamplePaymentListener { [weak self] resultCode, data in
            guard let self = self else { return }
            var payload = data ?? [:]
            payload["resultCode"] = resultCode
            
            // Send the JSON map over the event emitter
            self.sendEvent(withName: "payment_response", body: payload)
        }

        guard let rootVC = getTopMostViewController() else {
            self.sendEvent(withName: "payment_response", body: ["error": true, "code": "NO_VIEW", "message": "No visible view controller to start payment."])
            return
        }

        PayPhiSdk.makePayment(
            context: rootVC,
            paymentData: paymentData,
            display: PayPhiSdk.DIALOG,
            listenerEx: paymentListener!
        )
    }

    // MARK: - Helpers

    private func formatAmount(_ raw: String) -> String {
        if let f = Float(raw) {
            return String(format: "%.2f", f)
        }
        return raw
    }

    private func hmacSHA256(message: String, key: String) -> String {
        guard let keyData = key.data(using: .utf8),
              let msgData = message.data(using: .utf8) else { return "" }

        var digest = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
        keyData.withUnsafeBytes { keyPtr in
            msgData.withUnsafeBytes { msgPtr in
                CCHmac(CCHmacAlgorithm(kCCHmacAlgSHA256),
                       keyPtr.baseAddress,
                       keyData.count,
                       msgPtr.baseAddress,
                       msgData.count,
                       &digest)
            }
        }
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }

    // Equivalent to your UIApplication.pp_topMostViewController extension
    private func getTopMostViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return getTopMostViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopMostViewController(base: selected)
        }
        if let presented = base?.presentedViewController {
            return getTopMostViewController(base: presented)
        }
        return base
    }
}