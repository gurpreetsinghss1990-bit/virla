import { NativeModules, NativeEventEmitter, Platform } from "react-native";

// 1. Link to the Native Module we created
const { PayphiSdk } = NativeModules;

// Provide a helpful error if the user forgets to rebuild their app after installing
if (!PayphiSdk) {
  throw new Error(
    `The package 'react-native-payphi-sdk' doesn't seem to be linked. Make sure: \n\n` +
      Platform.select({ ios: "- You have run 'pod install'\n", default: "" }) +
      "- You rebuilt the app after installing the package\n",
  );
}

// 2. Create the Event Emitter for the Stream
const payphiEmitter = new NativeEventEmitter(PayphiSdk);

// 3. Export the JS interface for your clients
export default {
  /**
   * Equivalent to getPlatformVersion
   */
  getPlatformVersion: async () => {
    return `${Platform.OS} ${Platform.Version}`;
  },

  /**
   * Equivalent to setAppInfo
   * We pass this as an object because Kotlin expects a ReadableMap
   */
  setAppInfo: async (environment, merchantId, appId, merchantName = "") => {
    try {
      const result = await PayphiSdk.setAppInfo({
        environment,
        merchantId,
        appId,
        merchantName,
      });
      return result;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Equivalent to makePayment
   * Using JS destructuring to mimic Dart's named parameters
   */
  makePayment: ({
    amount,
    merchantId,
    merchantTxnNo,
    currencyCode,
    customerEmailID,
    secretKey,
    addlParam1 = "",
    addlParam2 = "",
    aggregatorID = "",
    apiVersion = "1.0",
  }) => {
    // Note: This doesn't return a Promise because the response comes through the Stream
    PayphiSdk.makePayment({
      amount,
      merchantId,
      merchantTxnNo,
      currencyCode,
      customerEmailID,
      secretKey,
      addlParam1,
      addlParam2,
      aggregatorID,
      apiVersion,
    });
  },

  /**
   * Equivalent to paymentResponseStream
   * Usage: const subscription = PayphiSdk.addPaymentResponseListener((event) => { ... })
   * Remember to call subscription.remove() when unmounting!
   */
  addPaymentResponseListener: (callback) => {
    return payphiEmitter.addListener("payment_response", (event) => {
      // In native, we sent the JSON as a string, so we parse it here for the user
      try {
        const parsedEvent =
          typeof event === "string" ? JSON.parse(event) : event;
        callback(parsedEvent);
      } catch (e) {
        callback(event);
      }
    });
  },
};
