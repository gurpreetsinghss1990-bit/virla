package com.payphi.reactnative.sdk

import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.payphi.customersdk.utils.HmacUtility
import com.payphi.customersdk.views.Application
import com.payphi.customersdk.views.PayPhiSdk
import com.payphi.customersdk.views.PaymentOptionsActivity
import org.json.JSONException
import org.json.JSONObject
import java.text.DecimalFormat
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

class PayphiModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {

    private val TAG = "PayphiModule"

    // This is the name exposed to JavaScript: NativeModules.PayphiSdk
    override fun getName(): String {
        return "PayphiSdk"
    }

    // Helper to replace Flutter's EventChannel
    private fun sendEvent(eventName: String, params: String) {
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(eventName, params)
    }

    @ReactMethod
    fun setAppInfo(params: ReadableMap, promise: Promise) {
        Log.d(TAG, "setAppInfo Called")

        if (params.hasKey("environment") && params.hasKey("merchantId") && params.hasKey("appId")) {
            val merchantId = params.getString("merchantId")
            val appId = params.getString("appId")
            val env = params.getString("environment")
            val merchantName = if (params.hasKey("merchantName")) params.getString("merchantName") else ""

            Log.d(TAG, "setAppInfoData: merchantId: $merchantId, appId: $appId, environment: $env")

            val application = Application
            env?.let { application.setEnv(it) }

            application.setAppInfo(
                merchantId!!,
                appId!!,
                reactContext,
                object : Application.IAppInitializationListener {
                    override fun onSuccess(status: String?) {
                        merchantName?.let { application.setMerchantName(it, reactContext) }
                        promise.resolve(status)
                    }

                    override fun onFailure(errorCode: String?) {
                        when (errorCode) {
                            "201" -> promise.reject(errorCode, "Invalid app credentials")
                            "504" -> promise.reject(errorCode, "Connection error")
                            "205" -> promise.reject(errorCode, "Payments not enabled")
                            "101" -> promise.reject(errorCode, "Internal error while fetching the payment options")
                            else -> promise.reject(errorCode ?: "UNKNOWN", "Generic error")
                        }
                    }
                }
            )
        } else {
            promise.reject("MISSING_ARGS", "Mandatory fields are missing")
        }
    }

    @ReactMethod
    fun makePayment(params: ReadableMap) {
        try {
            if (!params.hasKey("amount") || !params.hasKey("merchantId") || !params.hasKey("merchantTxnNo") ||
                !params.hasKey("currencyCode") || !params.hasKey("customerEmailID") || !params.hasKey("secretKey")
            ) {
                sendEvent("payment_response", "{\"error\": \"Mandatory fields are missing\"}")
                return
            }

            val amountRaw = params.getString("amount")
            val merchantId = params.getString("merchantId")
            val merchantTxnNo = params.getString("merchantTxnNo")
            val currencyCode = params.getString("currencyCode")
            val secretKey = params.getString("secretKey")

            val secureToken = getSecureToken(amountRaw, currencyCode, merchantId, merchantTxnNo, secretKey)

            // Create a bundle with all the payment parameters
            val paymentParams = Bundle().apply {
                putString("Amount", String.format("%.2f", amountRaw?.toFloat()))
                putString("MerchantID", merchantId)
                putString("MerchantTxnNo", merchantTxnNo)
                putString("CurrencyCode", currencyCode)
                putString("CustomerEmailID", params.getString("customerEmailID"))
                putString("SecureToken", secureToken)
                putString("invoiceNo", merchantTxnNo)

                if (params.hasKey("allowDisablePaymentMode")) putString("allowDisablePaymentMode", params.getString("allowDisablePaymentMode"))
                if (params.hasKey("CustomerID")) putString("CustomerID", "50000426") // From your flutter code
                if (params.hasKey("addlParam1")) putString("addlParam1", params.getString("addlParam1"))
                if (params.hasKey("addlParam2")) putString("addlParam2", params.getString("addlParam2"))
                if (params.hasKey("paymentType")) putString("PaymentType", params.getString("paymentType"))
                if (params.hasKey("vpa")) putString("vpa", params.getString("vpa"))
                if (params.hasKey("aggregatorID")) putString("aggregatorID", params.getString("aggregatorID"))
                if (params.hasKey("apiVersion")) putString("apiVersion", params.getString("apiVersion"))
            }

            val responseListener = object : PayPhiSdk.IAppPaymentResponseListenerEx {
                override fun onPaymentResponse(resultCode: Int, data: Intent?, additionalInfo: Map<String?, String?>?) {
                    val bundleData = data?.extras
                    val bundleToJsonResult = bundleData?.let { bundleToJson(it) }
                    Log.d(TAG, "onPaymentResponse: bundleToJsonResult $bundleToJsonResult")
                    
                    // Stream response through event channel
                    sendEvent("payment_response", bundleToJsonResult.toString())
                }

                override fun onPaymentResponse1(resultCode: Int, data: Intent?) {
                    Log.d(TAG, "onPaymentResponse1: resultCode => $resultCode")
                }
            }

            val intent = Intent(reactContext, PaymentOptionsActivity::class.java).apply {
                putExtras(paymentParams)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or Intent.FLAG_ACTIVITY_NO_HISTORY)
            }

            PayPhiSdk.makePayment(reactContext, intent, PayPhiSdk.DIALOG, responseListener)

        } catch (e: Exception) {
            Log.e(TAG, "Error starting payment: ${e.message}", e)
            sendEvent("payment_response", "{\"error\": \"${e.message}\"}")
        }
    }

    // To suppress warnings since RN expects Event Emitters to have these two methods natively declared
    @ReactMethod
    fun addListener(eventName: String) {}

    @ReactMethod
    fun removeListeners(count: Int) {}

    private fun getSecureToken(amountRaw: String?, currencyCode: String?, merchantId: String?, merchantTxnNo: String?, secretKey: String?): String? {
        val df = DecimalFormat()
        df.minimumFractionDigits = 2
        val f = amountRaw?.toFloat()
        val formattedAmount = String.format("%.2f", f)
        val value = formattedAmount + currencyCode + merchantId + merchantTxnNo
        return secretKey?.let { generateHMAC(value, it) }
    }

    private fun generateHMAC(message: String, secretKey: String): String? {
        return try {
            val sha256_HMAC = Mac.getInstance("HmacSHA256")
            val secret_key = SecretKeySpec(secretKey.toByteArray(), "HmacSHA256")
            sha256_HMAC.init(secret_key)
            val hashedBytes = sha256_HMAC.doFinal(message.toByteArray())
            HmacUtility.bytesToHex(hashedBytes)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun bundleToJson(bundle: Bundle): JSONObject {
        val json = JSONObject()
        for (key in bundle.keySet()) {
            try {
                json.put(key, JSONObject.wrap(bundle.get(key)))
            } catch (e: JSONException) {
                // Handle exception
            }
        }
        return json
    }
}