require "json"

# Read package.json to automatically keep version and descriptions in sync
package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "react-native-payphi-sdk"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.description  = <<-DESC
A React Native wrapper for the PayPhi iOS Customer SDK (customersdk.framework).
DESC
  s.homepage     = "https://payphi.com"
  s.license      = package["license"]
  s.authors      = { "PayPhi" => "appdeveloper@phicommerce.com" }
  
  # Set the minimum iOS version to match what your framework requires
  s.platforms    = { :ios => "12.0" }
  s.swift_version = '5.0'
  
  # For local packages, the source isn't strictly used, but it's required by CocoaPods validation
  s.source       = { :git => "https://github.com/yourusername/react-native-payphi-sdk.git", :tag => "#{s.version}" }

  # Look for the bridge files inside our 'ios' folder
  s.source_files = "ios/**/*.{h,m,swift}"

  # 1. Your packaged iOS SDK framework
  # Make sure you physically drop your customersdk.framework into the ios/Frameworks/ folder!
  s.vendored_frameworks = 'ios/Frameworks/customersdk.framework'

  # 2. Resources (Optional)
  # If your framework relies on external images/XIBs/storyboards, you can drop them in ios/Resources
  # s.resources = ['ios/Resources/**/*']

  # 3. React Native dependency (Replaces Flutter)
  s.dependency "React-Core"
end